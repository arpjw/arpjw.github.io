"""Exact finite checks for 'On the Additive Composition of Two and Two'.

This checks the paper's bookkeeping, not the analytic theorems it invokes.
Run with Python 3.10 or later. No external dependencies are required.
"""

from __future__ import annotations

Matrix = list[list[int]]


def zeros(n: int) -> Matrix:
    return [[0 for _ in range(n)] for _ in range(n)]


def multiply(a: Matrix, b: Matrix) -> Matrix:
    n = len(a)
    return [
        [sum(a[i][k] * b[k][j] for k in range(n)) for j in range(n)]
        for i in range(n)
    ]


def add(a: Matrix, b: Matrix) -> Matrix:
    return [[x + y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def check(condition: bool, description: str) -> None:
    if not condition:
        raise AssertionError(description)


def main() -> None:
    a = ("a0", "a1")
    b = ("b0", "b1")
    u = tuple((x, "L") for x in a) + tuple((x, "R") for x in b)
    q = ("q0", "q1", "q2", "q3")
    matching = dict(zip(u, q))
    inverse = {value: key for key, value in matching.items()}
    check(len(set(u)) == len(u), "Tagged elements must be distinct")
    check(set(matching) == set(u), "The matching must be total")
    check(set(matching.values()) == set(q), "The matching must be onto")
    check(len(inverse) == len(matching), "The matching must be injective")
    check(all(inverse[matching[x]] == x for x in u), "Left inverse")
    check(all(matching[inverse[y]] == y for y in q), "Right inverse")

    # Coordinates of harmonic modes against (evaluate A, integrate A,
    # evaluate B, integrate B), with evaluation restricted to degree zero.
    harmonic_coordinates = [
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
    ]
    harmonic_inverse = [list(row) for row in zip(*harmonic_coordinates)]
    identity_four = [[int(i == j) for j in range(4)] for i in range(4)]
    check(multiply(harmonic_coordinates, harmonic_inverse) == identity_four,
          "Right inverse of harmonic comparison")
    check(multiply(harmonic_inverse, harmonic_coordinates) == identity_four,
          "Left inverse of harmonic comparison")

    # E_r has r coordinates in degree 1 followed by r in degree 2.
    # Check d^2 = 0 and dh + hd = I as exact integer matrix identities.
    for r in (0, 1, 2, 7, 19):
        n = 2 * r
        differential = zeros(n)
        homotopy = zeros(n)
        identity = [[int(i == j) for j in range(n)] for i in range(n)]
        for j in range(r):
            differential[r + j][j] = 1
            homotopy[j][r + j] = 1
        check(multiply(differential, differential) == zeros(n), f"d^2, r={r}")
        check(add(multiply(differential, homotopy),
                  multiply(homotopy, differential)) == identity,
              f"Contraction, r={r}")
        check(len(u) - r + r == len(u), f"Euler stabilization, r={r}")

    # The symbolic coefficient identity m - 2m + m = 0 is checked
    # by comparing coefficients, then by finite examples of multiplicities.
    check(1 - 2 + 1 == 0, "Positive-mode coefficient identity")
    for ell in (1, 2, 3, 17, 1000):
        multiplicity = 2 * ell + 1
        check(multiplicity - 2 * multiplicity + multiplicity == 0,
              f"Positive-mode cancellation, ell={ell}")

    # Recursive addition, written without using + in the recursion itself.
    def successor(n: int) -> int:
        return len(tuple(range(n)) + (None,))

    def recursive_add(left: int, right: int) -> int:
        result = left
        for _ in range(right):
            result = successor(result)
        return result

    two = successor(successor(0))
    four = successor(successor(successor(successor(0))))
    check(recursive_add(two, two) == four, "Recursive numeral normalization")

    print("PASS: tagged bijection and its inverse")
    print("PASS: finite harmonic-coordinate comparison")
    print("PASS: exact contractions for r = 0, 1, 2, 7, 19")
    print("PASS: stabilization and positive-mode coefficient cancellation")
    print("PASS: recursive numeral normalization")
    print("Scope: finite bookkeeping only; analytic theorems are not tested.")


if __name__ == "__main__":
    main()
