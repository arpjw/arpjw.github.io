# On the Additive Composition of Two and Two

A 22-page mathematical satire by Arya Somu.

## Contents

- two-plus-two.pdf: the finished paper.
- two-plus-two.tex: standalone LaTeX source.
- verify_two_plus_two.py: finite structural checks using only the Python standard library.

## Build and verify

Compile the paper with a LaTeX distribution that supports the packages in the source, or run:

    tectonic two-plus-two.tex

Run the finite checks with Python 3.10 or later:

    python3 verify_two_plus_two.py

These checks cover tagged bijections, exact contractions, harmonic-coordinate bookkeeping, spectral multiplicity cancellation, and recursive numeral normalization. They do not mechanically verify the analytic theorems used in the paper. The referee exchange is fictional.
