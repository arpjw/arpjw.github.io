#!/usr/bin/env python3
"""Exact checks for greedy_variance.tex; Python 3.10+, standard library only.

Run: python3 verify.py
The sibling atlas_through_7.g6 is the nonempty part of the Graph Atlas,
exported from NetworkX 3.7 graph_atlas_g().
https://networkx.org/documentation/stable/reference/generated/networkx.generators.atlas.graph_atlas_g.html
Finite checks validate calculations; the manuscript supplies the proofs.
"""

from __future__ import annotations

import hashlib
import itertools
import json
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path

Graph = tuple[int, ...]


def vertices(mask: int):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def read_graph6(line: str) -> Graph:
    data = [ord(c) - 63 for c in line.strip()]
    n = data[0]
    assert 0 < n <= 7
    bits = [(value >> shift) & 1 for value in data[1:] for shift in range(5, -1, -1)]
    adj = [0] * n
    pos = 0
    for j in range(1, n):
        for i in range(j):
            if bits[pos]:
                adj[i] |= 1 << j
                adj[j] |= 1 << i
            pos += 1
    return tuple(adj)


def components(adj: Graph, mask: int) -> list[int]:
    result: list[int] = []
    left = mask
    while left:
        frontier = left & -left
        reached = 0
        while frontier:
            reached |= frontier
            neighbors = 0
            for v in vertices(frontier):
                neighbors |= adj[v]
            frontier = neighbors & mask & ~reached
        result.append(reached)
        left &= ~reached
    return result


def moments(adj: Graph) -> tuple[Q, Q]:
    """First-choice recursion, with exact disjoint-component factorization."""
    @lru_cache(None)
    def solve(mask: int) -> tuple[Q, Q]:
        if not mask:
            return Q(0), Q(0)
        count = mask.bit_count()
        if all(not (adj[v] & mask) for v in vertices(mask)):
            return Q(count), Q(0)
        if all((adj[v] & mask).bit_count() == count - 1 for v in vertices(mask)):
            return Q(1), Q(0)
        parts = components(adj, mask)
        if len(parts) > 1:
            child = [solve(part) for part in parts]
            # Restricted orders on disjoint components are independent uniforms.
            return sum((x[0] for x in child), Q(0)), sum((x[1] for x in child), Q(0))
        mu = second = Q(0)
        for v in vertices(mask):
            child_mu, child_var = solve(mask & ~(adj[v] | (1 << v)))
            conditional_mu = 1 + child_mu
            mu += conditional_mu / count
            second += (child_var + conditional_mu**2) / count
        return mu, second - mu**2

    return solve((1 << len(adj)) - 1)


def is_independent(adj: Graph, mask: int) -> bool:
    return all(not (adj[v] & mask) for v in vertices(mask))


def is_clique(adj: Graph, mask: int) -> bool:
    return all((adj[v] & mask).bit_count() == mask.bit_count() - 1 for v in vertices(mask))


def independence_number(adj: Graph) -> int:
    return max(mask.bit_count() for mask in range(1 << len(adj)) if is_independent(adj, mask))


def split_partitions(adj: Graph) -> list[int]:
    full = (1 << len(adj)) - 1
    return [mask for mask in range(1, full + 1) if is_independent(adj, mask) and is_clique(adj, full ^ mask)]


def is_cograph(adj: Graph) -> bool:
    full = (1 << len(adj)) - 1
    complement = tuple(full & ~(row | (1 << i)) for i, row in enumerate(adj))

    @lru_cache(None)
    def solve(mask: int) -> bool:
        if mask.bit_count() <= 1:
            return True
        for graph in (adj, complement):
            parts = components(graph, mask)
            if len(parts) > 1:
                return all(solve(part) for part in parts)
        return False

    return solve(full)


def is_complete_split(adj: Graph, k: int) -> bool:
    n = len(adj)
    full = (1 << n) - 1
    for mask in split_partitions(adj):
        if mask.bit_count() == k and all((adj[v] & (full ^ mask)) == (full ^ mask) for v in vertices(mask)):
            return True
    return False


def benchmark(n: int, k: int | None = None) -> Q:
    if k is None:
        k = (3 * n + 2) // 4
    return Q(k * (n - k) * (k - 1)**2, n**2)


def block_law(sizes: tuple[int, ...], clique: tuple[bool, ...], edges: tuple[tuple[int, int], ...]) -> dict[int, Q]:
    adj = [0] * len(sizes)
    for i, j in edges:
        adj[i] |= 1 << j
        adj[j] |= 1 << i

    @lru_cache(None)
    def solve(mask: int) -> tuple[tuple[int, Q], ...]:
        if not mask:
            return ((0, Q(1)),)
        denominator = sum(sizes[v] for v in vertices(mask))
        result: dict[int, Q] = {}
        for v in vertices(mask):
            reward = 1 if clique[v] else sizes[v]
            weight = Q(sizes[v], denominator)
            for count, probability in solve(mask & ~(adj[v] | (1 << v))):
                result[count + reward] = result.get(count + reward, Q(0)) + weight * probability
        return tuple(sorted(result.items()))

    result = dict(solve((1 << len(sizes)) - 1))
    assert sum(result.values()) == 1
    return result


def blowup(sizes: tuple[int, ...], clique: tuple[bool, ...], edges: tuple[tuple[int, int], ...]) -> Graph:
    blocks: list[list[int]] = []
    start = 0
    for size in sizes:
        blocks.append(list(range(start, start + size)))
        start += size
    adj = [0] * start

    def edge(i: int, j: int) -> None:
        adj[i] |= 1 << j
        adj[j] |= 1 << i

    for i, block in enumerate(blocks):
        if clique[i]:
            for u, v in itertools.combinations(block, 2):
                edge(u, v)
    for i, j in edges:
        for u in blocks[i]:
            for v in blocks[j]:
                edge(u, v)
    return tuple(adj)


def law_moments(law: dict[int, Q]) -> tuple[Q, Q]:
    mu = sum((count * probability for count, probability in law.items()), Q(0))
    var = sum((count**2 * probability for count, probability in law.items()), Q(0)) - mu**2
    return mu, var


def path5_formula(a: int, b: int, s: int) -> dict[int, Q]:
    n = 2*a + b + 2*s
    p = Q(2*a*a, n*(a+s))
    q = Q(2*a*s, (a+s)*(a+b+s))
    law: dict[int, Q] = {}
    for count, probability in [(2, p), (s+1, q), (b+2*s, 1-p-q)]:
        law[count] = law.get(count, Q(0)) + probability
    return law


def brute_force_order_checks() -> tuple[int, int]:
    graph_count = order_count = 0
    for n in range(1, 5):
        edges = list(itertools.combinations(range(n), 2))
        for edge_mask in range(1 << len(edges)):
            adj = [0] * n
            for j, (u, v) in enumerate(edges):
                if edge_mask >> j & 1:
                    adj[u] |= 1 << v
                    adj[v] |= 1 << u
            counts = Counter()
            for permutation in itertools.permutations(range(n)):
                accepted = 0
                for v in permutation:
                    if not adj[v] & accepted:
                        accepted |= 1 << v
                counts[accepted.bit_count()] += 1
                order_count += 1
            total = sum(counts.values())
            assert moments(tuple(adj)) == law_moments({k: Q(v, total) for k, v in counts.items()})
            graph_count += 1
    return graph_count, order_count


def main() -> None:
    base = Path(__file__).resolve().parent
    data = base / 'atlas_through_7.g6'
    graphs = [read_graph6(line) for line in data.read_text().splitlines() if line]
    assert len(graphs) == 1252
    count_by_order: Counter[int] = Counter()
    splits = cographs = union = 0
    means_equal = variance_equal = 0
    atlas_max: dict[int, Q] = {}
    split_partition_checks = 0
    for adj in graphs:
        n = len(adj)
        count_by_order[n] += 1
        alpha = independence_number(adj)
        mu, var = moments(adj)
        parts = split_partitions(adj)
        cograph = is_cograph(adj)
        splits += bool(parts)
        cographs += cograph
        atlas_max[n] = max(atlas_max.get(n, Q(0)), var)
        for mask in parts:
            k = mask.bit_count()
            if k < 2:
                continue
            full = (1 << n) - 1
            r = [(full ^ mask).bit_count() - (adj[i] & (full ^ mask)).bit_count() for i in vertices(mask)]
            delta = mu - 1 - Q(k*(k-1), n)
            assert delta >= sum((Q(x*(x+1), n*(k-1+x)) for x in r), Q(0))
            assert delta >= Q(sum(r)**2, k*n*(n-1))
            split_partition_checks += 1
        if not (parts or cograph):
            continue
        union += 1
        lower = 1 + Q(alpha*(alpha-1), n)
        assert mu >= lower
        equality = mu == lower
        assert equality == is_complete_split(adj, alpha)
        means_equal += equality
        assert var <= benchmark(n)
        if n >= 3:
            assert (var == benchmark(n)) == is_complete_split(adj, (3*n+2)//4)
            variance_equal += var == benchmark(n)
    assert dict(sorted(count_by_order.items())) == {1: 1, 2: 2, 3: 4, 4: 11, 5: 34, 6: 156, 7: 1044}
    assert splits == 257 and cographs == 287 and union == 417
    for n, value in atlas_max.items():
        assert value == benchmark(n)

    permutation_graphs, permutation_orders = brute_force_order_checks()

    path_edges = ((0, 1), (1, 2), (2, 3), (3, 4))
    types = (False, True, False, True, False)
    grid_checks = 0
    for a, b, s in itertools.product(range(1, 5), range(1, 6), range(1, 5)):
        sizes = (s, a, b, a, s)
        law = block_law(sizes, types, path_edges)
        assert law == path5_formula(a, b, s)
        assert moments(blowup(sizes, types, path_edges)) == law_moments(law)
        grid_checks += 1

    for t in range(1, 101):
        law = block_law((t, 6*t, 34*t, 6*t, t), types, path_edges)
        mu, var = law_moments(law)
        assert mu == Q(7698*t+135, 287)
        assert var == Q(20155992*t*t-2071572*t+55821, 82369)
        gap = var - benchmark(48*t)
        assert gap == Q(3*(748400*t*t-5117816*t+215343), 1317904)
        assert (gap > 0) == (t >= 7)
        assert mu - (1 + Q(36*t*(36*t-1), 48*t)) == Q(253-204*t, 1148)
    # A vertex-level computation on the actual 336-vertex graph, independent
    # of the five-class calculation. Component/clique shortcuts keep it small.
    assert moments(blowup((7, 42, 238, 42, 7), types, path_edges)) == (Q(54021, 287), Q(973198425, 82369))

    for n in range(3, 1001):
        k = (3*n+2)//4
        values = [benchmark(n, j) for j in range(1, n+1)]
        assert max(values) == values[k-1]
        assert values.count(max(values)) == 1
        assert k > Q(n, 2)

    result = {
        'status': 'all exact checks passed',
        'atlas_sha256': hashlib.sha256(data.read_bytes()).hexdigest(),
        'atlas_nonempty_graphs': len(graphs),
        'atlas_counts_by_order': dict(sorted(count_by_order.items())),
        'split_graphs': splits,
        'cographs': cographs,
        'graphs_in_either_class': union,
        'split_partition_gap_checks': split_partition_checks,
        'mean_equality_cases_in_union': means_equal,
        'variance_equality_cases_n_ge_3_in_union': variance_equal,
        'all_graph_atlas_variance_maxima': {n: str(v) for n, v in sorted(atlas_max.items())},
        'brute_force_labeled_graphs': permutation_graphs,
        'brute_force_vertex_orders': permutation_orders,
        'path5_parameter_grid_checks': grid_checks,
        'path5_scale_checks': 100,
        'independent_vertex_level_counterexample_check_n': 336,
        'integer_maximizer_checked_through_n': 1000,
        'counterexample_n': 336,
        'counterexample_variance': str(Q(973198425, 82369)),
        'class_maximum_at_n_336': str(Q(189003, 16)),
        'counterexample_excess': str(Q(3186693, 1317904)),
        'unrestricted_asymptotic_lower_bound': str(Q(839833, 7907424)),
        'lower_bound_excess_over_27_over_256': str(Q(46775, 63259392)),
        'scope': 'Finite exact checks support the manuscript; they do not establish novelty or replace its proofs.'
    }
    (base / 'verification_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
