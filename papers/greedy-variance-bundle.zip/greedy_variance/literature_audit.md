# Literature and novelty audit

Date: October 15, 2026 (America/Los_Angeles).

**Assessment:** a candidate short research note with complete proofs. The exact extremum for split graphs and cographs, the split-graph stability consequence, and the five-part obstruction were not located in the sources checked. This is a bounded search, not proof of priority. No claim of acceptance, independent referee validation, or comprehensive literature clearance is made.

## Closely related sources checked

### Fixed-graph greedy acceptance and variance

- David Gamarnik and David A. Goldberg, *Randomized greedy algorithms for independent sets and matchings in regular graphs: Exact results and finite girth corrections*, Combinatorics, Probability and Computing 19 (2010), 61–85. [Author manuscript](https://people.orie.cornell.edu/dag369/ftp/Goldberg_Gamarnik_CPC2009.pdf), [arXiv](https://arxiv.org/abs/0807.1277). This studies means in regular graphs of large girth and concentration/variance under bounded degree. It is important background; the present dense-class finite-order extremum is a different question.
- Michael Krivelevich, Tamás Mészáros, Peleg Michaeli, and Clara Shikhelman, *Greedy maximal independent sets via local limits*, Random Structures & Algorithms 64 (2024), 986–1015. [Author manuscript](https://www.math.tau.ac.il/~krivelev/greedy_MIS.pdf), [publisher](https://doi.org/10.1002/rsa.21200). The checked text develops local-limit methods and exact mean extremality for trees. Its double-star example disproves monotonicity of the greedy mean under edge deletion. That observation is prior work and is not a contribution of this draft.
- Mubin Shaikh, *Variance of random greedy independent sets in triangle-free graphs*, September 2026 preprint. [arXiv](https://arxiv.org/abs/2609.14826), [full PDF](https://arxiv.org/pdf/2609.14826). The full six-page manuscript was read. It establishes `Var(X_G) <= e(G)((n-2)/n)^2` for triangle-free graphs, with equality for edgeless graphs and connected stars, and the exact tree maximum. Our graphs permit triangles and our objective fixes order rather than order and an edge-count bound. Our counterexample does not contradict this preprint.
- M. D. Penrose and A. Sudbury, *Exact and approximate results for deposition and annihilation processes on graphs*, Annals of Applied Probability 15 (2005), 853–889. [DOI](https://doi.org/10.1214/105051604000000765). Bibliographic information and model relationship were checked through the full related manuscript above. Direct DOI retrieval was unavailable in this session; this paper was not fully read.

### Graph classes and elementary tools

- D. G. Corneil, H. Lerchs, and L. Stewart Burlingham, *Complement reducible graphs*, Discrete Applied Mathematics 3 (1981), 163–174. [Publisher](https://www.sciencedirect.com/science/article/pii/0166218X81900135). The recursive structure and tree representation of cographs are standard background, not new claims here.
- R. Bhatia and C. Davis, *A better bound on the variance*, American Mathematical Monthly 107 (2000), 353–357. [DOI](https://doi.org/10.1080/00029890.2000.12005203). The bounded-variable inequality is standard. Direct full-text retrieval was unavailable; the draft proves the exact identity it uses instead of depending on an inaccessible argument. No novelty is claimed for this inequality.
- Lauren Keough and A. J. Radcliffe, *Extremal Threshold Graphs for Matchings and Independent Sets*, Graphs and Combinatorics 34 (2018), 1519–1537. [arXiv](https://arxiv.org/abs/1710.00083). The checked abstract concerns counts of matchings and independent sets, with order and edge count fixed. Those are different random objects and objectives from random-order greedy cardinality.

## Search scope

Queries included combinations and variants of:

- `random greedy independent set variance extremal graphs`
- `random greedy independent set threshold graphs`
- `random greedy split graphs`
- `random greedy cographs`
- `random order independent split graph`
- `random sequential adsorption cographs`
- `random sequential adsorption split graph`
- `random greedy independent 27/256`
- `greedy variance cographs`
- `maximal stable random split`

Broader searches also considered edge sensitivity and deletion monotonicity before the variance problem was selected. No exact match to the final extremal formula or counterexample was found. Search coverage can miss old terminology, non-indexed manuscripts, or unpublished results. MathSciNet and zbMATH were not systematically searched, and no specialist was contacted.

## Contribution boundaries

**Proved in this draft:** the sharp mean inequality and equality classification in the two classes; the exact variance maximum and unique extremizer; the quantitative missing-edge estimate and stability consequence; the five-part law and strict counterexample; existence of the unrestricted normalized-variance limit by independent blow-ups and isolated padding.

**Standard ingredients:** first-choice conditioning, uniform restricted orders, variance decomposition, a bounded-variable variance inequality, cograph union/join decomposition, and Cauchy–Schwarz.

**Not established:** novelty beyond this search, optimal unrestricted variance, optimality of the counterexample family, minimum counterexample size, or external referee agreement.

## Discovery and rejection record

1. Exact enumeration of small graphs suggested that a complete split graph might maximize variance even without class restrictions. All graphs through seven vertices supported that stronger guess.
2. A recursive calculation first made threshold graphs tractable. A sharper induction then proved the mean inequality for all split graphs; union/join algebra extended it to cographs.
3. The class-specific sharp mean bound plus the standard variance inequality yielded the exact extremal theorem.
4. Floating-point search over small templates with clique/independent vertex classes disproved the broader guess. Numerical search was used only to find a construction.
5. A symmetric five-class family was then selected for its simple exact law. The final counterexample and all quoted constants are proved algebraically and checked with rational arithmetic; no optimized numerical value is presented as an extremum.

The main research value is the combination of an exact theorem on two natural classes and a concrete obstruction to its generalization. It is stronger than a numerical observation, but publication suitability still needs expert review.
