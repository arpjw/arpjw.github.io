# Random greedy independent sets: an extremal theorem and its boundary

Arya Somu

This is a research proposition draft, with complete proofs and executable exact checks. It is not a submitted paper, an externally refereed result, or a certification of novelty.

## The problem

Given a fixed graph, inspect its vertices in uniformly random order. Accept a vertex if none of its neighbors has already been accepted. How variable can the final number of accepted vertices be?

## Results proved in the manuscript

1. **An exact maximum in two graph classes.** Among split graphs on `n >= 3` vertices, and separately among cographs, the unique variance maximizer consists of an independent set of size `k = floor((3n+2)/4)` completely joined to a clique of size `n-k`. The exact maximum is `k(n-k)(k-1)^2/n^2`.
2. **A sharp mean inequality.** In both classes, `E[X] >= 1 + alpha(alpha-1)/n`, with equality exactly for complete split graphs. This yields the variance theorem and an exact worst expected approximation ratio.
3. **Stability.** A sequence of split graphs whose variance approaches the maximum to leading order must differ from the extremal construction in only `o(n^2)` edges.
4. **A proved counterexample to generalization.** A five-part graph on `48t` vertices beats the split/cograph maximum whenever `t >= 7`. Thus a concrete 336-vertex example disproves extending the same maximum to all graphs.
5. **An unrestricted asymptotic observation.** The maximum normalized variance over all `n`-vertex graphs has a limit. It is at least `839833/7907424 = 0.1062081658...`, strictly exceeding the split/cograph limit `27/256 = 0.10546875`. The exact unrestricted limit is not determined here.

The counterexample uses class sizes `t, 6t, 34t, 6t, t` along a five-vertex path. The second and fourth classes are cliques; the others are independent. Consecutive classes are completely joined. The outcome has only three possible sizes, making its law and variance exactly calculable.

## Files

- `greedy_variance.pdf`: typeset manuscript.
- `greedy_variance.tex`: standalone editable source with all proofs and references.
- `verify.py`: verification program using only Python's standard library.
- `atlas_through_7.g6`: all 1,252 nonempty Graph Atlas graphs through seven vertices.
- `verification_results.json`: machine-readable results of the executed checks.
- `literature_audit.md`: checked sources, search scope, and novelty limits.

## Reproduce the checks

With Python 3.10 or later, run from this directory:

```sh
python3 verify.py
```

No network access or third-party Python packages are required. The program writes `verification_results.json` beside itself. A successful run reports `all exact checks passed`.

The executed checks cover all 1,252 nonempty atlas graphs; all 257 split graphs and 287 cographs among them, with equality classifications; 615 split-partition gap inequalities; all 1,589 vertex orders across the 75 labeled graphs of orders one through four; 80 five-part parameter choices; 100 scales of the counterexample; and the integer maximizer for orders three through 1,000. A separate vertex-level first-choice calculation on the actual 336-vertex graph agrees with the five-class formula.

These are exact rational calculations, not Monte Carlo estimates. They support the calculations and implementation; they do not replace the general proofs.

## Rebuild the paper

The LaTeX source compiled successfully with the Codex built-in compiler. A PDF was also exported with Tectonic. With Tectonic installed:

```sh
tectonic greedy_variance.tex
```

## Dataset provenance

`atlas_through_7.g6` was exported from NetworkX 3.7's `graph_atlas_g()`, omitting the empty graph. The documentation identifies the source as Read and Wilson, *An Atlas of Graphs*, Oxford University Press, 1998. The verifier itself does not depend on NetworkX.

[NetworkX Graph Atlas documentation](https://networkx.org/documentation/stable/reference/generated/networkx.generators.atlas.graph_atlas_g.html)

SHA-256: `ad68465d32eb7679a1ed8b0aa7a7f1da366da9b1ef8566b04664c504e8876255`.

## What remains before submission

The specific theorem and counterexample were derived in this session. The targeted literature search did not find the same statements, but a search failure cannot establish originality. A graph theorist's proof and prior-art review is the appropriate next step. The unrestricted extremum, the optimality of the five-part family, and the smallest counterexample order remain unresolved by this work.
