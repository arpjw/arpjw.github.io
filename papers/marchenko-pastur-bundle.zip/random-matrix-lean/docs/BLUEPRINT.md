# Marchenko-Pastur for independent fair signs

## Precise flagship target

Let p_m and n_m be positive integers with n_m tending to infinity and
p_m/n_m tending to gamma in (0, infinity). For each m, let X_m be uniform on
all p_m-by-n_m matrices with entries in {-1,+1}. Define

    S_m = X_m X_m^T / n_m,
    mu_m = (1/p_m) sum_i delta_(lambda_i(S_m)).

Prove weak convergence in probability of mu_m to the Marchenko-Pastur measure

    mu_gamma = max(1 - 1/gamma, 0) delta_0 + rho_gamma(x) dx,
    rho_gamma(x) = sqrt((b-x)(x-a)) / (2 pi gamma x),  a < x < b,
    a = (1-sqrt(gamma))^2,  b = (1+sqrt(gamma))^2,

with density zero elsewhere. For every bounded continuous f : R -> R and every
epsilon > 0, the uniform probability of

    |integral f d mu_m - integral f d mu_gamma| > epsilon

tends to zero. There is no assumption about joint dependence across different m;
convergence in probability here uses each finite ensemble separately.

This theorem is proved in `RandomMatrix.marchenkoPastur_theorem`.
See [WEAK_CONVERGENCE.md](WEAK_CONVERGENCE.md) for the final analytic argument.
It is a classical theorem, not a new mathematical claim or a claim of first
formalization. Beginning with signs is a substantive special case, not a proof
for all independent-entry distributions.

## Dependency graph and acceptance criteria

1. Finite probability and sign moments. Define uniform expectation over the
   actual finite cube. Prove factorization and parity cancellation for every
   coordinate exponent. No external random-number generator enters these proofs.
2. Finite covariance algebra. Define S and normalized trace moments, prove
   positivity and trace formulas, and evaluate the first two moments exactly.
3. All-order alternating-walk formula. Expand tr((XX^T)^k), group by partitions
   of row and column positions, and prove that precisely the even-edge patterns
   survive. This stage is complete for every k, including zero: the labeled
   expansion, partition grouping, falling-factorial label multiplicities, and
   dimension-independent coefficient formula are proved in Lean. The Python
   enumerator supplies independent finite checks.
4. Leading patterns. Prove r+c <= k+1 for surviving connected patterns. Identify
   equality with doubled bipartite trees and count them by Narayana numbers.
   The bound is now proved for all even walks and all surviving abstract
   patterns. Coefficients with r+c>k+1 vanish. The graph on quotient blocks is
   now proved connected and bipartite, with exact vertex and edge counts.
   A pattern is surviving and maximal exactly when it is closed, its graph is
   a tree, and every used entry occurs twice. A genuine graph walk retains
   the entry order and distinguished root. The rooted ordered tree bijection,
   both inverses, preservation of both color counts, and equality of the
   original leading coefficients with refined tree counts are now proved
   for every order. The Narayana formula and exact divisibility are now proved,
   completing this counting stage. The total leading-pattern count is Catalan.
5. Expected moments. Prove convergence for every fixed k to

       sum_(r=1)^k (1/k) choose(k,r) choose(k,r-1) gamma^(r-1).

   This stage is complete, including k=0 with limit 1. The finite-size bound
   compares to the polynomial at the current ratio p/n and is C_k(a,B)/n
   when 0<a<=p/n<=B and B>=1. The constant is explicit and independent of
   the dimensions. Ratio convergence then yields the limit at gamma without
   assuming a rate. See EXPECTED_MOMENTS.md.
6. Fluctuations. Expand the covariance of two trace moments. Disjoint-coordinate
   terms cancel, and the remaining overlap patterns yield a variance bound
   tending to zero. This stage is now complete: an explicit O(1/n) variance
   bound, finite Chebyshev bounds, vanishing mean-square error, and convergence
   in probability of every fixed random moment are proved. The upper-bound
   count includes jointly even pairs sharing a row, with closure dropped.
   See CONCENTRATION.md.
7. Spectral interface. Use Hermitian eigenvalues to define the empirical
   probability measure and connect its moments to normalized matrix traces.
   This stage is complete, including every moment order and multiplicities.
   Nonnegative topological support, exact zero mass equal to nullity/p, and
   the lower bound max(1-1/(p/n),0) are proved. Concentration is transferred to
   integrals against the actual empirical probability measure. See SPECTRAL_MEASURES.md.
8. Identify the target measure. Prove positivity, total mass, and the moment
   formula for the displayed density plus atom. This stage is complete for
   every gamma>0, including gamma=1: continuous mass min(1,1/gamma), exact zero
   atom, total mass one, all natural moments, and compact nonnegative support
   are proved. The empirical moment theorem is identified with moments of this
   explicit measure. See MP_DENSITY.md.
9. Moment-to-measure convergence. This stage is complete. The exact first
   moment gives the uniform deterministic tail bound mu_X([0,R]^c)<=1/R.
   Global polynomial upper and lower bounds approximate every bounded
   continuous test on the compact target support, with higher powers controlling
   the tails. Finite linear combinations of the moment-concentration results
   then prove weak convergence in probability. The same bounds prove compact
   moment determinacy, including uniqueness of the MP law from its moments.
   The final theorem applies this argument to the actual finite sign ensembles;
   spectral convergence is a conclusion, not a hypothesis. See WEAK_CONVERGENCE.md.

## Finite identities used as normalization checks

For every p,n > 0 and every sign matrix, the first normalized trace moment is 1.
The exact ensemble second moment is

    E[(1/p) tr(S^2)] = 1 + (p-1)/n = 1 + p/n - 1/n.

Thus the limiting second moment is 1+gamma, with finite bias exactly -1/n.
A further exact-computation target, not yet a Lean theorem, is

    E[(1/p) tr(S^3)] = 1 + 3(p-1)/n + (p-1)(p-2)/n^2.

When p > n the matrix has at least p-n zero eigenvalues. Simulations must keep
those zeros in the empirical measure, rather than renormalizing the nonzero
spectrum to total mass one. All finite moments in the project use 1/p for the
trace normalization and 1/n for the covariance normalization.

## Working order

Stages 1 through 9 are complete. `marchenkoPastur_theorem` connects the actual
finite independent-sign matrix ensemble to the explicit MP density plus atom
and proves the displayed weak convergence in probability. All natural moments,
normalization, the zero atom, uniform tightness, and moment determinacy are
proved as parts of the chain. No proof obligation remains for this flagship
scope. The additional finite third-moment formula above is an optional exact
identity, rather than a dependency of the completed limit theorem.

See [WALKS.md](WALKS.md), [PATTERNS.md](PATTERNS.md), [TREES.md](TREES.md),
[ORDERED_TREES.md](ORDERED_TREES.md), [NARAYANA.md](NARAYANA.md), and
[EXPECTED_MOMENTS.md](EXPECTED_MOMENTS.md), [CONCENTRATION.md](CONCENTRATION.md),
[SPECTRAL_MEASURES.md](SPECTRAL_MEASURES.md), [MP_DENSITY.md](MP_DENSITY.md), and
[WEAK_CONVERGENCE.md](WEAK_CONVERGENCE.md) for the complete proof chain.

## References

- Fleermann and Kirsch, *Proof Methods in Random Matrix Theory* (2022):
  https://arxiv.org/abs/2203.02551. Pedagogical reference for the moment-method route.
- The original Marchenko-Pastur theorem (1967) supplies the mathematical target;
  this project uses the unit-variance sample-covariance convention above.
- See PRIOR_ART.md for the pinned Lean sources inspected before implementation.
