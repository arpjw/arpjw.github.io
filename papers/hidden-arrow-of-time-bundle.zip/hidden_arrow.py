"""Uniform-window binary Markov sources and their observable time reversal.

Pure standard library. Natural logarithms, unless a function says bits.
The context-state chain's ordinary edge reversal is NOT the reversal used here:
the observable binary word is reversed, including the order inside each context.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import product
from math import atanh, fsum, log, log1p
from typing import Callable, Mapping


def words(length: int) -> list[str]:
    return ["".join(bits) for bits in product("01", repeat=length)]


def deficit(x: float) -> float:
    """ln(2) minus entropy of Bernoulli((1+x)/2), for -1 <= x <= 1."""
    x = abs(x)
    if x > 1:
        raise ValueError("bias must be in [-1, 1]")
    if x == 1:
        return log(2)
    return ((1 + x) * log1p(x) + (1 - x) * log1p(-x)) / 2


def inverse_deficit(value: float) -> float:
    """Nonnegative inverse; floating point is for exploration, not certificates."""
    if not 0 <= value <= log(2):
        raise ValueError("deficit must be in [0, ln(2)]")
    if value == 0:
        return 0.0
    if value == log(2):
        return 1.0
    low, high = 0.0, 1.0
    for _ in range(60):
        mid = (low + high) / 2
        if deficit(mid) < value:
            low = mid
        else:
            high = mid
    return (low + high) / 2


def opposite_pair_objective(x: float, y: float) -> float:
    """Jeffreys divergence of biases x and -y, without the 1/N weight."""
    return (x + y) * (atanh(x) + atanh(y))


def golden_maximum(function: Callable[[float], float], low: float, high: float) -> tuple[float, float]:
    """Local numerical refinement inside a previously sampled interval."""
    ratio = (5**0.5 - 1) / 2
    left = high - ratio * (high - low)
    right = low + ratio * (high - low)
    fleft, fright = function(left), function(right)
    for _ in range(65):
        if fleft > fright:
            high, right, fright = right, left, fleft
            left = high - ratio * (high - low)
            fleft = function(left)
        else:
            low, left, fleft = left, right, fright
            right = low + ratio * (high - low)
            fright = function(right)
    candidates = [(low, function(low)), (high, function(high)), (left, fleft), (right, fright)]
    return max(candidates, key=lambda item: item[1])


def numerical_envelope(budget: float, grid: int = 800) -> dict[str, float]:
    """Explore the exact one-dimensional variational formula.

    The sampled/refined value is a numerical lower bound, not a certified
    global maximum. The mathematical reduction itself is proved in the note.
    """
    if not 0 < budget < log(2):
        raise ValueError("use a budget strictly between zero and ln(2)")

    def evaluate(allocation: float) -> float:
        return opposite_pair_objective(
            inverse_deficit(allocation), inverse_deficit(budget - allocation)
        )

    points = [budget / 2 + budget * i / (2 * grid) for i in range(grid + 1)]
    points[0], points[-1] = budget / 2, budget
    values = [evaluate(point) for point in points]
    candidates = [(points[0], values[0]), (points[-1], values[-1])]
    # Near the singular threshold, an interior maximum can lie much closer
    # to the endpoint than the uniform mesh spacing.
    candidates.append(golden_maximum(evaluate, points[-2], points[-1]))
    for i in range(1, grid):
        if values[i] >= values[i - 1] and values[i] >= values[i + 1]:
            candidates.append(golden_maximum(evaluate, points[i - 1], points[i + 1]))
    allocation, value = max(candidates, key=lambda item: item[1])
    symmetric = inverse_deficit(budget / 2)
    return {
        "budget_nats": budget,
        "budget_over_ln2": budget / log(2),
        "x": inverse_deficit(allocation),
        "y": inverse_deficit(budget - allocation),
        "objective": value,
        "symmetric_objective": opposite_pair_objective(symmetric, symmetric),
    }


class Source:
    """A stationary order-at-most-k source with exactly uniform k-bit windows."""

    def __init__(self, k: int, biases: Mapping[str, Fraction]):
        if k < 1:
            raise ValueError("k must be positive")
        if any(len(word) != k - 1 or set(word) - {"0", "1"} for word in biases):
            raise ValueError("bias keys must be binary words of length k-1")
        self.k = k
        self.ncontexts = 2 ** (k - 1)
        self.biases = {word: Fraction(biases.get(word, 0)) for word in words(k - 1)}
        if any(abs(value) >= 1 for value in self.biases.values()):
            raise ValueError("strict positivity requires all biases in (-1, 1)")

    def transition(self, context: str, bit: str) -> Fraction:
        if len(context) != self.k or bit not in ("0", "1"):
            raise ValueError("invalid context or bit")
        sign = 1 if context[0] == bit else -1
        return (1 + sign * self.biases[context[1:]]) / 2

    def probability(self, word: str) -> Fraction:
        if set(word) - {"0", "1"}:
            raise ValueError("word must be binary")
        if len(word) <= self.k:
            return Fraction(1, 2 ** len(word))
        value = Fraction(1, 2**self.k)
        for index in range(self.k, len(word)):
            value *= self.transition(word[index - self.k : index], word[index])
        return value

    def reverse(self) -> Source:
        return Source(self.k, {word: self.biases[word[::-1]] for word in self.biases})

    def entropy_rate_bits(self) -> float:
        return 1 - fsum(deficit(float(x)) for x in self.biases.values()) / (
            self.ncontexts * log(2)
        )

    def arrow_rate(self) -> float:
        # Pair each u with its reversal once. This expression has no cancellation.
        return fsum(
            (float(x) - float(self.biases[word[::-1]]))
            * (atanh(float(x)) - atanh(float(self.biases[word[::-1]])))
            for word, x in self.biases.items()
            if word < word[::-1]
        ) / self.ncontexts

    def finite_total_variation(self, length: int) -> Fraction:
        return sum(
            (abs(self.probability(word) - self.probability(word[::-1])) for word in words(length)),
            Fraction(),
        ) / 2
