"""Reproducible numerical exploration. Results are labeled, not proof claims."""

from __future__ import annotations

import csv
import json
from math import atanh, log
from pathlib import Path
from random import Random

from hidden_arrow import deficit, inverse_deficit, numerical_envelope, opposite_pair_objective


def main() -> None:
    out = Path("results")
    out.mkdir(exist_ok=True)
    ratios = sorted(set(
        [i / 100 for i in range(1, 95)]
        + [0.95 + i / 100000 for i in range(0, 1001, 5)]
        + [0.961 + i / 1000 for i in range(39)]
        + [0.999, 0.9999, 0.99999]
    ))
    rows = [numerical_envelope(ratio * log(2), grid=500) for ratio in ratios]
    with (out / "envelope.csv").open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    lo, hi = 0.7, 0.9
    for _ in range(60):
        a = (lo + hi) / 2
        if (3 * a * a - 1) * atanh(a) < a:
            lo = a
        else:
            hi = a
    local_a = (lo + hi) / 2

    # This estimates a crossing of the computed branches. It is not a proof
    # that there are exactly two competing branches or one global transition.
    lo, hi = 0.95705, 0.95715
    for _ in range(25):
        mid = (lo + hi) / 2
        result = numerical_envelope(mid * log(2), grid=1000)
        if result["objective"] - result["symmetric_objective"] > 1e-11:
            hi = mid
        else:
            lo = mid
    crossing = numerical_envelope(hi * log(2), grid=2000)

    # Adversarial multi-pair check of the concentration theorem. Each
    # generated configuration is compared with a feasible concentrated
    # construction: scale its best ratio pair to the total cost.
    rng = Random(314159)
    minimum_gap = float("inf")
    trials = 5000
    for _ in range(trials):
        count = rng.randint(2, 16)
        pairs = [(rng.random(), rng.random()) for _ in range(count)]
        target = rng.uniform(0.0001, 0.999) * log(2)
        low, high = 0.0, 1.0
        for _ in range(60):
            scale = (low + high) / 2
            cost = sum(deficit(scale * x) + deficit(scale * y) for x, y in pairs)
            if cost < target:
                low = scale
            else:
                high = scale
        pairs = [(low * x, low * y) for x, y in pairs]
        costs = [deficit(x) + deficit(y) for x, y in pairs]
        total = sum(costs)
        old_value = sum(opposite_pair_objective(x, y) for x, y in pairs)
        best = max(range(count), key=lambda j: opposite_pair_objective(*pairs[j]) / costs[j])
        x, y = pairs[best]
        low, high = 1.0, 1.0 / max(x, y)
        for _ in range(60):
            scale = (low + high) / 2
            if deficit(min(scale * x, 1)) + deficit(min(scale * y, 1)) < total:
                low = scale
            else:
                high = scale
        gap = opposite_pair_objective(low * x, low * y) - old_value
        if gap < -1e-10:
            raise AssertionError("numerical concentration counterexample")
        minimum_gap = min(minimum_gap, gap)

    result = {
        "status": "exploratory floating-point evidence; not a global optimizer certificate",
        "envelope_rows": len(rows),
        "estimated_global_crossing_budget_over_ln2": crossing["budget_over_ln2"],
        "crossing_candidate": crossing,
        "local_stability_loss": {
            "bias": local_a,
            "budget_nats": 2 * deficit(local_a),
            "budget_over_ln2": 2 * deficit(local_a) / log(2),
        },
        "concentration_stress_trials": trials,
        "minimum_concentration_improvement": minimum_gap,
        "open": "Global uniqueness and exact location of the symmetry-breaking transition are not proved.",
    }
    (out / "exploration.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
