# A hidden arrow of time in fair-looking coin flips

Arya Somu · Research draft · Website edition, 16 October 2026

A stationary process can have exactly fair 20-flip windows and entropy above 0.999998 bits per flip, yet arbitrarily large time-reversal relative-entropy rate. A classifier given 1,000 flips can still succeed at most 50.0934601% of the time. Rare events with extreme likelihood ratios explain the distinction.

The main paper proves a sharp entropy threshold and reduces the subcritical optimum to a scalar problem. The continuations establish optimizer uniqueness, constraints on transition noise, approximate fairness, larger alphabets, and nonuniform symbol frequencies. The final supplement certifies a discontinuous transition for a 40/60 coin in the budget interval (0.2874097, 0.2874098).

The underlying locally uniform construction is known prior art. These are mathematical research drafts, with written proofs and exact computational certificates where stated. They have not received independent expert review, and novelty remains unconfirmed. Numerical exploration is explicitly distinct from proof evidence. The complete biased-coin phase diagram remains open; the 40/60 uniqueness certificate covers the stated budget bracket.

## Read

- `output/pdf/hidden_arrow.pdf`: main ten-page paper.
- `output/pdf/finite_bias_transition.pdf`: final four-page 40/60 transition supplement.
- `hidden_arrow.tex` and `continuation/finite_bias_transition.tex`: editable sources for those PDFs.
- `continuation/001_*.md` through `continuation/019_*.md`: full sequence of supporting mathematical notes.
- `LITERATURE.md`: sources and the limits of the prior-art assessment.
- `results/`: exact certificates, recorded checks, and separately labeled numerical diagnostics.
- `MANIFEST.json`: SHA-256 hashes of the files in this download, excluding the manifest itself.

The public edition replaces the former author credit with Arya Somu in the two PDFs. Their mathematical text is unchanged. `results/website_author_edition.json` records that comparison and the original and replacement hashes. The original research archives are preserved privately.

## Reproduce

Unzip the download and run commands from its root directory. Python 3.10 or later suffices for the checks below; no third-party Python packages are required. Some complete interval certificates take several minutes. The scripts write their receipts into `results/`, replacing the corresponding saved output.

```sh
# Main paper: exact rational checks and asymmetric witness
python3 verify_exact.py

# Fair-coin transition, optimizer uniqueness, and jump
python3 continuation/verify_intervals.py
python3 continuation/branch_certificate.py --transition
python3 continuation/uniqueness_certificate.py
python3 continuation/audit_uniqueness.py
python3 continuation/jump_certificate.py

# Global context allocation, small-bias persistence, and the 40/60 certificate
python3 continuation/global_concentration.py
python3 continuation/biased_transition_persistence.py
python3 continuation/finite_bias_transition.py
```

Each continuation note describes its further checks and their evidentiary scope. `continuation/intervals.py` implements the outward-rounded integer intervals. The saved `results/memory_coefficient.json` includes LP witnesses that can be verified without a numerical optimizer. Scripts named `explore*` and stress checks are exploratory evidence, not universal proof.

Optional PDF compilation uses a local Tectonic installation:

```sh
tectonic --outdir output/pdf hidden_arrow.tex
python3 continuation/build_finite_bias_document.py
tectonic --outdir output/pdf continuation/finite_bias_transition.tex
```

The download contains the two published PDFs, their sources, all nineteen mathematical continuation notes, scientific Python code, and research receipts. It omits operational notes, historical checkpoint ZIPs, and intermediate PDF builds. This packaging does not strengthen any mathematical or novelty claim.
