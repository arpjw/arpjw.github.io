"""Exact rational verification and rational-series inequality certificates.

Run: python3 verify_exact.py
No third-party dependencies. Enumeration checks finite instances; general
theorems are supported by the written proofs, not by these finite checks.
"""

from __future__ import annotations

import json
import random
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

from hidden_arrow import Source, words


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


@lru_cache(maxsize=None)
def factor(value: int) -> tuple[tuple[int, int], ...]:
    factors = []
    divisor = 2
    while divisor * divisor <= value:
        exponent = 0
        while value % divisor == 0:
            value //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor += 1
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def add_log(target: dict[int, F], coefficient: F, value: F) -> None:
    for prime, exponent in factor(value.numerator):
        target[prime] += coefficient * exponent
    for prime, exponent in factor(value.denominator):
        target[prime] -= coefficient * exponent


def clean(signature: dict[int, F]) -> dict[int, F]:
    return {prime: value for prime, value in signature.items() if value}


def arrow_signature(source: Source, length: int) -> dict[int, F]:
    result: dict[int, F] = defaultdict(F)
    for word in words(length):
        p, q = source.probability(word), source.probability(word[::-1])
        add_log(result, p, p / q)
    return clean(result)


def entropy_signature(source: Source, length: int) -> dict[int, F]:
    result: dict[int, F] = defaultdict(F)
    for word in words(length):
        p = source.probability(word)
        add_log(result, -p, p)
    return clean(result)


def conditional_arrow_signature(source: Source) -> dict[int, F]:
    result: dict[int, F] = defaultdict(F)
    for word, x in source.biases.items():
        y = source.biases[word[::-1]]
        for sign in (-1, 1):
            p, q = (1 + sign * x) / 2, (1 + sign * y) / 2
            add_log(result, p / source.ncontexts, p / q)
    return clean(result)


def conditional_entropy_signature(source: Source) -> dict[int, F]:
    result: dict[int, F] = defaultdict(F)
    for x in source.biases.values():
        for sign in (-1, 1):
            p = (1 + sign * x) / 2
            add_log(result, -p / source.ncontexts, p)
    return clean(result)


def decimal(value: F) -> str:
    with localcontext() as context:
        context.prec = 28
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def atanh_interval(x: F, terms: int = 180) -> tuple[F, F]:
    require(0 <= x < 1, "atanh certificate domain")
    total = sum((x ** (2 * j + 1) / (2 * j + 1) for j in range(terms)), F())
    tail = x ** (2 * terms + 1) / ((2 * terms + 1) * (1 - x * x))
    return total, total + tail


def deficit_interval(x: F, terms: int = 180) -> tuple[F, F]:
    require(0 <= x < 1, "deficit certificate domain")
    total = sum((x ** (2 * j) / (2 * j * (2 * j - 1)) for j in range(1, terms + 1)), F())
    tail = x ** (2 * terms + 2) / ((2 * terms + 2) * (2 * terms + 1) * (1 - x * x))
    return total, total + tail


def certify_asymmetry() -> dict:
    x, y = F(91, 100), F(27, 50)
    a_low, a_high = F(7655109204, 10**10), F(7655109205, 10**10)
    dx, dy = deficit_interval(x), deficit_interval(y)
    r_low, r_high = dx[0] + dy[0], dx[1] + dy[1]
    require(2 * deficit_interval(a_low)[1] < r_low, "lower inverse bracket")
    require(r_high < 2 * deficit_interval(a_high)[0], "upper inverse bracket")
    ax, ay = atanh_interval(x), atanh_interval(y)
    asymmetric_low = (x + y) * (ax[0] + ay[0])
    asymmetric_high = (x + y) * (ax[1] + ay[1])
    symmetric_low = 4 * a_low * atanh_interval(a_low)[0]
    symmetric_high = 4 * a_high * atanh_interval(a_high)[1]
    gap_low = asymmetric_low - symmetric_high
    gap_high = asymmetric_high - symmetric_low
    stability_upper = (3 * a_high * a_high - 1) * atanh_interval(a_high)[1] - a_low
    require(gap_low > F(12999, 10**8), "strict counterexample gap > 0.00012999")
    require(stability_upper < F(-3697, 10**7), "strict local maximum at symmetric point")
    return {
        "status": "certified by rational arithmetic and positive series remainders",
        "x": str(x), "y": str(y),
        "symmetric_bias_bracket": [str(a_low), str(a_high)],
        "budget_nats_interval": [decimal(r_low), decimal(r_high)],
        "objective_gap_interval": [decimal(gap_low), decimal(gap_high)],
        "local_stability_expression_upper_bound": decimal(stability_upper),
        "series_terms": 180,
    }


def main() -> None:
    checks = 0
    rng = random.Random(271828)
    sources = [Source(3, {"01": F(91, 100), "10": F(-27, 50)})]
    for k in range(1, 6):
        for _ in range(4):
            sources.append(Source(k, {word: F(rng.randrange(-4, 5), 5) for word in words(k - 1)}))
    for source in sources:
        k = source.k
        for context in words(k):
            require(sum((source.transition(context, bit) for bit in "01"), F()) == 1, "row normalization")
            incoming = sum((source.transition(bit + context[:-1], context[-1]) for bit in "01"), F())
            require(incoming == 1, "uniform stationary distribution")
            checks += 2
        reverse = source.reverse()
        rate = conditional_arrow_signature(source)
        entropy = conditional_entropy_signature(source)
        for length in range(k, k + 5):
            distribution = {word: source.probability(word) for word in words(length)}
            require(sum(distribution.values(), F()) == 1, "path normalization")
            for word, p in distribution.items():
                require(reverse.probability(word[::-1]) == p, "observable reversal")
                checks += 1
            require(arrow_signature(source, length) == clean({p: (length - k) * c for p, c in rate.items()}), "exact path divergence identity")
            expected: dict[int, F] = defaultdict(F, {p: (length - k) * c for p, c in entropy.items()})
            expected[2] += k
            require(entropy_signature(source, length) == clean(expected), "exact path entropy identity")
            checks += 3
        for length in range(1, k + 1):
            marginal: dict[str, F] = defaultdict(F)
            for word in words(k + 1):
                marginal[word[:length]] += source.probability(word)
            require(all(value == F(1, 2**length) for value in marginal.values()), "exact uniform short blocks")
            checks += 1
        if k <= 2:
            require(not rate, "low-order reversibility")
            checks += 1

    for k in range(3, 7):
        word = "0" * (k - 2) + "1"
        x, y = F(9, 10), F(1, 3)
        source = Source(k, {word: x, word[::-1]: -y})
        require(source.finite_total_variation(k + 1) == (x + y) / source.ncontexts, "exact first-visible TV")
        for length in range(k + 1, k + 4):
            require(source.finite_total_variation(length) <= (length - k) * (x + y) / source.ncontexts, "path TV bound")
            checks += 1
        checks += 1

    report = {
        "status": "PASS",
        "verification_scope": "Finite exact identities plus a rigorous rational counterexample certificate; not a formal proof assistant.",
        "sources_checked": len(sources),
        "exact_checks": checks,
        "logarithms_verified_as": "rational coefficient vectors of log(prime), without floating point",
        "asymmetry_certificate": certify_asymmetry(),
    }
    path = Path("results/exact_verification.json")
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
