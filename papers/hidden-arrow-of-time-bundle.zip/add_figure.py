"""Embed reproducible vector plots into the standalone LaTeX document."""

import csv
from pathlib import Path

from hidden_arrow import deficit, inverse_deficit, opposite_pair_objective


def path(points: list[tuple[float, float]]) -> str:
    return " -- ".join(f"({x:.6f},{y:.6f})" for x, y in points)


rows = list(csv.DictReader(Path("results/envelope.csv").open()))
selected = [row for row in rows if 0.94 <= float(row["budget_over_ln2"]) <= 0.98]
upper, lower = [], []
for row in selected:
    x = (float(row["budget_over_ln2"]) - 0.94) / 0.04 * 5.4
    upper.append((x, 3.5 * float(row["x"])))
    lower.append((x, 3.5 * float(row["y"])))

r = deficit(.91) + deficit(.54)
z = inverse_deficit(r / 2)
baseline = opposite_pair_objective(z, z)
landscape = []
for index in range(161):
    allocation = .5 + .32 * index / 160
    value = opposite_pair_objective(inverse_deficit(r * allocation), inverse_deficit(r * (1 - allocation)))
    landscape.append((5.4 * index / 160, 1.85 * ((value - baseline) * 1e4 + .25)))
witness_allocation = deficit(.91) / r
witness_point = ((witness_allocation - .5) / .32 * 5.4, 1.85 * ((opposite_pair_objective(.91, .54) - baseline) * 1e4 + .25))

figure = r"""\begin{figure}[htbp]
\centering
\begin{tikzpicture}[font=\scriptsize]
\begin{scope}
\draw[->,ink] (0,0) -- (5.7,0);
\draw[->,ink] (0,0) -- (0,3.9);
\node[anchor=west,font=\small\bfseries] at (0,4.25) {A. The optimizing biases separate};
\node[below] at (2.7,-.45) {Normalized budget $r/\log 2$};
\node[rotate=90] at (-.65,1.9) {Bias magnitude};
\foreach \x/\label in {0/0.94,1.35/0.95,2.7/0.96,4.05/0.97,5.4/0.98}
 {\draw (\x,0)--(\x,-.07) node[below]{\label};}
\foreach \y/\label in {0/0,1.75/0.5,3.5/1.0}
 {\draw (0,\y)--(-.07,\y) node[left]{\label};}
\draw[accent,thick] UPPER;
\draw[warm,thick] LOWER;
\node[accent,right] at (4.7,3.45) {$x$};
\node[warm,right] at (4.7,.8) {$y$};
\node[align=center] at (1.2,1.3) {Numerical branch\\search, not a\\global certificate};
\end{scope}
\begin{scope}[xshift=7.3cm]
\draw[->,ink] (0,0) -- (5.7,0);
\draw[->,ink] (0,0) -- (0,3.9);
\node[anchor=west,font=\small\bfseries] at (0,4.25) {B. Stable locally, beaten globally};
\draw[gray,dashed] (0,.4625)--(5.4,.4625);
\node[below] at (2.7,-.45) {Budget fraction assigned to $x$};
\node[rotate=90] at (-.7,1.9) {$10^4[J(x,y)-J(z,z)]$};
\foreach \x/\label in {0/0.50,1.6875/0.60,3.375/0.70,5.0625/0.80}
 {\draw (\x,0)--(\x,-.07) node[below]{\label};}
\foreach \y/\label in {.4625/0,1.3875/0.5,2.3125/1.0,3.2375/1.5}
 {\draw (0,\y)--(-.07,\y) node[left]{\label};}
\draw[ink,thick] LANDSCAPE;
\fill[warm] WITNESS circle (2.2pt);
\node[anchor=east,align=right] at (4.3,3.65) {Exact witness:\\$x=0.91$, $y=0.54$};
\node[anchor=west] at (.2,.9) {Symmetric local maximum};
\draw[->,gray] (1.6,.8)--(.05,.48);
\end{scope}
\end{tikzpicture}
\caption{Left: the scalar optimization's numerical candidates show an abrupt
separation of the two magnitudes. Right: at the rational witness budget,
small deviations from equal allocation lower the objective, but a larger
deviation improves it. The marked witness and local stability are
certified with rational bounds in Proposition~\ref{prop:certificate};
the plotted curves themselves use floating point.}
\end{figure}"""
figure = figure.replace("UPPER", path(upper)).replace("LOWER", path(lower))
figure = figure.replace("LANDSCAPE", path(landscape)).replace("WITNESS", f"({witness_point[0]:.6f},{witness_point[1]:.6f})")
source = Path("hidden_arrow.tex")
text = source.read_text()
begin, end = "% BEGIN_GENERATED_FIGURE", "% END_GENERATED_FIGURE"
block = begin + "\n" + figure + "\n" + end
if begin in text:
    start = text.index(begin)
    finish = text.index(end, start) + len(end)
    text = text[:start] + block + text[finish:]
else:
    text = text.replace("% EXPLORATION_FIGURE", block)
source.write_text(text)
print("Embedded vector figure into standalone source")
