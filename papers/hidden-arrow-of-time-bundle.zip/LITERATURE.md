# Literature and novelty audit

This is a focused search, not a comprehensive literature review or proof of priority. Source material supports the nearby-work descriptions below. The new mathematical claims in the note rest on its written derivations, not on absence of search results.

## Closest foundations

1. **B. Ya. Ryabko and V. A. Monarev, “Using information theory approach to randomness testing,” Journal of Statistical Planning and Inference 133 (2005), 95–110.**
   - [DOI](https://doi.org/10.1016/j.jspi.2004.02.010)
   - [Author-hosted paper](https://boris.ryabko.net/published.pdf)
   - Read the relevant Section 3.3, Theorem 3, and surrounding discussion. It constructs finite-memory processes with uniform short blocks and smaller entropy rate. We explicitly credit this phenomenon and do not claim it as novel.
   - The examples inspected have a particular recursive structure. The present note parameterizes the whole positive binary class with uniform k-blocks, then optimizes observable time reversal under an entropy budget.

2. **Louise Kimpton, Peter Challenor, Henry Wynn, “Binary De Bruijn Processes.”**
   - [arXiv:2211.16921](https://arxiv.org/abs/2211.16921)
   - Inspected the abstract and accessed the full paper. It gives the de Bruijn representation of finite-memory binary chains and develops inference and applications. This is relevant construction background; it is not evidence that the extremal problem here is new.

3. **Lluís Arola-Fernández and Lucas Lacasa, “Irreversibility of symbolic time series: a cautionary tale,” Physical Review E 108 (2023), 014201.**
   - [DOI](https://doi.org/10.1103/PhysRevE.108.014201)
   - [arXiv:2303.11868](https://arxiv.org/abs/2303.11868)
   - Read the definitions, nonpalindromic-pair discussion, and no-go argument for words shorter than four. The present note's low-order obstruction and discussion of reversal should be understood in this established context.

## Nearby extremal work

4. **Igal Sason, “Tight Bounds for Symmetric Divergence Measures and a Refined Bound for Lossless Source Coding.”**
   - [arXiv:1403.7164](https://arxiv.org/abs/1403.7164)
   - [Author-hosted paper](https://webee.technion.ac.il/people/sason/symmetric_divergence_measures.pdf)
   - Inspected the abstract and retrieved the result/proof excerpts on Jeffreys divergence and total variation. The constrained quantities differ from the total binary entropy deficit used here. This is close enough that a broader novelty review should follow its references, particularly Gilardoni's divergence extremal results.

5. **Manuel Santos Gutiérrez, Niccolo Zagli, Giulia Carigi, “Markov matrix perturbations to optimize dynamical and entropy functionals.”**
   - [arXiv:2507.14040](https://arxiv.org/abs/2507.14040)
   - Inspected the primary-source abstract. This work develops perturbative optimization of Markov entropy and related functionals. It is relevant adjacent work, but the abstract does not settle the global constrained problem in this note. No secondary automated review was used as evidence.

## Search coverage

### Continuation update: rare events and distinguishability

6. **Edward H. Feng and Gavin E. Crooks, “Length of Time's Arrow,” Physical Review Letters 101 (2008), 090602.**
   - [Author-hosted paper](https://threeplusone.com/pubs/Feng2008a.pdf)
   - [DOI](https://doi.org/10.1103/PhysRevLett.101.090602)
   - Read the full four-page paper, especially its rare-event example and comparison of Jeffreys and Jensen-Shannon divergences. The qualitative distinction between large average likelihood-ratio evidence and weak practical direction distinguishability is established prior art. It must not be presented as a new general discovery here.
   - Our locally uniform binary construction and explicit finite-window classifier bound give a particular constrained realization. The exact extremal frontier remains the candidate contribution, subject to wider review.

Additional continuation searches included the constants `0.765578541`, `0.95707205`, and `0.117210729`, and combined Jeffreys-divergence, entropy, and symmetry-breaking queries. No exact match appeared in the returned results. Absence of a search hit provides no proof of novelty.

Search families included:

- Binary stationary processes, short-word irreversibility, de Bruijn entropy production.
- Two-faced processes and time reversal.
- Jeffreys divergence under fixed entropy, entropy constraints, or an entropy budget.
- Uniform-block Markov sources and maximum time-reversal divergence.
- Symmetry breaking in binary symmetric divergence optimization.

No exact match was identified for the conjunction of:

1. Exactly uniform k-blocks and strictly positive order-at-most-k kernels.
2. A lower bound on entropy rate.
3. Global maximization of observable time-reversal relative-entropy rate.
4. The one-pair concentration theorem, sharp divergence threshold, and stable-but-suboptimal symmetric witness.

This does **not** establish originality. The appropriate claim is: “derived and proved in this research notebook; candidate novelty pending broader literature review and independent mathematical review.”

## Potentially useful next checks

- General inequalities maximizing Bernoulli Jeffreys divergence at fixed sum of entropies.
- Extremal stochastic processes with prescribed finite-block laws.
- Known monotonicity and superadditivity results for power-series quotient envelopes.
- Existing metastability or symmetry-breaking analyses for binary divergence frontiers.

The continuations now prove uniqueness of the global transition and unequal optimizer, certify the transition and jump, and reduce the joint entropy-and-noise frontier at every positive noise floor to saturated pairs and one scalar choice. Continuations 5 and 6 add a floor-preserving projection for approximate uniformity and a sharp leading asymptotic for the order-three singular threshold. Continuation 7 determines that threshold exactly for `0<tau<=1/10000` and proves uniqueness of the critical boundary construction. The exact symmetry-breaking transition in closed form, the stronger one-fold claim for the whole stationary curve, the threshold at larger tolerances, and larger-memory perturbation coefficients remain unresolved. These additional derivations do not change the unconfirmed novelty status.

## Continuation update: entropy continuity and approximate fairness

7. **Mohammad A. Alhejji and Graeme Smith, “A Tight Uniform Continuity Bound for Equivocation,” IEEE ISIT (2020), 2270–2274.**
   - [arXiv:1909.00787](https://arxiv.org/abs/1909.00787)
   - [DOI](https://doi.org/10.1109/ISIT44484.2020.9174350)
   - Read the primary-source main result and proof. It gives a tight total-variation continuity bound for conditional Shannon entropy, independent of the conditioning alphabet's size. For binary outcomes the bound is binary entropy of the total-variation distance, and therefore has the familiar `tau log(1/tau)` scale near zero.
   - That general scale is not a new discovery here. Continuation 6 instead derives the specific singular time-reversal threshold under stationary three-word constraints, including the sharp coefficient `3/4`. Continuation 5's projection gives a one-sided linear entropy comparison because it changes the source in a particular favorable direction; it is not a stronger general two-sided conditional-entropy continuity theorem.

Focused searches combined conditional entropy continuity, Markov perturbations, uniform word distributions, de Bruijn processes, and time reversal. They did not establish priority for the new threshold coefficient. The mathematical proofs above are self-contained; the source is cited to keep the general entropy mechanism separate from the candidate contribution.

## Longer-memory continuation: stationary marginal polytopes

A focused follow-up search for stationary word-frequency polytopes found established background that should not be presented as a new contribution:

- J.-R. Chazottes, J.-M. Gambaudo, M. Hochman, and E. Ugalde, *On the finite-dimensional marginals of shift-invariant measures*, [arXiv:1011.2442](https://arxiv.org/abs/1011.2442), version 2. The primary PDF was inspected, especially Theorems 1 and 2 on page 3 and their dimension-one proofs on pages 7-9. Locally invariant marginal laws form rational polytopes, and in dimension one their extreme points come from periodic orbit measures.
- S. Goldstein, T. Kuna, J. L. Lebowitz, and E. R. Speer, *Translation invariant extensions of finite volume measures*, [arXiv:1508.04448](https://arxiv.org/abs/1508.04448). The primary abstract was inspected. It describes locally translation-invariant extensions, maximal-entropy extensions, and periodic configurations studied using de Bruijn graphs. Its full proof was not reviewed here.

Continuation 9's graph description, periodic-law constructions, and generic linear-program duality use this established setting. The candidate contribution is the connection to the singular time-reversal threshold, its explicit coefficient and bounds, and the exact finite-memory parity pattern. The proposed formula for arbitrary memory remains unproved. This focused search is not a novelty or priority determination.


## All-memory parity continuation

Continuation 10 resolves the coefficient conjecture within this draft, using a self-contained graph-cycle and finite-word-overlap argument plus 494 exact finite-base certificates. This is a new derivation in the notebook, not a verified claim of priority. No further literature conclusion is inferred from having found a proof. The stationary-flow polytope and periodic-cycle background remain established prior art, as described above.


## Selected-source continuation

Continuation 11 identifies the eventual exact critical source at every fixed memory and computes the next two threshold coefficients. The proof uses the earlier cycle dual, its equality cases, standard convexity, and finite rational certificates. This is an additional derivation in the notebook, not a new novelty search or a priority claim. The larger-memory validity cutoff and subsequent phase diagram remain unresolved. Earlier paragraphs describing larger-memory coefficients as open are historical; Continuations 10 and 11 resolve those coefficients within this draft.


## Quantitative-cutoff continuation

Continuation 12 supplies an explicit positive interval for the selected source at every memory, with a sharper finite certificate at memory four. Its cycle decomposition and rational denominator argument are elementary graph and convex geometry; no priority claim is made for those ingredients. The quantitative application strengthens this notebook's theorem. It is not a fresh literature search, and neither the conservative cutoff nor the recovered finite LP values establish novelty.


## Larger-alphabet continuation

- Mishel George, Saber Jafarpour, and Francesco Bullo, *Markov Chains with Maximum Entropy for Robotic Surveillance*, [author-hosted primary paper](https://motion.me.ucsb.edu/pdf/2017b-gjb.pdf). Inspected the abstract, introduction, and Theorem 6 on PDF page 8. It studies entropy maximization with prescribed stationary distributions and graph constraints. The inspected theorem assumes a symmetric irreducible adjacency matrix with all self-loops; its optimum is reversible. Our single directed missing transition has asymmetric support, so that theorem does not directly state the present construction. This is a scope distinction, not a novelty conclusion.

Focused searches combined maximum entropy, doubly stochastic matrices, zero entries, prescribed stationary laws, and unbounded entropy production. They reinforce that entropy maximization and matrix scaling are established settings. The fixed-corner matrix here follows from elementary convexity and should not be advertised as a new general method. Three-state irreversibility and the rare-event mechanism are also not claimed as new.

Continuation 13 derives the exact singular threshold for uniform finite-word laws, a sharp transition-floor envelope, and a global near-threshold asymptotic with a log-log term and an explicit constant. Its relative-entropy identity is the main proof device. The focused search did not establish priority for these particular constrained formulas; independent expert review and a broader novelty search remain necessary.


## Nonuniform-window continuation

Continuation 14 extends the sharp singular threshold and global near-threshold asymptotic to arbitrary positive symbol frequencies. Its fixed-margin minimizer is a four-group relative-entropy projection, an elementary standard entropy tool. The new notebook results include selection of the rare endpoints, the memory-three change, and the factor-of-two difference between the fair-coin asymptotic coefficient and the limit of biased-coin coefficients. These are derivations in this draft, not verified priority claims. No additional literature search was made for this checkpoint. The earlier primary sources remain background; the simultaneous small-bias and small-gap limit is an open continuation target.


## Simultaneous-limit continuation

Continuation 15 resolves the simultaneous small-bias/small-entropy-gap crossover left open in Continuation 14. It proves uniform asymptotic optimality, compares both boundary families and all context weights, and derives an explicit crossover function. This is an additional self-contained derivation in the notebook, not a new literature search or a priority claim. Exact scalar certificates are kept separate from the analytic uniform proof and from a small floating-point exploration of a stronger conjecture. Independent expert review and novelty verification remain open.


## Local biased-frontier continuation

- Frank Nielsen and Richard Nock, *On the Geometry of Mixtures of Prescribed Distributions*, ICASSP 2018, [author-hosted primary paper](https://franknielsen.github.io/GeometryWMixtures-ICASSP2018.pdf). Read the five-page paper, including Section 2 and Theorem 1. KL divergence within a prescribed-component mixture family is the Bregman divergence generated by negative Shannon entropy. Our scalar transport family is an elementary instance; this identity is established background.

Focused searches for symmetric Bregman diameters and entropy-constrained Jeffreys maximization did not establish priority for the local extremal formula. Continuation 16 derives local scalar uniqueness, exact small-budget context concentration, the cubic value expansion, and a whole-branch one-block ratio theorem. These are written derivations in this notebook, not independently reviewed or verified novelty claims. A search without an exact match does not establish originality. The finite-budget interior and an explicit local cutoff remain open.


## Global concentration continuation

Continuation 17 extends the allocation result to every subcritical budget, every memory, and every positive finite symbol law. Its proof writes the entropy cost along a fixed-center matrix ray as a positive power series, proves strict convexity of the ray's objective in its cost by a variance identity, and then handles the envelope and context allocation. KL/Jeffreys geometry, convexity, and positive-series variance identities are standard ingredients. No priority claim is made for these methods or for the resulting constrained theorem.

Additional searches used “maximum Jeffreys divergence entropy” and “Jeffreys divergence convex entropy constraint.” They did not establish priority or supply a result used in the proof. The previously inspected Nielsen/Nock primary paper remains information-geometric background. The separate numerical biased-phase exploration is not proof of a transition or a novelty claim.


## Biased-transition persistence continuation

Continuation 18 proves global persistence of the discontinuous optimizer change for every sufficiently small positive coin bias. The method uses standard compactness, nondegenerate constrained maxima, and the implicit-function theorem. Exact interval evaluations of the earlier fair-transition enclosures certify the needed curvature, reflection-selection coefficient, and quadratic transition shift. These particular constrained formulas are derivations in this notebook; they are not independently reviewed or verified priority claims. No additional literature search was made for this checkpoint. The admissible bias interval is positive but unquantified, and finite-bias numerical coexistence remains separate from proof.


## Concrete finite-bias certificate

Continuation 19 resolves the notebook's 40/60 numerical transition lead with an exhaustive interval certificate and a written global-selection proof. It establishes a unique crossing and unique scalar branches throughout an explicit narrow budget bracket. It does not establish uniqueness over the full subcritical range or a complete bias-dependent phase diagram. Monotone interval bounds, strict concavity, and transverse crossings are standard methods. No additional literature search was made for this final checkpoint. The specific constrained result remains a research derivation pending independent review and novelty checking.
