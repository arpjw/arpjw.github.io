# Continuation 2: enough noise restores an explicit frontier

Status: written theorem and proof, with numerical exploration kept separate. This builds on the stationary-curve classification in Continuation 1. Independent expert review and publication priority remain outstanding.

## A sharp threshold for symmetry within a pair

Impose a transition-noise floor `epsilon`, so every conditional probability lies in `[epsilon, 1-epsilon]`. In the original parameterization this is exactly the bias cap

\[
|\theta_u|\le b=1-2\epsilon.
\]

Let `z_c` be the positive root of

\[
(3z_c^2-1)\operatorname{atanh}z_c-z_c=0.
\]

Equivalently `z_c=tanh(t_c/2)`, where `t_c` is the stationary-curve threshold from Continuation 1. Numerically `z_c` is about `0.76557854121528283`, so the critical noise floor

\[
\epsilon_c=\frac{1-z_c}{2}
\]

is about `0.11721072939235859`. The rigorous enclosure is saved in `results/noise_threshold.json`.

**Theorem.** Equal bias magnitudes maximize the objective within a single reversed pair at every feasible entropy cost if and only if `b <= z_c`, or equivalently `epsilon >= epsilon_c`.

More explicitly, if `b <= z_c`, define `C=2d(b)`. For every `0 <= r <= C`,

\[
\max_{0\le x,y\le b,\ d(x)+d(y)=r}(x+y)(A(x)+A(y))
=S(r)=4a(r/2)A(a(r/2)).
\]

Proof. For `0<r<C`, order `x>=y` and parameterize by `s=d(x)` on the interval `[r/2,min(r,d(b))]`. The symmetric point is its left endpoint. It is a strict local maximum: its common magnitude is strictly below `z_c`, and the original second-variation formula is negative there.

There can be no unequal interior stationary point. Such a point would have `t=A(x)+A(y)<=2A(b)<=t_c`, contradicting Continuation 1. The derivative therefore cannot change sign away from symmetry. It is negative just to the right of symmetry, hence negative throughout the open feasible interval. The symmetric point is the unique maximum, including over the capped endpoint. The endpoint with `y=0`, when present, follows by continuity; the interior derivative does not change sign. At `r=0` or `r=C`, the conclusion is immediate.

Conversely suppose `b>z_c`. Select

\[
2d(z_c)<r<\min\{2d(b),\log2\}.
\]

This interval is nonempty because the original local critical budget is strictly below `log2`. The symmetric point is strictly inside the cap and has positive constrained second variation. Therefore it is a strict local minimum along the entropy constraint and cannot maximize. This proves the threshold is sharp.

## The entire entropy-and-noise frontier in this regime

Let `N=2^(k-1)`. The number of palindromic contexts of length `k-1` is

\[
P=2^{\lceil(k-1)/2\rceil},
\]

and the number of unordered nonpalindromic reversed pairs is

\[
m=(N-P)/2.
\]

For `0<b<=z_c`, let `C=2d(b)` and `R=min(N delta,m C)`. Write

\[
j=\lfloor R/C\rfloor,\qquad q=R-jC,\qquad 0\le q<C.
\]

At the endpoint `R=mC`, use `j=m,q=0`. Then the exact maximum observable time-reversal relative-entropy rate subject to entropy deficit at most `delta` and transition noise at least `epsilon` is

\[
\boxed{M_{k,\epsilon}(\delta)=\frac{4j b A(b)+S(q)}{N}.}
\]

For `b=0`, or for `m=0` (in particular `k<=2`), the value is zero.

An attaining process sets `j` reversed pairs to biases `(+b,-b)`, one additional pair to `(+a(q/2),-a(q/2))` if `q>0`, and all remaining biases to zero.

Proof. For fixed magnitudes, opposite signs maximize the contribution of each reversed pair. Palindromic biases contribute nothing to the objective, so an optimizer can set them to zero. The pair theorem reduces the optimization to

\[
\max\left\{\sum_{i=1}^m S(r_i):\ 0\le r_i\le C,\ \sum_i r_i\le N\delta\right\}.
\]

The function `S` is strictly increasing and strictly convex. Indeed, with `t=2A(a(r/2))`,

\[
S'(r)=2+2\sinh(t)/t,
\]

and both `t` and `sinh(t)/t` strictly increase with `r`. If two coordinates have costs strictly between 0 and C, transfer cost from the smaller to the larger. Strict convexity increases the total until one coordinate reaches an endpoint. Iterating leaves at most one partial pair, all other active pairs being saturated. Increasingness uses the full budget until all pairs saturate. This yields the formula.

The bound is attained with strictly positive transition probabilities because `epsilon>0`. If the entropy allowance exceeds the cost of saturating every useful pair, surplus allowance need not be spent. There may then also be optimizers with nonzero palindromic biases, so the construction above is an attaining choice, not a claim that all optimizers set palindromic biases to zero.

## What this does and does not settle

The theorem solves the joint entropy-and-noise problem for every `k` whenever every next-bit probability is at least approximately 11.7211 percent and at most approximately 88.2789 percent. The exact threshold is the equation above, not its rounded decimal.

For smaller noise floors, unequal pairs can be optimal. Numerical exploration in `results/noise_exploration.json` finds negative discrete second differences for the estimated capped single-pair envelope, for example at caps 0.95 and 0.999. This suggests the convexity argument above cannot simply be extended into that regime. It is a numerical observation, not a proof of nonconvexity, a certificate of the full optimizer, or a counterexample to every possible saturation rule.

The low-noise joint frontier, and uniqueness of the unequal branch, remain open in this notebook.
