# Continuation 9: memory, word overlaps, and a parity effect

Later development: [Continuation 10](010_all_memory_parity.md) proves the parity formula for every memory length. The checkpoint-6 account below is retained as the original record.

Status: an all-memory asymptotic theorem with explicit bounds; 4,030 exact primal/dual certificates determine its coefficient for memories 3 through 12. A proposed closed formula for arbitrary memory remains a conjecture. Independent expert review and novelty verification remain open.

## 1. The result

Let \(T_k(\tau)\) be the infimum entropy-rate deficit permitting unbounded
observable time-reversal KL rate among stationary binary Markov sources
of order at most \(k\), with strictly positive kernels and
\(\mathrm{TV}(P_k,U_k)\le\tau\). Write \(h=2^{-k}\).

For every fixed \(k\ge3\), we prove

\[
\boxed{T_k(\tau)=2h\log2-\alpha_k\tau\log(1/\tau)+O_k(\tau)
\quad(\tau\downarrow0).}
\]

The coefficient \(\alpha_k\) is the exact optimum of a finite linear
program on stationary word-frequency perturbations, defined below.
It obeys explicit universal bounds

\[
\frac12< A_k\le\alpha_k\le1,\qquad
A_k=
\begin{cases}
\dfrac{k+3}{2(k+1)},&k\text{ odd},\\[4pt]
\dfrac{k}{2(k-1)},&k\text{ even}.
\end{cases}
\]

The lower bounds come from two explicit pairs of periodic coin-flip
sequences. Exact primal and dual witnesses prove equality
\(\alpha_k=A_k\) for every \(3\le k\le12\):

| Memory \(k\) | Exact \(\alpha_k\) | Missing-word representatives checked |
|---:|---:|---:|
| 3 | \(3/4\) | 4 |
| 4 | \(2/3\) | 6 |
| 5 | \(2/3\) | 16 |
| 6 | \(3/5\) | 28 |
| 7 | \(5/8\) | 64 |
| 8 | \(4/7\) | 120 |
| 9 | \(3/5\) | 256 |
| 10 | \(5/9\) | 496 |
| 11 | \(7/12\) | 1,024 |
| 12 | \(6/11\) | 2,016 |

In particular the leading coefficient is **not monotone in memory**:
it decreases from \(k=5\) to 6, then increases from 6 to 7.
This is a statement about sensitivity to a tiny TV error; the
zero-tolerance threshold \(2^{1-k}\log2\) itself decreases geometrically.

**Conjecture, not proved:** \(\alpha_k=A_k\) for every \(k\ge3\).
The table is exact finite evidence, not a proof for unbounded memory.

## 2. A stationary-word linear program

For words \(s\) of length \(k\), let \(v_s\) be a signed frequency
perturbation. Define

\[
\mathcal V_k=\left\{v:
\sum_s v_s=0,\quad
\sum_{a=0}^1v_{au}=\sum_{b=0}^1v_{ub}\ \text{for every }|u|=k-1,\quad
\frac12\sum_s|v_s|\le1\right\}.
\]

These are exactly the normalized stationary perturbations of the
uniform \(k\)-word law. For a candidate missing word \(w=aub\), put

\[
\ell_w(v)=v_{u(1-b)}-v_{au},\qquad
\alpha_w=\max_{v\in\mathcal V_k}\ell_w(v),\qquad
\alpha_k=\max_{w\ne w^R}\alpha_w.
\]

Self-reversing words are excluded because their stationary flows
cannot contribute to reversal divergence.

Conservation at the middle context also gives

\[
\ell_w(v)=v_{(1-a)u}-v_{ub}
=\frac12\big(v_{u(1-b)}+v_{(1-a)u}-v_{au}-v_{ub}\big).
\]

For a non-self-reversing \(w\), the two positively signed words cannot
coincide: their coincidence would force \(u\) to be constant and
\(a=b\), making \(w\) a palindrome. The two negatively signed words
cannot coincide for the same reason. Opposite signs may cancel.
Thus every coefficient in the last linear expression has absolute
value at most \(1/2\), and \(\ell_w(v)\le1\). This proves
\(\alpha_k\le1\).

The constraints are the incidence equations on the binary de Bruijn
graph: \(k\)-words are directed edges between their length-\((k-1)\)
prefix and suffix. The coefficient measures how cheaply a stationary
frequency perturbation can reopen one corner of a constrained
transition block.

## 3. Why this LP gives the threshold coefficient

Write a stationary \((k+1)\)-word flow as
\(q(aub)=\pi(au)K(b\mid au)\). Prefix and suffix marginals both equal
\(\pi\). At the uniform law each \(k\)-word has mass \(h\).
For \(\mathrm{TV}(\pi,U_k)\le\tau<h\), all these masses are positive.

If a block has \(q(aub)=0\), its other three entries are forced:

\[
\begin{array}{c|cc}
&b&1-b\\\hline
a&0&\pi(au)\\
1-a&\pi(ub)&z
\end{array},
\qquad
z=\pi(u(1-b))-\pi(au)\ge0.
\]

Writing \(\pi=U_k+\tau v\) gives \(v\in\mathcal V_k\) and
\(z=\tau\ell_w(v)\le\alpha_k\tau\).
Let \(p=\pi(au)+\pi((1-a)u)\) and \(r=\pi((1-a)u)\).
This block's entropy-deficit contribution is

\[
p\log2-rH_2(z/r).
\]

The TV bound gives \(p\ge2h-\tau\), \(r\le h+\tau\).
Using \(rH_2(z/r)\le z\log(er/z)\), and monotonicity in \(z\) for
\(z\le r\), proves the universal boundary lower bound

\[
\boxed{L_k(\tau)=(2h-\tau)\log2
-\alpha_k\tau\log\frac{e(h+\tau)}{\alpha_k\tau}.}
\]

Here and below take \(0<\tau\le h/4\).
Other blocks have nonnegative entropy deficit, so they can be omitted.

To see that this bounds the singular threshold, suppose a sequence
with uniformly smaller deficit had unbounded reversal rate. By
compactness a subsequence converges to a flow with some non-self-reversing
word of zero mass. Otherwise every potentially singular denominator
in \(D(q\Vert q^R)\) stays bounded away from zero. The limiting flow
satisfies the lower bound, contradicting continuity of entropy deficit.
Thus \(T_k(\tau)\ge L_k(\tau)\).

For the matching construction, choose a missing word and an LP
optimizer attaining \(\alpha_k>0\), and put \(\pi=U_k+\tau v\).
In the selected block use the three entries above with
\(z=\alpha_k\tau\). In every other block use the product of its row
and column margins, divided by the block mass. The result is
stationary, has the prescribed marginal, and has just one zero edge.

Its reverse edge has positive mass. If \(u\ne u^R\), the reverse edge
is in an unconstrained product block. If \(u=u^R\), then nonpalindromicity
of \(w\) forces \(a\ne b\), and its reverse is the opposite corner,
with mass \(z>0\).

For this construction the selected block contributes at most

\[
(2h+\tau)\log2-\alpha_k\tau
\log\frac{h-\tau}{\alpha_k\tau}.
\]

Every unconstrained product block has conditional bias at most
\(m=2\tau/(2h-\tau)\). The standard binary deficit
\(d(x)=\log2-H_2((1+x)/2)\) obeys

\[
d(x)=\int_0^{|x|}\frac{|x|-t}{1-t^2}\,dt
\le\frac{x^2}{2(1-x^2)}.
\]

The block masses sum to at most one. Consequently

\[
\boxed{
T_k(\tau)\le U_k(\tau):=
(2h+\tau)\log2-\alpha_k\tau\log\frac{h-\tau}{\alpha_k\tau}
+\frac{2\tau^2}{(2h-\tau)^2-4\tau^2}.
}
\]

The notation \(U_k(\tau)\) in this display denotes an upper-bound
function, distinct from the uniform word law \(U_k\) in a TV expression.
Mixing the boundary flow with weight \(\eta\) of the fair flow
restores strict positivity, decreases TV and entropy deficit by
convexity, and gives

\[
\sigma_\eta=q(w^R)\log(1/\eta)+O_{k,\tau}(1).
\]

For general memory the correct identity is
\(\sigma=D(q\Vert q^R)-D(\pi\Vert\pi^R)\).
The second term remains bounded because every marginal mass is
bounded below by \(h-\tau\). Marginal reversal invariance, special
to the order-three calculation, is not assumed.

Expanding the explicit lower and upper bounds at zero yields the
claimed asymptotic, with an \(O_k(\tau)\) remainder for each fixed \(k\).
No uniformity in \(k\) is asserted. The bounds themselves remain
explicit and usable when \(k\) varies.

## 4. Two cycle constructions valid for every memory

For a finite binary string \(s\), let \(\mu_s^{(k)}\) be its stationary
\(k\)-word frequency law when \(s\) is repeated forever and the phase
is uniform.

### Long runs

For every \(k\ge3\), use the normalized signed difference

\[
v=\frac k2\left(\mu_{10^{k-2}}^{(k)}
-\mu_{10^{k-1}}^{(k)}\right).
\]

It has mass \(-1/2\) on each of \(0^{k-1}1\) and \(10^{k-1}\),
mass \(1/[2(k-1)]\) on each of the \(k-2\) intervening single-1 words,
and mass \(k/[2(k-1)]\) on \(10^{k-2}1\).
Its positive and negative masses each total one, so its TV norm is one.
Stationarity and zero total mass follow directly from the cycle laws.

For missing word \(w=0^{k-1}11\),

\[
\ell_w(v)=\frac1{2(k-1)}+\frac12
=\frac{k}{2(k-1)}.
\]

This proves the even-memory lower bound, and a slightly weaker bound
at odd memories beyond three.

### Alternation with two defects

For odd \(k=2r+1\ge3\), take

\[
s=0(01)^r1,\qquad
v=\mu_{01}^{(k)}-\mu_s^{(k)}.
\]

The first cycle has mass \(1/2\) on the two alternating \(k\)-words.
The second has period \(k+1\), with one double-0 defect and one
double-1 defect. Each of its \(k\)-word windows contains at least
one defect, so its support is disjoint from the alternating words.
The period is primitive because any proper repetition would repeat
each defect. Its length-\(k\) cyclic windows are
distinct: two length-\((k+1)\) rotations agreeing in all but one
position must agree in the final position as well, since they have
the same number of ones. Thus each such window has mass \(1/(k+1)\).

The two laws have disjoint support, so \(v\) has TV norm one.
For the missing word \(w=s\), its prefix \(au\) is a negative-mass
window of the defect cycle, while \(u(1-b)\) is alternating. Hence

\[
\ell_w(v)=\frac12+\frac1{k+1}=\frac{k+3}{2(k+1)}.
\]

This proves the asserted odd-memory lower bound and, in particular,
proves \(\alpha_k>0\) for all \(k\ge3\), as used in the construction.

## 5. Exact finite upper bounds, independent of the numerical solver

The optional certificate generator uses SciPy's HiGHS linear-programming
solver. The proof evidence consists of the rational witnesses it
produces, not its numerical status or objective value.

For each missing-word representative, the receipt stores:

- a rational stationary perturbation \(v\) of TV norm at most one;
- a rational potential \(g\) on length-\((k-1)\) vertices;
- a rational mass multiplier \(\lambda\) and radius \(t\ge0\);
- exact equality \(\ell_w(v)=2t\);
- every edge inequality
\[
\left|\ell_w(s)+g(s_{1:k-1})-g(s_{2:k})+\lambda\right|\le t.
\]

Here \(\ell_w(s)\) means the coefficient of \(v_s\) in the objective.
For any stationary zero-mass perturbation, the potential and mass
terms sum to zero. The inequalities imply
\(\ell_w(v')\le t\sum_s|v'_s|\le2t\).
The feasible primal witness attains this upper bound, proving
optimality using only exact rational arithmetic.

Bit complementation preserves the LP. Reversal does too:
after reversing both the missing word and the perturbation,
the objective becomes \(v_{(1-a)u}-v_{ub}\), equal to the original
objective by conservation. This justifies the representative reduction.
The verifier reconstructs all nonpalindromic word orbits and checks
that none are missing.

There are 4,030 certificates for \(3\le k\le12\).
The standalone verifier clears denominators and checks all constraints
with integers; it imports neither NumPy nor SciPy.

## 6. Reproduction and evidence boundaries

Run the exact verifier with
python3 continuation/memory_coefficient.py.
Its data and receipt are results/memory_coefficient.json and
results/memory_coefficient_verification.json.
To regenerate the optional numerical proposals locally, use
uv run --no-project --with scipy==1.18.1 python
continuation/memory_coefficient.py --generate --max-k 12.
The generation log is saved separately.

Run python3 continuation/memory_threshold.py for the explicit
cycle constructions and rational flow examples.
It checks both cycle families through memory 16, supplements their
all-memory written proof, and certifies four boundary constructions
and positive regularizations. These finite checks do not replace
the infinite-family argument.

The earlier transition certificate also received an independent audit:
continuation/audit_extended_threshold.py solves 1,280 rational
linear systems across all 64 TV orthants. Its 34 distinct vertices
agree exactly with the earlier cross-product enumeration.
No correction to Continuation 8 was required.

The general asymptotic theorem and explicit bounds are proved here;
the exact coefficients through memory 12 are computer certified;
the closed formula for all memory lengths is conjectural.
The generic entropy-continuity scale is known prior art. The
stationary-marginal polytope and its periodic extreme points are also
established background, for example in Chazottes, Gambaudo, Hochman,
and Ugalde, *On the finite-dimensional marginals of shift-invariant
measures*, Theorems 1 and 2, [arXiv:1011.2442](https://arxiv.org/abs/1011.2442).
The candidate contribution is the singular-threshold coefficient problem,
its explicit bounds, and the certified parity pattern. No claim of
publication priority is made.
