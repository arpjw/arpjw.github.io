# Continuation 11: selected sources and the next two terms

Status: a computer-assisted theorem for all memory lengths, with analytic equality and convexity arguments for large memory and exact finite-face certificates for the small cases. The small-tolerance interval exists for every fixed memory; its endpoint is not quantified here for k>=4. Independent expert review and novelty verification remain open.

## 1. The result

Write \(h=2^{-k}\), and let \(\alpha_k\) be the parity coefficient
proved in Continuation 10. Define

\[
\rho_k=
\begin{cases}
\frac12-\frac1{k+1},&k\text{ odd},\\[3pt]
\frac1{2(k-1)},&k\text{ even}.
\end{cases}
\]

For every fixed \(k\ge3\), the singular entropy threshold has the expansion

\[
\boxed{
T_k(\tau)=2h\log2-\alpha_k\tau\log(1/\tau)
+\beta_k\tau+\gamma_k\tau^2+O_k(\tau^3),
}
\]

where

\[
\boxed{\beta_k=-\rho_k\log2
+\alpha_k\log(\alpha_k/h)-\alpha_k,}
\]

and

\[
\boxed{
\gamma_k=
\begin{cases}
17/8,&k=3,\\[3pt]
\dfrac{2^k(3k^2+10k-5)}{16(k+1)^2},&k\ge5\text{ odd},\\[7pt]
\dfrac{2^k(3k^2-k-1)}{16(k-1)^2},&k\ge4\text{ even}.
\end{cases}}
\]

There is a stronger structural conclusion. For each fixed \(k\),
there exists \(\tau_0(k)>0\) such that the unique entropy-minimizing
critical boundary source, up to bit complementation and time reversal,
has an **exactly linear marginal**

\[
\pi_\tau=U_k+\tau v_k^*\qquad(0<\tau<\tau_0(k)),
\]

with an explicit signed vector \(v_k^*\) described next. Its transition
flow also has an exact finite formula. This is not merely a limiting
shape as tolerance goes to zero.

A boundary source has one forbidden transition. It is not itself in
the strictly positive-kernel class. Mixing it with an arbitrarily small
amount of the fair flow gives positive kernels with reversal rate tending
to infinity, while staying below its entropy deficit. The uniqueness
claim concerns the critical boundary variational problem, not a positive
kernel attaining an infinite rate.

The proof does not provide a numerical value of \(\tau_0(k)\) for
\(k\ge4\). None of the displayed positive-tolerance examples below is
used to claim such an endpoint. The order-three interval was already
quantified in Continuations 7 and 8.

## 2. The exact critical source

Let \(\mu_s^{(k)}\) denote the stationary \(k\)-word law of the
periodic sequence obtained by repeating a finite string \(s\), with
uniform phase.

For odd \(k=2r+1\), choose

\[
v_k^*=\mu_{0(01)^r1}^{(k)}-\mu_{01}^{(k)},
\qquad w_k=(10)^{r+1}.
\]

For even \(k\ge4\), choose

\[
v_k^*=\frac k2\left(\mu_{10^{k-1}}^{(k)}
-\mu_{10^{k-2}}^{(k)}\right),
\qquad w_k=10^{k-2}10.
\]

Here \(w_k\) is the forbidden word of length \(k+1\). These signed
vectors have total mass zero, stationary incidence balance, and TV norm
one. They are the negatives of the earlier lower-bound directions, with
both endpoints of the earlier missing word flipped.

Write \(w_k=aub\), and set \(\pi=U_k+\tau v_k^*\). In the selected
middle-context block, put

\[
\begin{array}{c|cc}
&b&1-b\\\hline
a&0&\pi(au)\\
1-a&\pi(ub)&\alpha_k\tau
\end{array}.
\]

In every other block, use its row-column product divided by the block
mass. This gives a stationary flow with exactly one zero entry; its
reverse entry is positive. The middle-context mass is

\[
\pi(au)+\pi((1-a)u)=2h-\rho_k\tau.
\]

The competing leading-order construction has the same \(\alpha_k\)
but context mass \(2h+\rho_k\tau\). Its entropy cost is larger by
\(2\rho_k(\log2)\tau+O_k(\tau^2)\). The next term therefore selects
which of the two leading constructions survives.

For an exact formula, put \(f(x)=x\log x\), with \(f(0)=0\), and
\(P_u=\pi(0u)+\pi(1u)\). The deficit of the selected construction is

\[
\boxed{
\begin{aligned}
\Phi_k(\tau)={}&\log2+\sum_{|s|=k} f(\pi_s)
-\sum_{|z|=k-1} f(P_z)\\
&+f(\alpha_k\tau)-f(\pi_{(1-a)u})-f(\pi_{u(1-b)})+f(P_u).
\end{aligned}
}
\]

For sufficiently small positive \(\tau\), \(T_k(\tau)=\Phi_k(\tau)\).
Although displayed as full sums, this formula needs only the changed
entries: all uniform baseline terms can be cancelled first.
There are \(k+1\) nonzero entries of \(v_k^*\) at even memory and
\(k+3\) at odd memory. No enumeration of \(2^k\) words is needed to
evaluate the sparse formula.

To derive it, a product block contributes
\(\sum_{\rm rows}f(\pi)+\sum_{\rm cols}f(\pi)-f(P)\) to
\(\sum f(q)\). Replace the selected block by its three forced nonzero
entries, subtract \(\sum f(\pi)\), and add \(\log2\).

## 3. Equality in the graph bound

We strengthen the dual-cycle proof in Continuation 10. First assume
\(k\ge10\). Orient a signed feasible perturbation \(-v\) as a
nonnegative circulation: positive entries use forward arcs, negative
entries use backward arcs. Decompose it into simple directed cycles
by repeatedly following positive-flow arcs and subtracting a minimum
cycle weight.

If \(v\) attains \(\ell(v)=\alpha_k=2t\), complementary slackness
forces \(\|v\|_1=2\). The total constraint-arc cost of this circulation is

\[
t\|v\|_1+\lambda\sum_e(-v_e)+\ell(-v)=2t-\alpha_k=0.
\]

Every simple cycle has nonnegative cost, so only zero-cost cycles can
occur. Because \(p,q>0\), cycles with cancelling marked terms have
strictly positive cost. Only critical cycles from the earlier proof
need be examined.

### Even memory

All other context types have coefficient at most one half, so a global
maximizer must belong to the near-constant family. Reduce by symmetries
to \(u=0^{k-2}1\), \(a=0\), with

\[
p=\frac{k-2}{2(k-1)},\qquad q=\frac1{k-1}.
\]

Inspecting equality in every case of the previous proof leaves only:

- the run triangle, with \(F=2,B=1\), length 3 and signed mass 1;
- the all-backward cycle of length \(k-1\) containing a single 1 per
period, with signed mass \(-(k-1)\).

The first triangle is unique through this context. A length-\((k-1)\)
cycle containing \(10^{k-2}1\) is uniquely fixed by that word's minimal
period. It exists as a critical cycle only for the canonical choice
\(b=1\); the other choice would require a consecutive pair of ones
inside this single-1 periodic cycle.

Let their nonnegative weights be \(A,B\). Zero signed mass and total
L1 mass two give

\[
A-(k-1)B=0,\qquad 3A+(k-1)B=2.
\]

Thus \(A=1/2\) and \(B=1/[2(k-1)]\). The resulting perturbation is
unique and is exactly the long-run direction in Continuation 9.
Its context-mass slope is \(+1/[2(k-1)]\). Endpoint flipping negates
that vector and selects the negative slope in Section 2.

### Odd memory

The near-constant bound is strictly smaller than \(\alpha_k\), so a
global maximizer must have a single marked alternating edge. Reduce to
\(w=0(01)^r1\), with \(p=1/(k+1),q=1/2\).

The only zero-cost cycles are the all-backward alternating two-cycle
and the all-forward defect cycle of length \(k+1\). Here is the extra
point needed beyond the inequality proof: the possible equality case
\(B=1,F=r+1\) is also impossible. Its central word would have period
\(r\), while containing at least \(2r-1\ge r+1\) alternating bits.
For \(r\ge2\), the same overlap argument forces alternation and then
either conflicts with the 00 defect or uses the other marked edge.

The two remaining cycles are uniquely determined. If their weights
are \(A,B\), zero signed mass and L1 normalization give

\[
-2A+(k+1)B=0,\qquad 2A+(k+1)B=2.
\]

Therefore \(A=1/2\), \(B=1/(k+1)\), yielding the unique direction
\(\mu_{01}^{(k)}-\mu_{0(01)^r1}^{(k)}\). Its context slope is
\(1/2-1/(k+1)\); endpoint flipping again selects the negative slope.

These arguments classify the maximizing word classes as well as the
perturbations. Up to complement and reversal there are exactly two
leading classes, with opposite context slopes. For every \(k\ge10\),
each class has a unique normalized perturbation.

## 4. The finite base and the exceptional three-bit face

For \(3\le k\le9\), the 494 exact certificates already establish all
word-class maxima. We now audit the optimal faces themselves.
For a saved dual witness, an optimal \(v_e\) can be nonzero only when
its edge residual equals \(+t\) or \(-t\), with the corresponding sign.
Orient these signed edges. Any stationary nonnegative flow uses only
edges lying on directed cycles, so all other tight edges can be discarded.

On the remaining edge magnitudes, impose incidence balance, zero signed
mass, and L1 mass two. Exact rational row reduction proves:

- At every \(4\le k\le9\), both globally maximizing representative
faces are singletons, agreeing with the cycle constructions above.
- At \(k=3\), both representative faces have affine dimension one.
Their context-mass slopes are nevertheless constant, respectively
\(+1/4\) and \(-1/4\).

The affine-dimension claim is not inferred from rank alone: the alternating
cycle construction has strictly positive magnitudes on all six allowed
edges, so the one-dimensional affine space meets the relative interior
of the feasible nonnegative region.

The same exact face audit was run through memory 12: 20 faces total,
18 singleton faces and the two order-three segments. This later check
corroborates the analytic equality classification.

For \(k=3\), Continuations 7 and 8 already prove that the selected
finite-tolerance optimum is the alternating construction of Section 2.
It lies in the interior of the leading face, rather than at the particular
vertex returned by the original LP solver. The new argument does not
claim uniqueness of the leading order-three perturbation.

## 5. Why the limiting direction becomes exactly optimal

Fix a nonpalindromic missing word \(w=aub\). For a feasible normalized
marginal perturbation \(v\), let \(F_{w,\tau}(v)\) be the minimum deficit
among stationary flows with marginal \(U_k+\tau v\) and zero \(w\)-entry.
The feasible domain is the stationary TV polytope intersected with
\(\ell_w(v)\ge0\). All margins remain positive for \(\tau<h/4\).

The selected block is forced; every other block uniquely maximizes
entropy by taking the product of its margins. Thus the formula in
Section 2 applies to this general \(w,v\).

The function \(F_{w,\tau}\) is convex on its domain. Indeed the negative
conditional entropy of a row is
\(f(x)+f(y)-f(x+y)\), whose Hessian is positive semidefinite by
Cauchy-Schwarz. Sum over rows and minimize this convex function over
linear flow and marginal constraints.

Put \(L=\log(1/\tau)\), \(a_v=\ell_w(v)\), and
\(s_v=v_{au}+v_{(1-a)u}\). Uniformly over the feasible compact polytope,

\[
F_{w,\tau}(v)=2h\log2-\tau L a_v
+\tau\{s_v\log2+a_v\log(a_v/h)-a_v\}+O_k(\tau^2),
\]

with \(a_v\log a_v=0\) at zero. This follows directly from the exact
formula: the only singular term is \(f(\tau a_v)\); all other terms
are expanded around the positive constants \(h\) or \(2h\).

Suppose \(v_*\) uniquely maximizes \(\ell_w\) on the stationary TV
polytope. Because it is a polytope, there is \(c>0\) such that

\[
\ell_w(v_*)-\ell_w(v)\ge c\|v-v_*\|
\quad\text{for every feasible }v.
\]

To see this, take the minimum positive objective-gap/distance ratio
over the finitely many other vertices, then use convex combinations
and the triangle inequality.

At \(v_*\), where \(a_{v_*}=\alpha_k>0\), differentiation of the exact
formula gives

\[
\nabla F_{w,\tau}(v_*)=-\tau L\ell_w+O_k(\tau).
\]

Consequently, for small enough \(\tau\), every nonzero feasible direction
from \(v_*\) has strictly positive directional derivative. Convexity
then makes \(v_*\) the unique exact minimizer of \(F_{w,\tau}\).
This proves eventual exact selection for every maximizing class at
\(k\ge4\), not just convergence to that direction.

The finitely many other word classes have a strictly smaller leading
coefficient. The uniform value expansion excludes them once \(L\) is
large enough. Among the two maximizing classes, the linear term differs
by \(2\rho_k\log2\), selecting the negative context slope. Complement
and reversal preserve the deficit and account for the stated symmetry.
The already solved order-three problem supplies the remaining case.

Finally, minimizing over all nonpalindromic zero-word faces bounds every
possible singular limit. The selected minimizer has a positive reversed
edge, so fair-flow mixing proves an infinite supremum at its deficit.
Below that deficit, compactness and continuity preclude an unbounded
reversal rate. This identifies the boundary minimum with \(T_k(\tau)\).
No separate assumption about how many zero edges a competing limit has
is needed: any such limit belongs to at least one of these faces.

## 6. Expanding the sparse formula

Let \(m_u=\sum_a v_{au}\), \(s=m_u\) at the selected context,
\(R=v_{(1-a)u}\), and \(C=v_{u(1-b)}\). Expanding the exact formula gives

\[
\beta=s\log2+\alpha\log(\alpha/h)-\alpha,
\]

and

\[
\gamma=\frac{\sum_s v_s^2-R^2-C^2}{2h}
+\frac{s^2-\sum_u m_u^2}{4h}.
\]

The following exact quantities determine the stated formulas:

\[
\begin{array}{c|c|c|c|c}
&\sum v^2&\sum m^2&R&C\\\hline
k\ge4\text{ even}&\dfrac{3k}{4(k-1)}&\dfrac{k}{4(k-1)}&\dfrac12&0\\[7pt]
k\ge5\text{ odd}&\alpha_k&\dfrac12&\dfrac1{k+1}&\dfrac1{k+1}\\[7pt]
k=3&\dfrac34&\dfrac14&\dfrac14&\dfrac14
\end{array}
\]

For even memory, the length-\((k-1)\) marginal perturbation has value
\(+1/2\) on the all-zero context and value \(-1/[2(k-1)]\) on each
of the \(k-1\) single-1 contexts. The word-level values follow from
the explicit long-run construction in Continuation 9.

For odd \(k\ge5\), the defect cycle has \(k+1\) distinct length-\((k-1)\)
windows. Exactly one is alternating. A nonalternating window contains
a 00 or 11 pair, whose unique position in the period identifies its
phase; the sole alternating window omits both endpoint defects.
The resulting context slopes are \(-1/2+1/(k+1)\), \(-1/2\), and
\(+1/(k+1)\) on the other \(k\) contexts. Their squared sum is one half.
At \(k=3\), both alternating two-bit contexts occur in the defect
cycle; the squared sum is instead one quarter. This explains the
exceptional quadratic coefficient \(17/8\).

A fully explicit error bound is available for any evaluation of the
candidate source. For \(|d|<x\),

\[
\left|f(x+d)-f(x)-f'(x)d-\frac{d^2}{2x}\right|
\le\frac{|d|^3}{6(x-|d|)^2}.
\]

Apply this to every changed \(h\)- and \(2h\)-term in the sparse formula;
treat \(f(\alpha\tau)\) exactly. Summing the absolute bounds gives a
certified cubic remainder. The bound concerns the candidate entropy
at any allowed input tolerance; its identification with the threshold
still uses the small-tolerance theorem.

## 7. Reproduction, audit, and remaining work

Run `python3 continuation/leading_face.py` for the 494 base certificates,
the 20 exact face-rank checks, and the comparison with the periodic
constructions. The receipt is `results/leading_face.json`.

Run `python3 continuation/second_order_threshold.py` for sparse sources,
closed coefficients, and rigorous Taylor examples at memories 3, 4, 5,
10, 11, and 20. Four of these are checked against independent full-flow
entropy sums. Sparse constructions and coefficient identities are also
checked at memories 21, 50, 51, 100, and 101. The receipt is
`results/second_order_threshold.json`.

Both scripts use only the standard library and the existing outward-rounded
integer interval module. The numerical examples certify source values and
error bounds; except for the earlier order-three regime, they do not
certify a particular tolerance as below \(\tau_0(k)\).

Continuation 10's word-overlap and parity proof was rechecked, including
the equal-cost alternating case needed here. No earlier theorem required
correction. The order-three nonunique leading face is a refinement,
not a contradiction to the already proved unique finite-tolerance source.

The next useful target is a quantitative lower bound for \(\tau_0(k)\),
or a proof of how the exact source changes beyond it. The larger-alphabet
threshold calculation in the handoff remains an unverified direction.
All results remain research drafts, with novelty and independent expert
review unresolved.
