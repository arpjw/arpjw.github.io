# A certified phase transition for a 40/60 coin

Status: written global-selection proof with a complete outward-rounded interval certificate. Research draft, pending independent expert review and novelty checking. All logarithms and entropy budgets use nats. The uniqueness statement below concerns the displayed budget interval, not the whole biased phase diagram.

## 1. A concrete biased transition

The discontinuous change is now certified for a coin with probabilities
\(p=2/5\) and \(q=3/5\). This is a concrete finite bias, independent of Continuation 18's unquantified neighborhood of fairness.

For this coin, put
\[
T(x)=\begin{pmatrix}x&p-x\\p-x&1-2p+x\end{pmatrix},
\quad \mu=p^2=\frac4{25},
\quad f(x)=D(T(x)\Vert(p,q)^{\otimes2}).
\]
For a pair of blocks define
\[
J(x,y)=(y-x)\{f'(y)-f'(x)\},
\qquad A(c)=\max_{f(x)+f(y)\le c}J(x,y).
\]
The singular scalar budget is rigorously enclosed by
\[
0.29110316603236874492646504891915
 <f(0)<
0.29110316603236874492646504891917.
\]

**Finite-bias transition theorem.** There is exactly one crossing budget in
\[
\boxed{0.2874097<c_t<0.2874098.}
\]
Throughout this interval, the global maximizing unordered scalar pair is unique below and above \(c_t\). At \(c_t\), exactly two unordered pairs maximize. Their smaller parameters lie in the disjoint intervals
\[
\begin{aligned}
\text{strong suppression:}&\quad 0.0008<x<0.0009,\\
\text{mild suppression:}&\quad 0.019<x<0.021.
\end{aligned}
\]
The mild branch wins below the crossing, and the strong branch wins above it. Consequently the smaller diagonal probability drops by more than \(0.0181\). The derivative of \(A(c)\) jumps upward by more than \(20\).

Both maxima correspond to strictly positive stationary kernels. For every memory \(k\ge3\), the global source theorem from Continuation 17 gives
\[
M_{p,k}(\delta)=R A(\delta/R),\qquad
R=(2/5)^{k-2}(3/5).
\]
Thus the source transition lies in the interval obtained by multiplying the displayed scalar bracket by \(R\). At memory three this is
\[
0.068978328<\delta_t<0.068978352.
\]
The source frontier's derivative with respect to \(\delta\) has the same jump as \(A\), since the factor \(R\) cancels on differentiation. Reversing time still gives an equally good process.

## 2. Reduction to a compact one-dimensional problem

The derivative formulas are
\[
\begin{aligned}
f'(x)&=\log\frac{x(1-2p+x)}{(p-x)^2},\\
f''(x)&=\frac1x+\frac2{p-x}+\frac1{1-2p+x}>0.
\end{aligned}
\]
The cost decreases strictly on \((0,\mu)\), increases strictly on \((\mu,p)\), and vanishes at \(\mu\). For every \(0<c<f(0)\), both inverse branches are available at costs up to \(c\), and every feasible block is positive.

As proved in Continuation 16, every scalar maximizer strictly straddles \(\mu\) and uses the full budget. For completeness, if both parameters are on the same side, replace the nearer one by the opposite-side parameter of equal cost. Both the distance and the derivative gap increase. A parameter at \(\mu\) can be moved across it at first-order objective gain and second-order cost. Finally, pushing a straddling endpoint outward increases the objective, excluding a slack budget.

Let \(x_{\min}(c)\) be the left solution of \(f(x)=c\). Let \(r\) be the inverse of \(f\) on \([\mu,p)\). Every candidate is therefore represented by
\[
x\in[x_{\min}(c),\mu],\qquad
y=r(c-f(x)),\qquad H(c,x)=J(x,y).
\]
This is a continuous objective on a compact feasible interval. In the two neighborhoods used in the theorem, \(y>\mu\), so \(H\) is analytic in both variables.

## 3. Exhaustive exclusion rather than a search grid

The certificate first treats the larger budget interval
\[
0.2867\le c\le0.2882.
\]
Across that whole interval, no global maximizer has
\(0.004\le x\le0.012\). At the lower endpoint, every global maximizer has \(x>0.012\); at the upper endpoint every one has \(x<0.004\). This broad certificate already proves coexistence somewhere and rules out a continuous choice of global optimizers across the interval.

The sharper certificate covers the full feasible set for every budget in
\([0.2874097,0.2874098]\), excluding everything outside
\[
N_L=[0.0008,0.0009],\qquad N_R=[0.019,0.021].
\]
It also excludes the entire left candidate at the lower budget endpoint and the entire right candidate at the upper endpoint. These exclusions compare against explicitly feasible pairs, not against an assumed numerical optimum.

Here is the interval argument for each covered rectangle. Suppose
\(c\in[c_0,c_1]\) and \(x\in[a,b]\subset(0,\mu]\). If \(f(b)>c_1\), the rectangle is infeasible. Otherwise monotonicity gives
\[
y\le r(c_1-f(b)).
\]
For straddling pairs,
\[
J_x=-\{f'(y)-f'(x)\}-(y-x)f''(x)<0,
\]
\[
J_y=\{f'(y)-f'(x)\}+(y-x)f''(y)>0.
\]
Hence evaluating \(J\) at the lower \(x\) bound and the upper \(y\) bound gives a rigorous upper bound throughout the rectangle. A feasible pair of cost at most \(c_0\) supplies a lower bound on \(A(c)\) throughout the same budget interval. If the upper bound is strictly smaller, the entire rectangle is excluded.

Unresolved rectangles are bisected in \(x\). The script verifies that the final rational intervals join without gaps, and that the budget strips cover their complete specified interval. Thus it checks every feasible point, including points between proposed numerical candidates.

All arithmetic bounds use the existing 40-decimal-place integer interval library, with positive logarithm series and explicit remainders. Floating-point inverse calculations only propose rational brackets. Both ends of every proposed bracket must pass exact outward-rounded entropy inequalities before the bracket is accepted. A floating-point error can make verification fail or require a wider bracket; it cannot silently establish a bound.

## 4. Unique branches and a transverse crossing

Write \(f_x=f'(x)\), \(f_y=f'(y)\), \(a_x=f''(x)\), and \(a_y=f''(y)\). On a fixed-cost curve,
\[
y_x=-f_x/f_y,\qquad
H_x=J_x-J_y f_x/f_y.
\]
Its second derivative is
\[
\begin{aligned}
H_{xx}={}&J_{xx}-2J_{xy}\frac{f_x}{f_y}
 +J_{yy}\left(\frac{f_x}{f_y}\right)^2\\
&-\frac{J_y}{f_y}\left\{a_x+a_y
 \left(\frac{f_x}{f_y}\right)^2\right\}.
\end{aligned}
\]
The needed partial derivatives are
\[
J_{xx}=2a_x-(y-x)f'''(x),\quad
J_{yy}=2a_y+(y-x)f'''(y),\quad
J_{xy}=-a_x-a_y.
\]

The interval certificate verifies \(H_{xx}<0\) throughout each neighborhood, uniformly over the sharp budget interval. It verifies \(H_x>0\) at each neighborhood's left endpoint and \(H_x<0\) at its right endpoint. Each neighborhood therefore contains exactly one stationary maximum. The implicit-function theorem gives two analytic maximizing branches, with values \(V_L(c)\) and \(V_R(c)\).

At a stationary point, differentiation with respect to budget gives
\[
V'(c)=H_c(c,x)=\frac{J_y}{f_y}.
\]
Uniform interval bounds on the two neighborhoods certify
\[
\inf_{N_L}H_c-\sup_{N_R}H_c>20.
\]
Consequently \(V_L-V_R\) is strictly increasing. The endpoint exclusions give it opposite signs at the ends of the sharp bracket. There is exactly one zero. The global exclusions show that no third maximizer can intervene. This proves uniqueness of the crossing in the bracket, uniqueness of the winning pair on either side, exactly two pairs at coexistence, and the positive derivative jump.

## 5. Reproduction and precise limits

Reproduce with `python3 continuation/finite_bias_transition.py`.

The full rational covers, feasible witnesses, inverse-bracket checks, curvature bounds, branch endpoint signs, and slope bounds are saved in `results/finite_bias_transition.json`. The receipt distinguishes the broad exclusion cover from the sharper uniqueness certificate. Code and the interval library are hashed.

The final run used 1,661 broad exclusion boxes, 16,217 sharp exclusion boxes, four curvature boxes, and 18,388 validated inverse brackets. Conservative outward summaries of its derivative bounds are
\[
\begin{aligned}
30.03&<H_c<34.16 &&\text{on }N_L,\\
5.45&<H_c<5.81 &&\text{on }N_R,\\
H_{xx}&<-21000 &&\text{on }N_L,\\
H_{xx}&<-17.9 &&\text{on }N_R.
\end{aligned}
\]
All four bounds hold uniformly over the sharp budget interval. The large separation of branch slopes makes the certified crossing robust to the width of the displayed bracket.

A separate 60-digit Decimal stationary solve suggested
\(c_t\approx0.287409731352362\), with smaller parameters near
\(0.000853224325\) and \(0.019832718734\). This numerical calculation helped choose rational neighborhoods. Its digits beyond the certified bracket are not part of the theorem.

The result resolves the earlier numerical conjecture that a 40/60 coin has a discontinuous global optimizer change. It does not prove that this is the only transition over the entire subcritical budget range, nor determine the full phase diagram as the bias varies. It does not quantify the bias neighborhood in Continuation 18. The proofs remain drafts pending independent expert review, and novelty remains unconfirmed.
