"""Double-precision search for competing biased-binary scalar branches.

This is deliberately separate from the exact global concentration proof.
A grid can miss narrow branches; refined peaks are not global certificates.
"""
from __future__ import annotations

import json
from math import log, sqrt
from pathlib import Path

from explore_biased_scalar import f, inverse


def value(p: float, budget: float, share: float) -> tuple[float,float,float]:
    x=inverse(p,budget*share,True)
    y=inverse(p,budget*(1-share),False)
    slope=lambda z:log(z)+log(1-2*p+z)-2*log(p-z)
    return (y-x)*(slope(y)-slope(x)),x,y


def peaks(p: float, fraction: float, grid_size: int=400) -> list[dict]:
    budget=f(p,0)*fraction
    edge=[10**(-j/4) for j in range(1,49)]
    grid=sorted(set(edge+[1-t for t in edge]+[i/grid_size for i in range(1,grid_size)]))
    values=[value(p,budget,t)[0] for t in grid]
    out=[]
    for i in range(1,len(grid)-1):
        if values[i] < values[i-1] or values[i] < values[i+1]: continue
        lo,hi=grid[i-1],grid[i+1]
        ratio=(sqrt(5)-1)/2
        a,b=hi-ratio*(hi-lo),lo+ratio*(hi-lo)
        fa,fb=value(p,budget,a)[0],value(p,budget,b)[0]
        for _ in range(55):
            if fa<fb:
                lo,a,fa=a,b,fb
                b=lo+ratio*(hi-lo);fb=value(p,budget,b)[0]
            else:
                hi,b,fb=b,a,fa
                a=hi-ratio*(hi-lo);fa=value(p,budget,a)[0]
        share=(lo+hi)/2
        score,x,y=value(p,budget,share)
        if any(abs(share-row['left_entropy_share'])<1e-5 for row in out): continue
        out.append({'left_entropy_share':share,'rate':score,'x':x,'y':y})
    out.sort(key=lambda row:row['rate'],reverse=True)
    return out


def main() -> None:
    rows=[]
    for p in (.5,.4999,.499,.495,.49,.48,.45,.4,1/3,.2,.1):
        for fraction in (.1,.5,.8,.9,.93,.94,.95,.955,.9565,.957,.957072,.95715,.95725,.9575,.96,.965,.97,.975,.98,.985,.99,.995,.999):
            local=peaks(p,fraction)
            rows.append({'p':p,'fraction_of_singular_scalar_budget':fraction,'budget':f(p,0)*fraction,'local_peaks_found':local})
    receipt={'status':'exploratory double precision; a finite grid and golden-section peak refinement, not a global or interval certificate',
             'uniform_grid_subintervals':400,'logarithmic_edge_points_per_side':48,'cases':len(rows),'multiple_peak_cases':sum(len(row['local_peaks_found'])>1 for row in rows),'rows':rows}
    Path('results/biased_phase_exploration.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({key:receipt[key] for key in ('status','cases','multiple_peak_cases')},indent=2))
    for row in rows:
        if len(row['local_peaks_found'])>1:
            print(json.dumps(row))


if __name__=='__main__':
    main()
