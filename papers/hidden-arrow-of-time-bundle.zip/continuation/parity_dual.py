"""Exact graph-potential audit of the all-memory parity proof.

No optimization library is used. Rational dual parameters come from the
written case analysis; integer shortest-path relaxations construct potentials.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque
from fractions import Fraction as Q
import json
from math import lcm
from pathlib import Path
from time import perf_counter

from memory_coefficient import check_certificate, complement, objective, representative, words


def flip_ends(w: str) -> str:
    return complement(w[0]) + w[1:-1] + complement(w[-1])


def periodic(w: str, p: int) -> bool:
    return all(w[i] == w[i-p] for i in range(p, len(w)))


def conjectured(k: int) -> Q:
    return Q(1, 2) + (Q(1, k+1) if k % 2 else Q(1, 2*(k-1)))


def dual_parameters(w: str) -> tuple[str, Q, Q]:
    k, u = len(w)-1, w[1:-1]
    a, b = w[0], w[-1]
    assert k >= 10 and w != w[::-1]
    if len(set(u)) == 1:
        return "constant", Q(0), Q(0)
    # Complement, reversal, and endpoint flip preserve alpha. Endpoint flip
    # negates the objective modulo an incidence row, so negates lambda.
    for rev in (False, True):
        for comp in (False, True):
            for ends in (False, True):
                transformed = w[::-1] if rev else w
                if comp:
                    transformed = complement(transformed)
                if ends:
                    transformed = flip_ends(transformed)
                if transformed[0] == "0" and transformed[1:-1] == "0"*(k-2)+"1":
                    radius = Q(k, 4*(k-1))
                    mass = Q(k-4, 4*(k-1)) * (-1 if ends else 1)
                    return "run triangle", radius, mass
    minus, plus = a+u, u+complement(b)
    if periodic(u, 2):
        pm, pp = periodic(minus, 2), periodic(plus, 2)
        if pm != pp:
            assert k % 2 == 1
            radius = Q(k+3, 4*(k+1))
            mass = Q(1,2)-radius if pm else radius-Q(1,2)
            return "alternation", radius, mass
        return "alternation cancellation", Q(1,4), Q(0)
    if periodic(u, 3):
        pm, pp = periodic(minus, 3), periodic(plus, 3)
        if pm != pp:
            return "period three", Q(1,4), Q(1 if pm else -1,12)
        return "period-three cancellation", Q(1,4), Q(0)
    return "generic", Q(1,4), Q(0)


def graph_potential(k: int, w: str, radius: Q, mass: Q) -> tuple[list[int], int, int]:
    scale = lcm(radius.denominator, mass.denominator)
    ti, li = int(radius*scale), int(mass*scale)
    ell = objective(w)
    node_count = 2**(k-1)
    adjacency: list[list[tuple[int,int]]] = [[] for _ in range(node_count)]
    for e in range(2**k):
        edge = f"{e:0{k}b}"
        tail, head = e >> 1, e & (node_count-1)
        value = int(ell.get(edge, 0))*scale
        adjacency[tail].append((head, ti+li+value))
        adjacency[head].append((tail, ti-li-value))
    distances = [0]*node_count
    queue = deque(range(node_count))
    queued = [True]*node_count
    depth = [0]*node_count
    relaxations = 0
    while queue:
        tail = queue.popleft()
        queued[tail] = False
        for head, cost in adjacency[tail]:
            candidate = distances[tail]+cost
            if candidate < distances[head]:
                distances[head] = candidate
                depth[head] = depth[tail]+1
                assert depth[head] < node_count, ("negative cycle or relaxation-depth alarm", w)
                relaxations += 1
                if not queued[head]:
                    queue.append(head)
                    queued[head] = True
    # The certificate is every exact edge inequality, not algorithm termination.
    for e in range(2**k):
        edge = f"{e:0{k}b}"
        tail, head = e >> 1, e & (node_count-1)
        value = int(ell.get(edge, 0))*scale
        assert abs(value+distances[tail]-distances[head]+li) <= ti, (w,edge)
    return distances, scale, relaxations


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-k", type=int, default=13)
    args = parser.parse_args()
    saved = json.loads(Path("results/memory_coefficient.json").read_text())
    base = []
    for k in range(3,10):
        records = [r for r in saved["certificates"] if r["k"] == k]
        expected = {representative(w) for w in words(k+1) if w != w[::-1]}
        assert len(records) == len(expected)
        assert {r["missing_word"] for r in records} == expected
        maximum = max(check_certificate(r) for r in records)
        assert maximum == conjectured(k)
        base.append({"k":k,"certificates":len(records),"maximum":str(maximum)})
    report = {"status":"PASS: exact finite base and integer graph potentials", "base_cases":base, "range":[10,args.max_k], "per_memory":[], "scope":"The 494 base certificates prove memories 3 through 9. The later finite audit checks the analytic dual parameters; the arbitrary-memory theorem requires the written cycle proof."}
    for k in range(10,args.max_k+1):
        start = perf_counter()
        counts, relaxations = Counter(), 0
        representatives = sorted({representative(w) for w in words(k+1) if w != w[::-1]})
        examples = []
        for w in representatives:
            case, radius, mass = dual_parameters(w)
            assert 2*radius <= conjectured(k)
            potential, scale, changes = graph_potential(k,w,radius,mass)
            counts[case] += 1
            relaxations += changes
            if len(examples) < 8 and case not in {e['case'] for e in examples}:
                examples.append({'case':case,'word':w,'radius':str(radius),'mass':str(mass),'scale':scale,'potential':{f'{i:0{k-1}b}':str(Q(g,scale)) for i,g in enumerate(potential) if g}})
        row={'k':k,'representatives':len(representatives),'cases':dict(counts),'integer_edge_inequalities':len(representatives)*2**k,'relaxations':relaxations,'seconds':perf_counter()-start,'example_witnesses':examples}
        report['per_memory'].append(row)
        print(json.dumps({key:value for key,value in row.items() if key!='example_witnesses'}),flush=True)
    Path('results/parity_dual.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__ == '__main__':
    main()
