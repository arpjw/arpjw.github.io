# Continuation 13: more symbols, less memory

Status: a written theorem for every finite alphabet of size at least three, with exact rational construction checks and outward-rounded numerical certificates. The fixed-corner entropy calculation uses standard convexity. Novelty and independent expert review remain open.

## 1. The result and a concrete example

Three symbols already permit unbounded time-reversal divergence with only one-step memory. More generally, consider stationary order-at-most-\(k\) processes on \(m\ge3\) symbols, with strictly positive transitions and exactly uniform length-\(k\) windows. Let \(\delta\) be the entropy-rate deficit from \(\log m\), in nats. The exact threshold for an infinite supremum of the observable reversal rate is

\[
\boxed{\Delta_{m,k}=m^{-(k-1)}\left\{
\log m+\frac{m-2}{m}\log(m-2)
-\frac{2(m-1)}m\log(m-1)\right\}.}
\]

Below \(\Delta_{m,k}\), the maximum is finite and attained. At or above it, the supremum is infinite, although each individual positive-kernel process has finite rate. We also determine the sharp minimum-transition envelope below the threshold and the exact asymptotic growth of the maximum as the threshold is approached.

For a tangible example, there are stationary byte-valued processes such that:

- Every three-byte window is exactly uniform over all \(256^3\) possibilities.
- Entropy exceeds \(7.99999999966\) bits per byte.
- The reversal KL rate can be arbitrarily large.
- Even the optimal direction classifier given 1,000 bytes succeeds with probability at most \(50.034136\) percent, under equal prior probabilities of forward and reversed data.

The rare-event distinction between divergence and practical distinguishability is established background. The exact constrained formulas and their derivation are the subject of this continuation.

## 2. Uniform windows as doubly stochastic blocks

Write a length-\((k+1)\) word as \(aub\), where \(u\) has length \(k-1\). Uniform length-\(k\) windows imply

\[
q(aub)=m^{-k}P_u(a,b),
\]

where every \(P_u\) is an \(m\times m\) doubly stochastic matrix: its rows and columns sum to one. Conversely, any such collection defines a stationary order-at-most-\(k\) source with uniform length-\(k\) windows. Positive matrix entries give positive transition probabilities.

Define the block deficit

\[
B(P)=\frac1m\sum_{a,b}P(a,b)\log(mP(a,b)).
\]

The entropy deficit and observable reversal rate are

\[
\delta=m^{-(k-1)}\sum_u B(P_u),
\qquad
\sigma=m^{-k}\sum_{u,a,b}P_u(a,b)
\log\frac{P_u(a,b)}{P_{u^R}(b,a)}.
\]

The factor \(m^{-(k-1)}\) averages over the \(m^{k-1}\) middle contexts. Reversal acts on the entire observable word, including the order inside the middle context.

For a path of length \(n\ge k\), its initial \(k\)-word has uniform probability. Multiplying transition probabilities therefore gives the exact identities

\[
D(\mathbb P_n\|U_n)=(n-k)\delta,
\qquad
D(\mathbb P_n\|\mathbb P_n^R)=(n-k)\sigma.
\]

## 3. The least entropy cost of a small transition

Fix one matrix entry \(P(a,b)=t\), with \(0\le t\le1/m\). The unique block minimizing \(B(P)\) is

\[
P^{a,b}_t(i,j)=
\begin{cases}
t,&(i,j)=(a,b),\\
\dfrac{1-t}{m-1},&i=a,\ j\ne b\text{ or }i\ne a,\ j=b,\\[5pt]
\dfrac{m-2+t}{(m-1)^2},&i\ne a,\ j\ne b.
\end{cases}
\]

The special row, special column, and remaining square have fixed masses \(1-t\), \(1-t\), and \(m-2+t\), respectively. Strict convexity of \(x\log x\) minimizes each group's contribution by making its entries equal. The displayed matrix satisfies every row and column constraint, so these separate minima are simultaneously attained. This proves global optimality and uniqueness.

Its cost is

\[
\boxed{\begin{aligned}
\phi_m(t)=\frac1m\bigg\{&t\log(mt)
+2(1-t)\log\frac{m(1-t)}{m-1}\\
&+(m-2+t)\log\frac{m(m-2+t)}{(m-1)^2}\bigg\}.
\end{aligned}}
\]

Use \(0\log0=0\). A useful exact identity strengthens the inequality:

\[
B(P)-\phi_m(t)=D(P/m\|P_t^{a,b}/m)\ge0.
\]

The identity follows because each of the four groups has the same total mass in \(P\) and \(P_t^{a,b}\), so their cross-entropy terms agree. At \(t=0\), omit the common zero entry. The other entries are positive because \(m\ge3\).

Differentiation gives

\[
\phi_m'(t)=\frac1m\log\frac{t(m-2+t)}{(1-t)^2}<0
\qquad(0<t<1/m).
\]

The strict inequality is equivalent to \(mt<1\). Also \(\phi_m(1/m)=0\), and \(\Delta_{m,k}=m^{-(k-1)}\phi_m(0)\).

## 4. Sharp threshold and transition envelope

If any transition vanishes, its block has deficit at least \(\phi_m(0)\); every other block has nonnegative deficit. Thus every boundary source has entropy deficit at least \(\Delta_{m,k}\). A deficit sublevel strictly below this value is compact and separated from all zero transitions. The continuous reversal rate therefore has a finite attained maximum there.

To reach the singular threshold, choose any nonpalindromic word \(w=aub\). Put \(P_u=P_0^{a,b}\), and make all other blocks uniform. This source has exactly one zero word, namely \(w\), and its reversed word has positive probability. If \(u\ne u^R\), the reverse block is uniform. If \(u=u^R\), nonpalindromicity means \(a\ne b\), and the reverse entry equals \((m-2)/(m-1)^2>0\).

Mix every block with the uniform matrix using weight \(\epsilon>0\). This preserves uniform windows and makes all transitions positive. In the changed block the mixture is exactly \(P_{\epsilon/m}^{a,b}\). Its entropy deficit is strictly below \(\Delta_{m,k}\), while the reversed positive word contributes a logarithm diverging as \(\epsilon\downarrow0\). Hence every entropy budget at least \(\Delta_{m,k}\) has infinite reversal-rate supremum.

The equality cases are also classified: a boundary source with deficit exactly \(\Delta_{m,k}\) has precisely one changed block, of the displayed fixed-zero form, and all other blocks uniform. It has exactly one zero. It can be the limit of a diverging-rate sequence at this budget only if that zero word is nonpalindromic. A palindromic zero has no distinct reverse entry, and all remaining entries stay positive, preventing divergence.

There is an exact quantitative converse. For \(0\le\delta<\Delta_{m,k}\), let \(t_\delta\in(0,1/m]\) be the unique solution of

\[
\phi_m(t_\delta)=m^{k-1}\delta.
\]

Every allowed transition probability is at least \(t_\delta\). The bound is sharp, attained by one block \(P_{t_\delta}^{a,b}\) and uniform blocks elsewhere. Indeed, if the smallest entry is \(t\le1/m\), the fixed-entry inequality gives \(\phi_m(t)\le m^{k-1}\delta\), hence \(t\ge t_\delta\).

Row normalization also gives an upper transition bound \(1-(m-1)t_\delta\). Consequently

\[
\boxed{\sigma\le\log\frac{1-(m-1)t_\delta}{t_\delta}.}
\]

This last reversal-rate bound is finite and explicit through a monotone scalar inverse. It is not asserted sharp. The transition lower bound is sharp.

## 5. Asymptotically optimal reversal near the threshold

Let \(M_{m,k}(\delta)\) denote the maximum reversal rate under deficit budget \(\delta<\Delta_{m,k}\). Define

\[
C_{m,k}=\begin{cases}
\dfrac{m-2}{m^k(m-1)^2},&k=1,2,\\[6pt]
m^{-(k+1)},&k\ge3.
\end{cases}
\]

Then the stronger, additive asymptotic is

\[
\boxed{M_{m,k}(\delta)=C_{m,k}
\log\frac1{(m-2)t_\delta}+o(1)
\qquad(\delta\uparrow\Delta_{m,k}).}
\]

Thus the explicit fixed-corner family is asymptotically optimal with error tending to zero. This is not a claim that it is the exact maximizer throughout the subcritical regime.

To prove it, take any source with deficit at most \(\Delta_{m,k}\), and let \(t\) be its smallest transition, located at \(w=aub\). Let \(q_t\) be the one-changed-block source with that same entry. The block relative-entropy identity gives the global identity

\[
\delta(q)-\delta(q_t)=D(q\|q_t),
\]

where \(q,q_t\) are normalized length-\((k+1)\) word laws. Since

\[
\Delta_{m,k}-\delta(q_t)=O_{m,k}(t\log(1/t)),
\]

Pinsker's inequality yields

\[
\|q-q_t\|_1=O_{m,k}(\sqrt{t\log(1/t)}).
\]

All entries of \(q_t\) except the designated word stay bounded away from zero as \(t\to0\). The designated entry agrees exactly in \(q\) and \(q_t\). If \(w\ne w^R\), isolate this reversal pair; its perturbation error is at most a constant times \(\|q-q_t\|_1\log(1/t)\). Every other term is locally Lipschitz. Therefore, uniformly over these sources,

\[
\sigma(q)=\sigma(q_t)
+O_{m,k}(\sqrt t\,[\log(1/t)]^{3/2})
=\sigma(q_t)+o(1).
\]

If \(w=w^R\), its own reversal term is identically zero and the same comparison, with bounded derivatives on the remaining entries, holds. Its comparison source is reversible and has rate zero.

The comparison rates can be evaluated exactly. Write

\[
r=\frac{1-t}{m-1},\qquad c=\frac{m-2+t}{(m-1)^2}.
\]

For a nonpalindromic middle context,

\[
\sigma(q_t)=m^{-k}(t-1/m)
\log\frac{t(m-2+t)}{(1-t)^2}.
\]

For a palindromic middle context and distinct endpoint symbols,

\[
\sigma(q_t)=m^{-k}\left\{(t-c)\log(t/c)
+2(m-2)(r-c)\log(r/c)\right\}.
\]

These give, respectively,

\[
\sigma(q_t)=m^{-(k+1)}\log\frac1{(m-2)t}+o(1),
\]

and

\[
\sigma(q_t)=\frac{m-2}{m^k(m-1)^2}
\log\frac1{(m-2)t}+o(1).
\]

All contexts are palindromic when \(k=1,2\). Nonpalindromic contexts become available at \(k=3\), and their coefficient is larger by the factor \((m-1)^2/[m(m-2)]\).

For the upper bound, take maximizing sources as \(\delta\uparrow\Delta_{m,k}\). Their smallest transition must tend to zero, since the explicit family already has diverging rate, whereas a fixed positive transition floor bounds the rate. Apply the uniform comparison, use \(t\ge t_\delta\), and choose the largest available coefficient. For the matching lower bound, take the appropriate comparison family at \(t=t_\delta\), which uses exactly the budget. This proves the boxed asymptotic.

At \(k\ge3\), a maximizing sequence cannot approach a critical source whose middle context is palindromic: its smaller logarithmic coefficient loses by an amount tending to infinity. This is a selection result for limiting context type, not uniqueness of the finite-budget optimizer.

## 6. The logarithm and log-log terms

Let \(\eta=\Delta_{m,k}-\delta\downarrow0\). Expanding the derivative of \(\phi_m\) and integrating gives

\[
\eta=m^{-k}t_\delta
\left\{\log(1/t_\delta)+1-\log(m-2)+O_m(t_\delta)\right\}.
\]

Taking logarithms and substituting once back into the slowly varying term yields

\[
\log(1/t_\delta)=\log(1/\eta)+\log\log(1/\eta)-k\log m+o(1).
\]

Consequently

\[
\boxed{\begin{aligned}
M_{m,k}(\delta)=C_{m,k}\big\{&\log(1/\eta)+\log\log(1/\eta)\\
&-k\log m-\log(m-2)\big\}+o(1).
\end{aligned}}
\]

Both divergent terms and the constant are determined. The \(o(1)\) statement fixes \(m,k\); it is not uniform as alphabet size or memory also grows.

## 7. Three symbols and random-looking bytes

For three symbols and one-step memory, the critical transition matrix is

\[
P_0=\begin{pmatrix}
1/2&0&1/2\\
1/4&1/2&1/4\\
1/4&1/2&1/4
\end{pmatrix}.
\]

Its stationary law is uniform. The forbidden transition \(0\to1\) has reverse probability \(1/4\). Mixing with the uniform matrix makes all entries positive and gives

\[
\Delta_{3,1}=\log3-\frac43\log2
=0.1744160479215159\ldots,
\qquad
\sigma(P_\epsilon)=\frac1{12}\log(1/\epsilon)+O(1).
\]

For the byte example, the certified threshold is enclosed by

\[
2.33744304117622810\times10^{-10}
\le\Delta_{256,3}\le
2.33744304117622811\times10^{-10}.
\]

The entropy therefore exceeds \(8-\Delta_{256,3}/\log2\), which is greater than \(7.99999999966\) bits per byte along the positive-kernel approximations.

To bound direction classification, use the uniform path law as a common reference. Pinsker and the triangle inequality give

\[
\operatorname{TV}(\mathbb P_n,\mathbb P_n^R)
\le\sqrt{2(n-k)\delta}.
\]

Equal-prior optimal success is one half plus half this TV distance. At \(n=1000\), \(m=256\), \(k=3\), and \(\delta\le\Delta_{256,3}\), an integer square-root ceiling certifies

\[
\text{success}\le0.50034135250929594025<0.50034136.
\]

This bound holds uniformly along sources whose reversal rate grows without limit. Large likelihood ratios are concentrated on sufficiently rare words.

## 8. Alphabet-size scaling, verification, and scope

The threshold constant has a positive series:

\[
\phi_m(0)=\sum_{j=1}^{\infty}
\frac1{m j(2j-1)(m-1)^{2j-1}}.
\]

It follows by writing \(q=1/(m-1)\) and expanding
\(\{(1+q)\log(1+q)+(1-q)\log(1-q)\}/(1+q)\).
The series gives the simple bounds

\[
\frac1{m^k(m-1)}\le\Delta_{m,k}
\le\frac{m-1}{m^{k+1}(m-2)}.
\]

In particular \(\Delta_{m,k}\sim m^{-(k+1)}\) as \(m\to\infty\) with fixed \(k\). The threshold is on the scale of one length-\((k+1)\) word's uniform probability.

Run `python3 continuation/alphabet_threshold.py`. The receipt `results/alphabet_threshold.json` records 162 fixed-corner and relative-entropy checks, 108 stationary-flow and entropy checks, and 1,309 exact finite-path identities. It also contains certified transition-floor inversions, positive-series bounds, regularized ternary rates, and the byte example. Closed comparison-rate formulas are checked against direct flow sums. All calculations use standard-library fractions and the existing outward-rounded integer interval library.

The displayed near-threshold examples evaluate the explicit family and its asymptotic errors; they do not numerically solve the global maximization. Global asymptotic optimality follows from the relative-entropy identity and uniform perturbation argument above.

Entropy maximization with prescribed stationary distributions is established literature. A focused search inspected George, Jafarpour, and Bullo's author-hosted paper, \emph{Markov Chains with Maximum Entropy for Robotic Surveillance}, especially Theorem 6, whose adjacency assumptions are symmetric. Our single directed missing transition has asymmetric support. This distinction describes scope, not priority. The primary source is available at \href{https://motion.me.ucsb.edu/pdf/2017b-gjb.pdf}{the authors' site}. See the literature note for other established background. The fixed-corner calculation is elementary; no novelty is claimed for convexity, matrix scaling, or the rare-event mechanism.

No earlier theorem required correction. The general subcritical reversal frontier, exact finite-budget optimizers for larger alphabets, and nonuniform stationary marginals remain open directions. All results remain research drafts pending independent expert review and a broader novelty audit.
