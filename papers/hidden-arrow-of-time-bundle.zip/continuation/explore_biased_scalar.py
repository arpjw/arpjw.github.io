"""Small floating-point falsification attempt, explicitly not a proof."""
from __future__ import annotations

import json
from math import log
from pathlib import Path


def xlog(x: float) -> float:
    return x * log(x) if x else 0.0


def f(p: float, x: float) -> float:
    return xlog(x) + 2 * xlog(p - x) + xlog(1 - 2 * p + x) - 2 * xlog(p) - 2 * xlog(1 - p)


def j(p: float, x: float) -> float:
    return (x - p * p) * (log(x) + log(1 - 2 * p + x) - 2 * log(p - x))


def inverse(p: float, value: float, left: bool) -> float:
    lo, hi = (0.0, p * p) if left else (p * p, p)
    for _ in range(70):
        mid = (lo + hi) / 2
        if (f(p, mid) > value) == left:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def main() -> None:
    rows = []
    for p in (.01, .05, .1, .2, .3, .4, .49, .499):
        for fraction in (.0001, .001, .01, .05, .1, .2, .5, .8, .95, .99):
            value = f(p, 0.0) * fraction
            left, right = inverse(p, value, True), inverse(p, value, False)
            rows.append({'p': p, 'fraction_of_left_boundary_cost': fraction,
                         'anti_minus_identity_rate': j(p, left) - j(p, right)})
    receipt = {'status': 'exploratory double precision; neither interval-certified nor a proof',
               'hypothesis': 'The rare-diagonal one-block family beats the off-diagonal family at every common subcritical cost.',
               'cases': len(rows), 'minimum': min(rows, key=lambda row: row['anti_minus_identity_rate']),
               'rows': rows}
    Path('results/biased_scalar_exploration.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'cases', 'minimum')}, indent=2))


if __name__ == '__main__':
    main()
