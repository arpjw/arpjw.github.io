"""Enclose the coexisting optimizer and slopes using certified transition bounds."""

from fractions import Fraction as Q
import json
from pathlib import Path

from intervals import I, entropy_cost, sinh_cosh


def symmetric_total_field(r: str) -> I:
    low, high = Q(0), Q(3)
    target = I.point(r)
    while high - low > Q(1, 10**25):
        middle = (low + high) / 2
        value = 2 * entropy_cost(I.point(middle)) - target
        if value.hi < 0:
            low = middle
        elif value.lo > 0:
            high = middle
        else:
            raise ArithmeticError("symmetric field precision unresolved")
    return 2 * I.hull(low, high)


def tanh(field: I) -> I:
    s, c = sinh_cosh(field)
    return s / c


def main() -> None:
    source = json.loads(Path("results/transition_certificate.json").read_text())
    roots = []
    for endpoint in ("lower", "upper"):
        candidates = source[endpoint]["unequal_stationary_points"]
        candidates = [item for item in candidates if item["monotonicity_on_isolating_interval"] == "increasing"]
        assert len(candidates) == 1
        roots.append(candidates[0])
    t = I.hull(roots[0]["t_interval"][0], roots[1]["t_interval"][1])
    z = I.hull(roots[0]["z_interval"][0], roots[1]["z_interval"][1])
    u, v = (t + z) / 2, (t - z) / 2
    x, y = tanh(u), tanh(v)
    t0 = I.hull(symmetric_total_field(source["lower"]["budget"]), symmetric_total_field(source["upper"]["budget"]))
    equal = tanh(t0 / 2)
    s, c = sinh_cosh(t)
    _, d = sinh_cosh(z)
    right = 2 + 2 * s / t * (1 + c * d) / (c + d)
    s0, _ = sinh_cosh(t0)
    left = 2 + 2 * s0 / t0
    assert (x - y).lo > I.point("0.35736").hi
    assert (right - left).lo > I.point("1.1555").hi
    report = {
        "status": "PASS: rigorously enclosed first-order jump",
        "prerequisites": "The certified transition interval, monotone stationary root z(t), and the global optimizer uniqueness proof in continuation/003_unique_optimizer.md.",
        "symmetric_bias_magnitude": equal.decimal_bounds(),
        "unequal_larger_bias_magnitude": x.decimal_bounds(),
        "unequal_smaller_bias_magnitude": y.decimal_bounds(),
        "jump_from_zero_in_magnitude_difference": (x - y).decimal_bounds(),
        "left_envelope_derivative": left.decimal_bounds(),
        "right_envelope_derivative": right.decimal_bounds(),
        "upward_derivative_jump": (right - left).decimal_bounds(),
    }
    Path("results/jump_certificate.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
