"""Finite interval cover for uniqueness of the unequal global optimizer.

The infinite tail is handled analytically in 003_unique_optimizer.md.
Acceptance decisions use only the exact integer interval library.
"""

from __future__ import annotations

from fractions import Fraction as Q
import json
from math import factorial
from pathlib import Path

from intervals import I, SCALE, ceil_div, check_library, sinh_cosh
from branch_certificate import branch_coefficients, branch_cost, critical_t, root_z


def even_series(w: I) -> tuple[I, I, I]:
    """cosh(sqrt(w)), sinh(sqrt(w))/sqrt(w), and derivative of the latter."""
    if w.lo < 0 or w.hi > SCALE:
        raise ArithmeticError("series domain is 0 <= w <= 1")
    d, q, qw = I.point(0), I.point(0), I.point(0)
    power = I.point(1)
    for n in range(30):
        d += power / factorial(2 * n)
        q += power / factorial(2 * n + 1)
        qw += (n + 1) * power / factorial(2 * n + 3)
        power *= w
    # Each positive omitted tail is below 100/60! on this domain.
    tail = ceil_div(100 * SCALE, factorial(60))
    return tuple(I(value.lo, value.hi + tail) for value in (d, q, qw))


def regular_cost_derivative(t: I, w: I) -> I:
    """dR(t,z(t))/dt, regular even when the branch starts at z=0."""
    s, c = sinh_cosh(t)
    d, q, qw = even_series(w)
    b, _ = branch_coefficients(t)
    bp = -1 / (t * s.square()) - c / (t.square() * s) - 2 * c / (s.square() * s)
    cp = -(c.square() + 1) / (s.square() * s) - 1 / (t.square() * s) - c / (t * s.square())
    kw = qw - b * q / 2
    if kw.hi >= 0:
        raise ArithmeticError("implicit even derivative unresolved")
    wp = -(-bp * d - cp) / kw
    denominator = (c + d).square()
    rt = (t * (1 + c * d) - s * w * q) / denominator
    rw = (1 + c * d - t * s * q) / (2 * denominator)
    return rt + rw * wp


def implicit_fields(u: I, v: I) -> tuple[I, I, I]:
    """G_u, G_v and derivative of cost with respect to u on G=0."""
    su, cu = sinh_cosh(u)
    sv, cv = sinh_cosh(v)
    a, b = 1 / cu.square(), 1 / cv.square()
    x, y = su / cu, sv / cv
    total = x + y
    difference = u.square() - v.square()
    ell = u / b + difference / total
    ell_u = 1 / b + 2 * u / total - difference * a / total.square()
    ell_v = 2 * u * cv * sv - 2 * v / total - difference * b / total.square()
    gu = a * (2 * x * ell - ell_u)
    gv = 1 - a * ell_v
    if gv.lo <= 0:
        raise ArithmeticError("implicit v derivative unresolved")
    vp = -gu / gv
    return gu, gv, u * a + v * b * vp


def increasing_cost_bound(low: Q, high: Q) -> I:
    zl, zh = root_z(low), root_z(high)
    ul, uh = (I.point(low) + zl) / 2, (I.point(high) + zh) / 2
    vl, vh = (I.point(low) - zl) / 2, (I.point(high) - zh) / 2
    u = I.hull(ul, uh)  # u(t) is strictly increasing analytically.
    v = (I.hull(low, high) - I.hull(zl, zh)) / 2
    if v.lo <= 0:
        raise ArithmeticError("v domain too wide")
    gu, _, bound = implicit_fields(u, v)
    if gu.lo > 0:
        # The first rectangle proves v decreases throughout this interval.
        v = I.hull(vh, vl)
        _, _, bound = implicit_fields(u, v)
    return bound


def cover(low: Q, high: Q, mode: str) -> dict:
    stack = [(low, high)]
    leaves = []
    nodes = 0
    while stack:
        left, right = stack.pop()
        nodes += 1
        if nodes > 200000:
            raise RuntimeError("finite cover budget exceeded; no certificate issued")
        if nodes % 1000 == 0:
            print(mode, "visited", nodes, "nodes;", len(stack), "pending", flush=True)
        bound = None
        try:
            if mode == "negative derivative":
                w = I.hull(root_z(left).square(), root_z(right).square())
                bound = regular_cost_derivative(I.hull(left, right), w)
                accepted = bound.hi < 0
            elif mode == "cost below transition":
                bound = branch_cost(I.hull(left, right), I.hull(root_z(left), root_z(right)))
                accepted = bound.hi < I.point("0.663391796").lo
            elif mode == "positive derivative":
                bound = increasing_cost_bound(left, right)
                accepted = bound.lo > 0
            else:
                raise ValueError(mode)
        except ArithmeticError:
            accepted = False
        if accepted:
            leaves.append({"t": [str(left), str(right)], "bound": bound.decimal_bounds()})
        else:
            middle = (left + right) / 2
            stack.extend([(left, middle), (middle, right)])
    # Exact tiling check: no gaps, no overlaps beyond shared boundaries.
    leaves.sort(key=lambda leaf: Q(leaf["t"][0]))
    position = low
    for leaf in leaves:
        assert Q(leaf["t"][0]) == position
        position = Q(leaf["t"][1])
    assert position == high
    print(mode, "PASS:", nodes, "nodes,", len(leaves), "leaves", flush=True)
    return {"mode": mode, "domain": [str(low), str(high)], "nodes": nodes, "leaves": leaves}


def main() -> None:
    check_library()
    tc = critical_t()
    start = Q(tc.hi, SCALE) + Q(1, 10**7)
    near = regular_cost_derivative(I.hull(Q(tc.lo, SCALE), start), I.hull(0, root_z(start).square()))
    if near.hi >= 0:
        raise AssertionError("near-critical derivative not certified negative")
    report = {
        "status": "PASS: finite interval cover for global optimizer uniqueness",
        "prerequisites": "Analytic stationary curve and infinite-tail proof in continuation/003_unique_optimizer.md.",
        "near_critical": {"critical_field": tc.decimal_bounds(), "upper_field": str(start), "derivative": near.decimal_bounds()},
        "covers": [
            cover(start, Q("2.06"), "negative derivative"),
            cover(Q("2.06"), Q("2.1"), "cost below transition"),
            cover(Q("2.1"), Q(6), "positive derivative"),
        ],
    }
    path = Path("results/uniqueness_certificate.json")
    path.write_text(json.dumps(report, indent=2) + "\n")
    print("Saved", path, flush=True)


if __name__ == "__main__":
    main()
