# Continuation 1: the symmetric optimizer cannot return

This extends the original notebook. The original files remain preserved in `archives/initial-result`. The arguments below are written proofs, not a claim of independent review or established publication priority.

## Result

The first notebook proved that the symmetric optimizer loses globally before it loses locally. We can now prove more:

**There is exactly one budget threshold at which symmetry ceases to be globally optimal. After that threshold, the advantage of the unequal optimum over the symmetric candidate is strictly increasing. Symmetry never regains global optimality.**

This does not yet prove uniqueness of the unequal maximizing pair at every fixed budget. That is a distinct question.

Let

\[
A(x)=\operatorname{atanh}x,\quad
d(x)=\tfrac12[(1+x)\log(1+x)+(1-x)\log(1-x)],
\]

and let `a` be the nonnegative inverse of `d`. As in the first note,

\[
F(r)=\max_{d(x)+d(y)=r,\ x,y\ge0}(x+y)(A(x)+A(y)),\qquad 0<r<\log2.
\]

The symmetric candidate is

\[
S(r)=4a(r/2)A(a(r/2)).
\]

There is a unique `r_t` such that `F(r)=S(r)` for `r <= r_t`, and `F(r)>S(r)` for `r>r_t`. Moreover `F-S` is strictly increasing on `(r_t, log 2)`.

## 1. A single curve contains every unequal stationary point

Put

\[
u=A(x),\quad v=A(y),\quad t=u+v,\quad z=u-v,
\]

with `u>v>0`, hence `0<z<t`. Define

\[
c(u)=u\tanh u-\log\cosh u=d(\tanh u).
\]

The cost and objective become

\[
R(t,z)=\frac{t\sinh t+z\sinh z}{\cosh t+\cosh z}
-\log\frac{\cosh t+\cosh z}{2},
\]

\[
J(t,z)=\frac{2t\sinh t}{\cosh t+\cosh z}.
\]

The Lagrange equations for the original constrained problem reduce, after dividing by positive factors, to

\[
H_t(z)=\frac{\sinh z}{z}-B(t)\cosh z-C(t)=0,
\]

where

\[
B(t)=\frac{t+\sinh t\cosh t}{t\sinh^2t},\qquad
C(t)=\frac{t\cosh t+\sinh t}{t\sinh^2t}.
\]

The value at zero is its continuous extension:

\[
H_t(0)=\frac{t(\cosh t-2)-\sinh t}{t(\cosh t-1)}.
\]

Let `t_c` be the unique positive zero of the numerator. It lies in `(2,3)`. Indeed, the numerator has derivative `t sinh(t)-2`, which strictly increases from `-2` to infinity, so the numerator first decreases and then increases, with exactly one positive zero. At 2 it is negative, using `7 < e^2 < 15/2`; at 3 it is positive.

For completeness, `e^2>7` follows from the first five positive Taylor terms. Their sum is 7, and the remaining terms sum to less than `(4/15)/(1-1/3)=2/5`, giving `e^2<37/5<15/2`.

**Claim.** An unequal stationary point exists at a given `t` exactly when `t>t_c`, and then its `z` is unique.

For `t<=t_c`, we have `H_t(0)<=0` and `B(t)>1/t>=1/t_c>1/3`. In the series

\[
H_t(z)=H_t(0)+\sum_{n\ge1}
\left(\frac1{2n+1}-B(t)\right)\frac{z^{2n}}{(2n)!},
\]

all nonconstant coefficients are negative. Thus there is no positive root.

For `t>t_c`, the constant term is positive. The nonconstant coefficient signs have at most one change, from positive to negative, because `1/(2n+1)` decreases with `n`. Consequently this series has at most one positive root: divide it by the power corresponding to its final positive coefficient. Every remaining term has nonpositive derivative, and some have strictly negative derivative. The quotient is therefore strictly decreasing. Absolute convergence justifies termwise differentiation.

Finally,

\[
H_t(t)=-\frac{2(\sinh t+t\cosh t)}{t\sinh^2t}<0.
\]

There is exactly one root in `(0,t)`, and the derivative with respect to `z` at the root is strictly negative.

Both `B(t)` and `C(t)` strictly decrease. Their derivatives are

\[
B'=-\frac1{t\sinh^2t}-\frac{\cosh t}{t^2\sinh t}
-\frac{2\cosh t}{\sinh^3t}<0,
\]

\[
C'=-\frac{\cosh^2t+1}{\sinh^3t}-\frac1{t^2\sinh t}
-\frac{\cosh t}{t\sinh^2t}<0.
\]

Implicit differentiation therefore gives `z'(t)>0`. All unequal stationary points lie on one smooth curve, parameterized by `t>t_c`.

## 2. An entropy comparison at fixed total field

**Lemma.** For every `t>=2` and `0<z<t`,

\[
c((t+z)/2)+c((t-z)/2)<2c(t/2).
\]

Proof. Write `f(w)=c'(w)=w sech^2(w)` and consider
`g(u)=c(u)+c(t-u)` on `[t/2,t]`. On the interior, the sign of `g'(u)` is the sign of

\[
Q(u)=\log f(u)-\log f(t-u).
\]

This function has `Q(t/2)=0`, tends to infinity as `u` tends to `t`, and is strictly convex, since, putting `v=t-u`,

\[
Q''(u)=\frac1{v^2}-\frac1{u^2}
+2(\operatorname{sech}^2v-\operatorname{sech}^2u)>0.
\]

Thus `g` either increases throughout or first decreases and then increases. Its maximum is attained at one of its two endpoints.

Let `D(t)=2c(t/2)-c(t)`. For `t>=2`,

\[
D'(t)=\frac t2\operatorname{sech}^2(t/2)-t\operatorname{sech}^2t>0,
\]

because `cosh^2(t)>2 cosh^2(t/2)=cosh(t)+1`.

Also `D(2)>0`. To see this without relying on decimal evaluation, put `q=tanh(1)>3/4`. Then

\[
D(2)=\log(1+q^2)-\frac{2q(1-q^2)}{1+q^2}.
\]

The right side is increasing for `q>=3/4`, by direct differentiation, and at `q=3/4` it is `log(25/16)-21/50`. This is positive because

\[
\log(25/16)=2\operatorname{atanh}(9/41)>18/41>21/50.
\]

The symmetric endpoint of `g` is therefore its strict maximum. This proves the lemma.

## 3. Every unequal stationary point has a larger objective slope

Let `lambda` be the Lagrange multiplier, so an unequal stationary pair satisfies `grad J = lambda grad cost`. Its two equations imply

\[
\lambda=
2+\frac{2\sinh t}{t}
\frac{1+\cosh t\cosh z}{\cosh t+\cosh z}.
\]

The last fraction is strictly greater than one for `z>0`.

If the pair has cost `r`, let `t_0=2 A(a(r/2))` be the total field of the symmetric candidate at the same cost. The preceding lemma and `t>t_c>2` imply

\[
r<2c(t/2),\qquad t_0<t.
\]

Direct differentiation gives

\[
S'(r)=2+\frac{2\sinh t_0}{t_0}.
\]

Since `sinh(t)/t` strictly increases for `t>0`, every unequal stationary pair satisfies

\[
\boxed{\lambda>S'(r).}
\]

An additional useful fact is that `lambda` increases strictly along the entire stationary curve as `t` increases. Both `t` and `z(t)` increase, and the function `(CD+1)/(C+D)` increases in each argument for `C,D>1`. This does not alone prove that the entropy cost along that curve is monotone.

## 4. Global consequence

On every compact subinterval of `(0,log 2)`, the envelope `F` is locally Lipschitz. Parameterize the feasible pairs by the fraction `q` of the budget assigned to the larger magnitude, `q in [1/2,1]`; the objective and its budget derivative are uniformly bounded there. At `q=1`, the derivative of the vanishing coordinate has its continuous limiting value, so the square-root behavior of the inverse entropy does not create a singularity in the budget derivative.

At a point where `F` is differentiable, its derivative equals the budget derivative of any maximizing allocation. This follows by holding a maximizing allocation fixed and comparing the envelope at neighboring budgets from both sides. Endpoint allocations with one zero magnitude cannot maximize for positive cost, as established in the original notebook.

If a maximizer is symmetric, its derivative is `S'(r)`. If it is unequal, its derivative is the multiplier `lambda`, which is strictly greater than `S'(r)` by Section 3. Therefore

\[
(F-S)'(r)\ge0
\]

at almost every budget, with strict inequality wherever `F(r)>S(r)`. Local absolute continuity turns these derivative inequalities into monotonicity, and into strict monotonicity on any interval where the gap is positive.

The first notebook proved `F=S` for small budgets and supplied an exactly certified budget with `F>S`. Hence its first transition is unique in the global sense claimed above. The coexistence and discontinuous-jump proof in the original note still applies. What was previously an existence result is now a one-way global transition result.

## Computational checkpoint

`continuation/intervals.py` implements outward-rounded fixed-point interval arithmetic using exact integers, 40 decimal places, positive Taylor series, and explicit remainder bounds. No floating-point values decide a certificate.

`continuation/branch_certificate.py --transition` completed an exhaustive interval cover at each of two rational budgets. It proves symmetry strictly optimal at the lower endpoint and suboptimal at the upper endpoint. Together with the theorem above, this encloses the unique global transition:

\[
0.663391796\le r_t\le0.663391798,
\]

\[
0.95707205425562287138 < r_t/\log2 < 0.95707205714101295317.
\]

See `results/transition_certificate.json`. The two covers visited 16,077 and 16,075 interval nodes and isolated exactly two unequal stationary candidates at each budget. At the lower budget, both lose to symmetry; at the upper budget, one wins. Every other interval is excluded by a rigorous cost bound or monotonicity bound. A direct bound handles the near-critical segment, and `c(3)>r` proves all candidate total fields satisfy `t<6`.

The arithmetic audit `continuation/verify_intervals.py` passed 85,665 exact rational enclosure checks and 19 independent Decimal transcendental diagnostics. These supplement the written series bounds; they are not a proof assistant or independent expert review. The first attempted certificate stopped at an unresolved root comparison. Increasing root precision resolved it; no uncertain comparison was accepted.

The local critical parameter is rigorously enclosed near `t_c = 2.019113099819606200394460...`; its normalized entropy budget is near `0.95742062354747418740822...`.

## Still open here

- Whether the unequal maximizing pair is unique at every budget above the transition.
- A proof that the entropy cost along the stationary curve has exactly one minimum.
- The joint entropy-and-noise constrained frontier at low noise. Continuation 2 solves the sufficiently high-noise regime.
