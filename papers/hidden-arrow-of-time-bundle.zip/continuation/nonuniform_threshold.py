"""Exact rational audits for prescribed nonuniform independent-window laws.

The general threshold and global asymptotic statements are proved in the
accompanying note. This executable checks their algebra and finite examples;
it does not replace the written proofs with numerical optimization.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
import random

from intervals import I, log as ilog

Word = tuple[int, ...]
Matrix = tuple[tuple[Q, ...], ...]


def prod(xs) -> Q:
    value = Q(1)
    for x in xs:
        value *= x
    return value


def xlog(x: Q) -> I:
    return I.point(0) if not x else x * ilog(I.point(x))


def overlap(x: I, y: I) -> None:
    assert x.lo <= y.hi and y.lo <= x.hi, (x, y)


def cost(a: Q, b: Q, z: Q) -> I:
    assert max(Q(0), a + b - 1) <= z <= min(a, b)
    table = (z, a - z, b - z, 1 - a - b + z)
    base = (a * b, a * (1 - b), (1 - a) * b, (1 - a) * (1 - b))
    return sum((x * ilog(I.point(x / y)) for x, y in zip(table, base) if x), I.point(0))


def zero_cost(a: Q, b: Q) -> I:
    assert a + b <= 1
    return xlog(1 - a - b) - xlog(1 - a) - xlog(1 - b)


def corner(pi: tuple[Q, ...], a: int, b: int, z: Q) -> Matrix:
    aa, bb = pi[a], pi[b]
    assert max(Q(0), aa + bb - 1) <= z <= min(aa, bb)
    matrix = tuple(tuple(
        z if (i, j) == (a, b) else
        (aa - z) * pi[j] / (1 - bb) if i == a else
        (bb - z) * pi[i] / (1 - aa) if j == b else
        (1 - aa - bb + z) * pi[i] * pi[j] / ((1 - aa) * (1 - bb))
        for j in range(len(pi))) for i in range(len(pi)))
    assert all(sum(row) == pi[i] for i, row in enumerate(matrix))
    assert all(sum(matrix[i][j] for i in range(len(pi))) == pi[j] for j in range(len(pi)))
    assert all(x >= 0 for row in matrix for x in row)
    return matrix


def divergence(matrix: Matrix, reference: Matrix) -> I:
    return sum((x * ilog(I.point(x / reference[i][j]))
                for i, row in enumerate(matrix) for j, x in enumerate(row) if x), I.point(0))


@dataclass(frozen=True)
class Source:
    pi: tuple[Q, ...]
    k: int
    missing: Word
    z: Q

    def __post_init__(self) -> None:
        assert self.k >= 1 and len(self.missing) == self.k + 1
        assert sum(self.pi) == 1 and all(x > 0 for x in self.pi)
        assert all(0 <= x < len(self.pi) for x in self.missing)
        corner(self.pi, self.missing[0], self.missing[-1], self.z)

    def block_entry(self, w: Word) -> Q:
        assert len(w) == self.k + 1
        if w[1:-1] == self.missing[1:-1]:
            return corner(self.pi, self.missing[0], self.missing[-1], self.z)[w[0]][w[-1]]
        return self.pi[w[0]] * self.pi[w[-1]]

    def transition(self, w: Word) -> Q:
        return self.block_entry(w) / self.pi[w[0]]

    def flow(self) -> dict[Word, Q]:
        m = len(self.pi)
        q = {w: prod(self.pi[x] for x in w[1:-1]) * self.block_entry(w)
             for w in product(range(m), repeat=self.k + 1)}
        for v in product(range(m), repeat=self.k):
            marginal = prod(self.pi[x] for x in v)
            assert sum(q[v + (a,)] for a in range(m)) == marginal
            assert sum(q[(a,) + v] for a in range(m)) == marginal
        assert sum(q.values()) == 1
        return q

    def probability(self, path: Word) -> Q:
        value = prod(self.pi[x] for x in path[:self.k])
        for i in range(self.k, len(path)):
            value *= self.transition(path[i - self.k:i + 1])
        return value

    def deficit(self) -> I:
        a, b = self.pi[self.missing[0]], self.pi[self.missing[-1]]
        r = prod(self.pi[x] for x in self.missing[1:-1])
        return r * cost(a, b, self.z)

    def rate(self) -> I:
        q = self.flow()
        return sum(((v - q[w[::-1]]) * ilog(I.point(v / q[w[::-1]]))
                    for w, v in q.items() if w < w[::-1]), I.point(0))


def threshold_parameters(pi: tuple[Q, ...], k: int) -> tuple[Q, Q, Q, Word] | None:
    assert list(pi) == sorted(pi) and sum(pi) == 1
    p, q = pi[:2]
    if len(pi) == 2 and k <= 2:
        return None
    if k <= 2:
        return p, q, p ** (k - 1), (0,) * k + (1,)
    return p, p, p ** (k - 2) * q, (0, 1) + (0,) * (k - 1)


def compare_rate(pi: tuple[Q, ...], k: int, z: Q, pal: bool) -> I:
    parameters = threshold_parameters(pi, k)
    assert parameters is not None
    a, b, r, _ = parameters
    if not pal:
        return r * (z - a * b) * ilog(I.point(z * (1 - a - b + z) / ((a - z) * (b - z))))
    denominator = (1 - a) * (1 - b)
    c = (1 - a - b + z) * a * b / denominator
    first = (z - c) * ilog(I.point(z / c))
    # Pair the special endpoints with every remaining letter, then sum pi_j.
    others = (1 - a - b) * (a * b - z) / denominator
    ratio = (a - z) * (b - z) * denominator / (a * b * (1 - a - b + z) ** 2)
    return r * (first + others * ilog(I.point(ratio)))


def fixed_entry_audit() -> dict:
    rng = random.Random(140014)
    cases = 0
    laws = ((Q(1, 10), Q(1, 5), Q(7, 10)), (Q(1, 4), Q(1, 4), Q(1, 2)),
            (Q(1, 10), Q(1, 5), Q(3, 10), Q(2, 5)), (Q(1, 3), Q(2, 3)),
            (Q(1, 2), Q(1, 2)))
    for pi in laws:
        m = len(pi)
        base = tuple(tuple(x * y for y in pi) for x in pi)
        for a, b in product(range(m), repeat=2):
            lo, hi = max(Q(0), pi[a] + pi[b] - 1), min(pi[a], pi[b])
            for z in (lo, (lo + pi[a] * pi[b]) / 2, pi[a] * pi[b], (pi[a] * pi[b] + hi) / 2):
                optimum = corner(pi, a, b, z)
                overlap(divergence(optimum, base), cost(pi[a], pi[b], z))
                candidate = [list(row) for row in optimum]
                for _ in range(20):
                    ii = rng.sample(range(m), 2)
                    jj = rng.sample(range(m), 2)
                    if a in ii and b in jj:
                        continue
                    i, h = ii
                    j, l = jj
                    shift = min(candidate[i][l], candidate[h][j]) / 3
                    candidate[i][j] += shift
                    candidate[h][l] += shift
                    candidate[i][l] -= shift
                    candidate[h][j] -= shift
                matrix = tuple(tuple(row) for row in candidate)
                assert matrix[a][b] == z
                assert all(sum(row) == pi[i] for i, row in enumerate(matrix))
                assert all(sum(matrix[i][j] for i in range(m)) == pi[j] for j in range(m))
                # The four group masses and the four constant density ratios
                # are an exact certificate of cross-entropy cancellation.
                masses = [Q(0)] * 4
                ratios = [set() for _ in range(4)]
                for i, j in product(range(m), repeat=2):
                    group = 0 if (i, j) == (a, b) else 1 if i == a else 2 if j == b else 3
                    masses[group] += matrix[i][j]
                    ratios[group].add(optimum[i][j] / base[i][j])
                assert masses == [z, pi[a] - z, pi[b] - z, 1 - pi[a] - pi[b] + z]
                assert all(len(x) == 1 for x in ratios)
                overlap(divergence(matrix, base) - cost(pi[a], pi[b], z), divergence(matrix, optimum))
                if lo == 0:
                    overlap(cost(pi[a], pi[b], Q(0)), zero_cost(pi[a], pi[b]))
                cases += 1
    return {'fixed_margin_and_KL_identity_cases': cases, 'laws': [[str(x) for x in pi] for pi in laws]}


def path_audit() -> dict:
    cases = 0
    sources = 0
    for pi, k in (((Q(1, 10), Q(1, 5), Q(7, 10)), 1),
                  ((Q(1, 10), Q(1, 5), Q(7, 10)), 2),
                  ((Q(1, 10), Q(1, 5), Q(7, 10)), 3),
                  ((Q(1, 3), Q(2, 3)), 3), ((Q(1, 2), Q(1, 2)), 3)):
        a, b, _, word = threshold_parameters(pi, k)
        source = Source(pi, k, word, a * b / 10)
        flow = source.flow()
        dc, sc = Counter(), Counter()
        for w, mass in flow.items():
            t = source.block_entry(w)
            dc[t] += mass
            dc[pi[w[0]]] -= mass
            dc[pi[w[-1]]] -= mass
            sc[t] += mass
            sc[source.block_entry(w[::-1])] -= mass
        n = k + 3
        dp, sp = Counter(), Counter()
        total = Q(0)
        for path in product(range(len(pi)), repeat=n):
            probability = source.probability(path)
            total += probability
            iid_ratio, reverse_ratio = Q(1), Q(1)
            for i in range(n - k):
                w = path[i:i + k + 1]
                t, tr = source.block_entry(w), source.block_entry(w[::-1])
                iid_ratio *= t / (pi[w[0]] * pi[w[-1]])
                reverse_ratio *= t / tr
                dp[t] += probability
                dp[pi[w[0]]] -= probability
                dp[pi[w[-1]]] -= probability
                sp[t] += probability
                sp[tr] -= probability
            assert iid_ratio == probability / prod(pi[x] for x in path)
            assert reverse_ratio == probability / source.probability(path[::-1])
            cases += 1
        assert total == 1
        clean = lambda c: {x: y for x, y in c.items() if y}
        assert clean(dp) == clean({x: (n - k) * y for x, y in dc.items()})
        assert clean(sp) == clean({x: (n - k) * y for x, y in sc.items()})
        sources += 1
    return {'exact_finite_path_checks': cases, 'source_cases': sources}


def threshold_audit() -> dict:
    laws = ((Q(1, 10), Q(1, 5), Q(7, 10)), (Q(1, 5), Q(3, 10), Q(1, 2)),
            (Q(1, 4), Q(1, 4), Q(1, 2)), (Q(1, 3),) * 3,
            (Q(1, 3), Q(2, 3)), (Q(1, 2), Q(1, 2)))
    checked = 0
    rows = []
    for pi in laws:
        for k in range(1, 6):
            parameters = threshold_parameters(pi, k)
            if parameters is None:
                # Every 2 by 2 matrix with equal margins is symmetric.
                for z in (pi[0] ** 2 / 10, pi[0] ** 2, pi[0] / 2):
                    source = Source(pi, k, (0,) * (k + 1), z)
                    assert all(v == source.flow()[w[::-1]] for w, v in source.flow().items())
                    assert source.rate().contains(0)
                rows.append({'pi': list(map(str, pi)), 'k': k, 'reversal_rate_identically_zero': True})
                continue
            a, b, r, missing = parameters
            optimum = r * zero_cost(a, b)
            minimizers = []
            for w in product(range(len(pi)), repeat=k + 1):
                if w == w[::-1] or pi[w[0]] + pi[w[-1]] > 1:
                    continue
                rw = prod(pi[x] for x in w[1:-1])
                value = rw * zero_cost(pi[w[0]], pi[w[-1]])
                # Certify strictness unless the analytic equality parameters match.
                equal = rw == r and sorted((pi[w[0]], pi[w[-1]])) == sorted((a, b))
                if equal:
                    overlap(value, optimum)
                    minimizers.append(''.join(map(str, w)))
                else:
                    assert value.lo > optimum.hi, (pi, k, w, value, optimum)
                checked += 1
            assert ''.join(map(str, missing)) in minimizers
            boundary = Source(pi, k, missing, Q(0))
            boundary.flow()
            assert boundary.block_entry(missing[::-1]) > 0
            rows.append({'pi': list(map(str, pi)), 'k': k, 'threshold_nats': optimum.decimal_bounds(),
                         'minimizing_words': minimizers})
    return {'nonpalindromic_zero_costs_checked': checked, 'examples': rows}


def asymptotic_audit() -> list[dict]:
    rows = []
    for pi, k in (((Q(1, 10), Q(1, 5), Q(7, 10)), 1),
                  ((Q(1, 10), Q(1, 5), Q(7, 10)), 2),
                  ((Q(1, 10), Q(1, 5), Q(7, 10)), 3),
                  ((Q(1, 4), Q(1, 4), Q(1, 2)), 3),
                  ((Q(1, 3), Q(2, 3)), 3), ((Q(49, 100), Q(51, 100)), 3),
                  ((Q(1, 2), Q(1, 2)), 3)):
        a, b, r, missing = threshold_parameters(pi, k)
        s = 1 - a - b
        fair_binary = len(pi) == 2 and pi[0] == Q(1, 2)
        coefficient = r / 2 if fair_binary else r * a * b * (s / ((1 - a) * (1 - b)) if k <= 2 else 1)
        examples = []
        for power in (3, 6, 9, 15):
            z = a * b / 10 ** power
            source = Source(pi, k, missing, z)
            rate = source.rate()
            overlap(rate, compare_rate(pi, k, z, k <= 2))
            gap = r * (zero_cost(a, b) - cost(a, b, z))
            assert gap.lo > 0
            big_l = ilog(1 / gap)
            transition_asymptotic = coefficient * ilog(I.point(Q(1, 2) / z if fair_binary else a * b / (s * z)))
            constant = r if fair_binary else r * a * b / s
            budget_asymptotic = coefficient * (big_l + ilog(big_l) + ilog(I.point(constant)))
            examples.append({'z': str(z), 'threshold_gap': gap.decimal_bounds(),
                             'family_rate': rate.decimal_bounds(),
                             'transition_asymptotic_error': (rate - transition_asymptotic).decimal_bounds(),
                             'budget_asymptotic_error': (rate - budget_asymptotic).decimal_bounds()})
        rows.append({'pi': list(map(str, pi)), 'k': k, 'coefficient': str(coefficient), 'examples': examples})
    return rows


def main() -> None:
    receipt = {'status': 'exact rational checks and outward-rounded logarithms; global theorems are written proofs',
               'fixed_entry': fixed_entry_audit(), 'paths': path_audit(),
               'thresholds': threshold_audit(), 'asymptotics': asymptotic_audit()}
    Path('results/nonuniform_threshold.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'fixed_entry': receipt['fixed_entry']['fixed_margin_and_KL_identity_cases'],
                      'finite_paths': receipt['paths']['exact_finite_path_checks'],
                      'zero_costs': receipt['thresholds']['nonpalindromic_zero_costs_checked'],
                      'asymptotic_source_cases': len(receipt['asymptotics'])}, indent=2))


if __name__ == '__main__':
    main()
