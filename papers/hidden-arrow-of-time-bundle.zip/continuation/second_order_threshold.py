"""Sparse critical sources and certified entropy expansions.

The written proof gives eventual optimality for each fixed k>=3. These
examples certify the candidate values and Taylor bounds, not a numerical
endpoint for that eventual-optimality interval.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path

from intervals import I, ln2, log as ilog
from approximate_uniformity import deficit_interval
from memory_threshold import boundary_flow
from parity_dual import conjectured, flip_ends


def cycle_law_sparse(k: int, period: str) -> dict[str,Q]:
    result=defaultdict(Q)
    for i in range(len(period)):
        word=''.join(period[(i+j)%len(period)] for j in range(k))
        result[word]+=Q(1,len(period))
    return dict(result)


def selected_direction(k: int) -> tuple[str,dict[str,Q]]:
    assert k>=3
    if k%2:
        w='0'+'01'*((k-1)//2)+'1'
        positive,negative=cycle_law_sparse(k,'01'),cycle_law_sparse(k,w)
        scale=Q(1)
    else:
        w='0'*(k-1)+'11'
        positive=cycle_law_sparse(k,'1'+'0'*(k-2))
        negative=cycle_law_sparse(k,'1'+'0'*(k-1))
        scale=Q(k,2)
    # Endpoint flipping selects the negative context-mass perturbation.
    direction={e:scale*(negative.get(e,Q(0))-positive.get(e,Q(0))) for e in positive.keys()|negative.keys()}
    return flip_ends(w),{e:x for e,x in direction.items() if x}


def context_masses(v: dict[str,Q]) -> dict[str,Q]:
    incoming,outgoing=defaultdict(Q),defaultdict(Q)
    for e,x in v.items():
        incoming[e[1:]]+=x
        outgoing[e[:-1]]+=x
    incoming={u:x for u,x in incoming.items() if x}
    outgoing={u:x for u,x in outgoing.items() if x}
    assert incoming==outgoing and sum(v.values())==0
    assert sum(abs(x) for x in v.values())==2
    return incoming


def f(x: Q) -> I:
    return I.point(0) if not x else x*ilog(I.point(x))


def parameters(k: int,w: str,v: dict[str,Q]) -> tuple[Q,Q,Q,Q,Q]:
    h=Q(1,2**k)
    a,u,b=w[0],w[1:-1],w[-1]
    row_other=v.get(str(1-int(a))+u,Q(0))
    col_other=v.get(u+str(1-int(b)),Q(0))
    s=v.get(a+u,Q(0))+row_other
    alpha=col_other-v.get(a+u,Q(0))
    assert alpha==conjectured(k)
    expected=-(1-alpha) if k%2 else -(alpha-Q(1,2))
    assert s==expected
    return h,alpha,s,row_other,col_other


def exact_candidate(k: int,tau: Q) -> I:
    w,v=selected_direction(k)
    masses=context_masses(v)
    h,alpha,s,r,c=parameters(k,w,v)
    assert 0<tau<=h/4
    return (sum((f(h+tau*x)-f(h) for x in v.values()),I.point(0))
            -sum((f(2*h+tau*x)-f(2*h) for x in masses.values()),I.point(0))
            +f(alpha*tau)-f(h+tau*r)-f(h+tau*c)+f(2*h+tau*s))


def coefficients(k: int) -> tuple[I,Q]:
    w,v=selected_direction(k)
    masses=context_masses(v)
    h,alpha,s,r,c=parameters(k,w,v)
    beta=s*ln2()+alpha*ilog(I.point(alpha/h))-alpha
    gamma=(sum(x*x for x in v.values())-r*r-c*c)/(2*h)
    gamma+=(s*s-sum(x*x for x in masses.values()))/(4*h)
    if k==3:
        expected=Q(17,8)
    elif k%2:
        expected=Q(2**k*(3*k*k+10*k-5),16*(k+1)**2)
    else:
        expected=Q(2**k*(3*k*k-k-1),16*(k-1)**2)
    assert gamma==expected
    return beta,gamma


def remainder_bound(k: int,tau: Q) -> Q:
    w,v=selected_direction(k)
    masses=context_masses(v)
    h,alpha,s,r,c=parameters(k,w,v)
    def bound(base: Q,direction: Q) -> Q:
        d=abs(tau*direction)
        return d**3/(6*(base-d)**2)
    return (sum(bound(h,x) for x in v.values())
            +sum(bound(2*h,x) for x in masses.values())
            +bound(h,r)+bound(h,c)+bound(2*h,s))


def main() -> None:
    rows=[]
    for k in (3,4,5,10,11,20):
        w,v=selected_direction(k)
        h,alpha,s,r,c=parameters(k,w,v)
        tau=h/10000
        exact=exact_candidate(k,tau)
        beta,gamma=coefficients(k)
        approximation=2*h*ln2()-alpha*tau*ilog(I.point(1/tau))+beta*tau+gamma*tau*tau
        difference=exact-approximation
        error=remainder_bound(k,tau)
        lower,upper=difference.fraction_bounds()
        assert -error<lower<=upper<error
        if k<=10:
            independent=deficit_interval(boundary_flow(k,w,v,tau))
            assert exact.lo<=independent.hi and independent.lo<=exact.hi
        rows.append({'k':k,'missing_word':w,'nonzero_marginal_entries':len(v),'alpha':str(alpha),
                     'context_mass_slope':str(s),'beta':beta.decimal_bounds(),'gamma':str(gamma),
                     'tau':str(tau),'candidate_deficit':exact.decimal_bounds(),
                     'quadratic_approximation':approximation.decimal_bounds(),
                     'approximation_error':difference.decimal_bounds(),'certified_cubic_error_bound':str(error),
                     'independent_full_flow_check':k<=10})
    # Sparse coefficient construction also works beyond feasible full-word enumeration.
    large=[]
    for k in (21,50,51,100,101):
        w,v=selected_direction(k)
        h,alpha,s,r,c=parameters(k,w,v)
        context_masses(v)
        _,gamma=coefficients(k)
        large.append({'k':k,'alpha':str(alpha),'context_mass_slope':str(s),'support':len(v),'gamma':str(gamma)})
    report={'status':'PASS: sparse exact constructions and outward-rounded Taylor certificates',
            'examples':rows,'larger_sparse_constructions':large,
            'scope':'The written theorem proves eventual optimality, without a quantified tau_0(k). The displayed positive tau examples certify candidate entropy values and Taylor errors; they do not certify that those tau lie below tau_0(k).'}
    Path('results/second_order_threshold.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
