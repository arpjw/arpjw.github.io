# A hidden arrow never needs to spread its entropy budget

Status: written global concentration and convexity proofs, with exact rational and interval audits. Research draft; independent expert review and novelty checking remain open. All logarithms and rates use nats. This removes the small-budget restriction on allocation, not on matrix-optimizer uniqueness.

## 1. The biased-coin allocation is global

Continuation 16 proved concentration in one rarest reversed-context pair for sufficiently small entropy deficits. The restriction can now be removed entirely.

Consider stationary Markov sources of order at most \(k\ge3\), with every length-\(k\) window having exactly the independent binary law \((p,q)^{\otimes k}\), where \(0<p\le1/2\). Let
\[
R=p^{k-2}q,\qquad
T_p(x)=\begin{pmatrix}x&p-x\\p-x&1-2p+x\end{pmatrix},\qquad
f_p(x)=D(T_p(x)\Vert(p,q)^{\otimes2}).
\]
As before, define
\[
A_p(c)=\max_{f_p(x)+f_p(y)\le c}
 (y-x)\{f'_p(y)-f'_p(x)\},
\qquad \Lambda=f_p(0).
\]

**Global binary theorem.** The function \(A_p\) is strictly convex on \([0,\Lambda)\). For every entropy budget strictly below the singular threshold,
\[
\boxed{M_{p,k}(\delta)=R A_p(\delta/R),\qquad 0<\delta<R\Lambda.}
\]
Every optimizer uses exactly one reversed pair of nonpalindromic contexts of weight \(R\), with every other block independent. The optimum is attained by a strictly positive kernel. The scalar maximizer must straddle \(p^2\), as proved in Continuation 16, but its uniqueness throughout the whole range is not asserted here.

The earlier cubic expansion and local uniqueness remain valid. Only their allocation component now extends to every subcritical budget. At and above \(R\Lambda\), the supremum is infinite by Continuation 14. Binary memories one and two remain reversible.

The proof also gives a larger-alphabet theorem: all useful deficit goes into a single orbit of the map that reverses middle contexts. Such an orbit consists of one palindromic context or two distinct reversed contexts. The memory-dependent optimization reduces to at most two matrix problems.

## 2. Two matrix frontiers for any positive symbol law

Let \(\pi\) be a positive probability vector on \(m\ge2\) symbols, and write
\[
\mathcal T_\pi=\{T\ge0:T\mathbf1=\pi,\ T^{\mathsf T}\mathbf1=\pi\},
\qquad B=\pi\otimes\pi,\qquad \Phi(T)=D(T\Vert B).
\]
These are probability matrices, not row-normalized transition matrices. Sort the symbol probabilities and let \(p\le q\) be the two smallest, counting multiplicity. Define
\[
F(a,b)=(1-a-b)\log(1-a-b)
 -(1-a)\log(1-a)-(1-b)\log(1-b),
\]
\[
\Lambda=F(p,p),\qquad \Gamma=F(p,q).
\]
The convention is \(0\log0=0\). For \(m\ge3\), both constants are positive. Define the paired and palindromic matrix frontiers
\[
\begin{aligned}
A_\pi(c)&=\max\{D(P\Vert Q)+D(Q\Vert P):
 P,Q\in\mathcal T_\pi,\ \Phi(P)+\Phi(Q)\le c\},\\
P_\pi(c)&=\max\{D(T\Vert T^{\mathsf T}):
 T\in\mathcal T_\pi,\ \Phi(T)\le c\}.
\end{aligned}
\]
The first maximum is considered for \(0\le c<\Lambda\); every feasible entry is then positive. The second is considered for \(0\le c<\Gamma\); its off-diagonal entries are positive, while diagonal zeros are allowed and contribute zero to the objective. It is a maximum on the closed transport polytope and equals the positive-matrix supremum. For binary laws, \(P_\pi\equiv0\), and \(A_\pi=A_p\).

**Matrix convexity theorem.** For \(m\ge2\), \(A_\pi\) is strictly convex on \([0,\Lambda)\). For \(m\ge3\), \(P_\pi\) is strictly convex on \([0,\Gamma)\). Each vanishes at zero, is strictly increasing, and has a strictly increasing ratio to its budget. Each is strictly greater than \(4c\) for positive \(c\) in its stated range.

The matrices themselves can have more than one maximizing configuration. Strict convexity of the optimal value as a function of budget does not establish uniqueness of an optimizer or rule out phase transitions.

## 3. A positive-series lemma

Let
\[
C(v)=b_0+\sum_{j\ge1}b_jv^j,\qquad
b_0\ge0,\quad b_j>0\ (j\ge1),
\]
be convergent for \(0\le v<v_*\). Suppose its limiting boundary cost is at least a target \(L>b_0\). For \(b_0<c<L\), invert \(C(v)=c\) and define
\[
\mathcal R(c)=4vC'(v).
\]
Extend \(\mathcal R(c)=0\) on \(0\le c\le b_0\). The inverse exists since \(C'>0\). On the active interval,
\[
\mathcal R'(c)=4\left(1+\frac{vC''(v)}{C'(v)}\right).
\]
The expression \(vC''/C'\) is the mean of \(j-1\) under weights proportional to \(jb_jv^{j-1}\). Its derivative with respect to \(\log v\) is the variance of \(j-1\), which is strictly positive because \(b_1,b_2>0\). Consequently
\[
\mathcal R''(c)>0\qquad(b_0<c<L).
\]
At the join, the right derivative is \(4\), while the left derivative is zero. Thus the extension is convex everywhere, and strictly convex on every interval with a nonempty active portion. If \(b_0=0\), it also gives \(\mathcal R(c)>4c\).

An equivalent direct calculation is
\[
\mathcal R''(c)=\frac{4\{(C''+vC''')C'-v(C'')^2\}}{(C')^3}>0.
\]
The variance identity proves its sign on the entire convergence interval. The finite interval audits below evaluate this expression at sample rays but are not the proof of its universal sign.

## 4. Every matrix pair lies on such a ray

For a pair of positive matrices, write
\[
P=M+hV,\qquad Q=M-hV,\qquad v=h^2,
\]
where \(M\in\mathcal T_\pi\), and \(V\) has zero row and column sums. Keep \(M,V\) fixed and vary \(h\). Entrywise Taylor expansion of \(x\log x\) gives
\[
C(v)=\Phi(M+hV)+\Phi(M-hV)
 =2\Phi(M)+\sum_{j\ge1}
 \frac{2v^j}{(2j)(2j-1)}
 \sum_{a,b}\frac{V_{ab}^{2j}}{M_{ab}^{2j-1}}.
\]
For a nonzero direction, all nonconstant coefficients are positive. The series converges until the first varying entry reaches zero, since
\(h<\min_{V_{ab}\ne0}M_{ab}/|V_{ab}|\).
Furthermore,
\[
D(P\Vert Q)+D(Q\Vert P)
 =2h\frac{d}{dh}\{\Phi(M+hV)+\Phi(M-hV)\}
 =4vC'(v).
\]
The first equality follows by differentiating the cost: its derivative is
\(\sum_{ab}V_{ab}\log(P_{ab}/Q_{ab})\).

By Continuation 14's fixed-entry entropy projection, any transport matrix with any feasible zero costs at least \(\Lambda\). Therefore the first boundary on any such paired ray has total cost at least \(\Lambda\). Every paired ray with initial cost below \(\Lambda\) satisfies the lemma on the entire budget interval up to \(\Lambda\). Centers with zero entries cannot be active there, since their cost alone already reaches the relevant boundary bound.

For the palindromic problem use
\[
M=\frac{T+T^{\mathsf T}}2,
\qquad V=\frac{T-T^{\mathsf T}}2.
\]
Here \(M\) is symmetric, \(V\) is antisymmetric, and the transpose of \(M+hV\) is \(M-hV\). The cost is now
\[
C(v)=\Phi(M+hV)
 =\Phi(M)+\sum_{j\ge1}
 \frac{v^j}{(2j)(2j-1)}
 \sum_{a,b}\frac{V_{ab}^{2j}}{M_{ab}^{2j-1}}.
\]
Its reversal objective is again \(4vC'(v)\), half the paired objective. Coordinates with \(M_{aa}=V_{aa}=0\) are omitted from the sum. All varying coordinates are off diagonal. At the first boundary, an off-diagonal entry vanishes, and the fixed-entry projection gives cost at least \(\Gamma\). Diagonal zeros already present at the center do not interfere with this argument.

For clarity, the boundary bounds use only the previously proved fact that a zero entry with endpoint probabilities \(a,b\) costs at least \(F(a,b)\), and that \(F\) increases in each argument on its feasible domain. The cheapest arbitrary zero has \(a=b=p\). The cheapest off-diagonal zero has the two smallest distinct-index probabilities \(p,q\). An entry whose margins sum to more than one cannot vanish.

## 5. Taking the envelope preserves strict convexity here

Each nonzero ray supplies the convex profile from Section 3, extended by zero below its center cost. Such a profile is defined throughout the relevant common interval \([0,\Lambda)\) or \([0,\Gamma)\), because its first boundary costs at least that interval's endpoint. Rays whose center costs more than the interval contribute only zero and can be ignored.

The frontier is the pointwise supremum of these profiles. This proves convexity, but strictness needs an additional argument. At every positive budget, a nonzero feasible direction from \(B\) gives positive value. In the paired case any nonzero transport tangent direction works; in the palindromic case a three-symbol antisymmetric cycle works. A maximum exists by compactness: below the respective threshold all entries relevant to the objective are bounded away from zero.

Take \(0\le c_1<c_2<L\) and an intermediate budget \(c\). Choose a maximizing matrix configuration at \(c\). Its value is positive, so its ray is active. It uses the whole budget, since its ray profile is strictly increasing and can continue to every budget below \(L\). That ray's profile has strict curvature on a nonempty portion of \([c_1,c_2]\), so its value at \(c\) is strictly below the chord between its values at \(c_1,c_2\). Those endpoint values are no larger than the corresponding frontier values. This proves strict convexity of the frontier itself.

Because the frontier vanishes at zero, strict convexity makes its ratio to budget strictly increasing. The ray from \(B\) starts with zero center cost, so the same lemma also proves the strict \(4c\) lower bound. This completes the matrix convexity theorem.

## 6. Exact allocation at every memory and alphabet

Recall the transport-block formula for a stationary source with independent length-\(k\) law \(\pi^{\otimes k}\):
\[
Q(aub)=r_uT_u(a,b),\qquad r_u=\prod_{x\in u}\pi_x,
\]
\[
\delta=\sum_u r_u\Phi(T_u),\qquad
\sigma=\sum_{u,a,b}r_uT_u(a,b)
 \log\frac{T_u(a,b)}{T_{u^R}(b,a)}.
\]
A palindromic context gives the frontier \(r_uP_\pi(d/r_u)\). A pair of distinct reversed contexts gives \(r_uA_\pi(d/r_u)\), after transposing its second block. The least palindromic context weight is
\[
r_0=p^{k-1}.
\]
For \(k\ge3\), the least nonpalindromic context weight is \(R=p^{k-2}q\). For \(m\ge3\), the sharp singular threshold is \(r_0\Gamma\) at memories one and two, and \(R\Lambda\) at memory at least three. The inequality
\[
R\Lambda\le r_0\Gamma
\]
was proved in Continuation 14, equivalently \(qF(p,p)\le pF(p,q)\).

**Global allocation theorem.** For \(m\ge3\), throughout the subcritical range,
\[
\boxed{M_{\pi,k}(\delta)=r_0P_\pi(\delta/r_0),\qquad k=1,2,}
\]
\[
\boxed{M_{\pi,k}(\delta)=
 \max\{r_0P_\pi(\delta/r_0),\ R A_\pi(\delta/R)\},\qquad k\ge3.}
\]
For binary laws, the palindromic term vanishes and the second formula is exactly the binary theorem in Section 1.

To prove this, let an orbit use deficit \(d_i\) and have frontier \(F_i\), including its context weight. Its strictly increasing value-to-budget ratio gives, whenever \(0<d_i\le\delta\),
\[
F_i(d_i)\le\frac{d_i}{\delta}F_i(\delta).
\]
Every term \(F_i(\delta)\) is well defined below its threshold by the preceding bounds. Summing yields
\[
\sigma\le\sum_i\frac{d_i}{\delta}F_i(\delta)
 \le\max_iF_i(\delta).
\]
The ratio is strictly increasing, so equality requires one active orbit with \(d_i=\delta\). All other blocks must equal \(B\). Within either orbit type, the same ratio property shows that \(rF(\delta/r)\) strictly decreases with context weight \(r\). Hence only the least weight of each type matters, giving the displayed formulas and all allocation equality cases. Zero-rate orbits cannot receive deficit at a positive optimum.

The paired matrix maximum has positive entries and therefore constructs a positive-kernel source. The palindromic maximum can lie on a diagonal boundary; mixing its block with \(B\) makes every entry positive, decreases the deficit, and approaches its reversal value. Thus the formulas are exact for the originally defined positive-kernel supremum. We do not assert positive attainment for every larger-alphabet palindromic optimum.

Each nontrivial global frontier is strictly convex in the entropy budget below its singular threshold. If the two orbit types tie, either can be selected, but distributing deficit between them is still strictly worse. The matrix problems have dimension depending on the alphabet, while the memory enters only through \(r_0\) and \(R\).

## 7. Audits, scope, and the next question

Reproduce with `python3 continuation/global_concentration.py`.

The receipt `results/global_concentration.json` records:

- 304 exact positive even-series coefficients across 19 paired or palindromic rays on two-, three-, and four-symbol laws.
- 19 certified boundary-cost comparisons and 76 interval evaluations of the rate identity, strict curvature, and increasing rate-to-cost ratio. One ray has a zero rare diagonal at its symmetric center, explicitly checking the allowed palindromic boundary case.
- 18 full stationary-flow examples, totaling 4,000 word probabilities, checking both length-\(k\) marginals and the entropy/reversal formulas.

These finite checks are corroboration. The all-budget and arbitrary-alphabet conclusions follow from the positive-series and envelope proofs, not from an exhaustive numerical search. The implementation uses standard-library fractions and the previously audited outward-rounded interval logarithms.

A separate `explore_biased_phase.py` run examines 253 cases using double precision. It finds competing branches at \(p=2/5\), with opposite orderings at \(0.985\Lambda\) and \(0.99\Lambda\). This suggests a discontinuous optimizer change but does not certify one. An initial uniform grid missed narrow near-boundary peaks; adding logarithmic edge sampling recovered them. The revised search remains nonexhaustive, and its receipt is labeled numerical exploration.

No prior theorem required correction. The local allocation restriction in Continuation 16 is strengthened, and binary subcritical positive attainment is now established globally. Its explicit uniqueness cutoff remains open. Larger-alphabet positive attainment on the palindromic branch remains open as well.

The next substantive question is the shape and uniqueness of the biased-binary scalar optimizer, and the comparison of the two matrix frontiers for larger alphabets. The original fair-binary phase transition shows why strict convexity of the value cannot settle these optimizer questions. A positive transition floor also interrupts a ray before a zero, so the present proof cannot simply be reused for the nonuniform noise-floor problem.

KL and Jeffreys divergence geometry, convex envelopes, and positive-series variance identities are standard ingredients. The constrained allocation result is a derivation in this notebook. A focused additional search did not establish priority; novelty and independent expert validation remain unresolved.
