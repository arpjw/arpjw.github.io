# The jump survives a biased coin

Status: written perturbation and global-selection proof, using certified fair-transition enclosures and new outward-rounded coefficient bounds. Independent expert review and novelty verification remain open. The allowed bias neighborhood is positive but not quantified. All costs and rates use nats.

## 1. A first-order transition without an exactly fair coin

The fair-binary problem has a certified discontinuous optimizer change at
\[
0.663391796\le c_*\le0.663391798.
\]
Its three scalar maximizers at coexistence are a symmetric pair and two reflected unequal pairs. A small coin bias removes the equality between the reflected pairs, but the discontinuous change survives.

Write
\[
p=(1-s)/2,\qquad q=(1+s)/2,\qquad s\ge0,
\]
and use the correlation coordinate
\[
x=p^2+pqz,
\qquad
T_s(z)=\begin{pmatrix}
p^2+pqz&pq(1-z)\\pq(1-z)&q^2+pqz
\end{pmatrix}.
\]
The independent block is \(z=0\). Define
\[
\phi_s(z)=D(T_s(z)\Vert(p,q)^{\otimes2}),
\qquad
J_s(z_-,z_+)=(z_+-z_-)\{\phi_s'(z_+)-\phi_s'(z_-)\}.
\]
The scalar frontier \(A_p(c)\) maximizes \(J_s\) under
\(\phi_s(z_-)+\phi_s(z_+)\le c\). The maximizer straddles zero below the singular threshold.

**Persistence theorem.** There are \(\varepsilon,\eta>0\) and a function \(c_t(s)\), analytic in \(s^2\) near zero, such that for every \(0<s<\varepsilon\) and \(|c-c_*|<\eta\):

- Below \(c_t(s)\), there is a unique unordered scalar maximizing pair, close to the fair symmetric pair.
- Above \(c_t(s)\), there is a unique unordered scalar maximizing pair, close to the fair unequal pair with the larger negative correlation magnitude.
- At \(c_t(s)\), exactly these two pairs maximize. Their correlation-magnitude imbalance jumps by more than \(0.35\), and the derivative of the optimal value with respect to \(c\) jumps upward by more than \(1.1\), after shrinking \(\varepsilon\) if necessary.

The transition moves according to
\[
\boxed{c_t(s)=c_*+\beta s^2+O(s^4),\qquad
 -78.212<\beta<-78.200.}
\]
Thus a small bias lowers the normalized entropy budget at which the jump occurs. Time reversal still gives an equally good process; the selected pair type suppresses the rare diagonal more strongly, rather than choosing a direction of time.

For memory \(k\ge3\), Continuation 17's global concentration theorem transfers this statement directly to the source problem:
\[
\delta_t(s)=p^{k-2}q\,c_t(s).
\]
The choice of a rarest reversed-context pair remains a symmetry of the construction. No explicit \(\varepsilon\) is certified here. In particular, this theorem does not certify the previously observed candidate transition at \(p=2/5\).

## 2. Certified inputs at the fair transition

At \(s=0\), write
\[
d(z)=\frac{1+z}{2}\log(1+z)+\frac{1-z}{2}\log(1-z),
\qquad A(z)=\operatorname{atanh}z.
\]
The three maximizing correlation pairs are
\[
(-h,h),\qquad(-a,b),\qquad(-b,a),\qquad a>b>0.
\]
Continuations 1 and 3 prove that these are all the fair maximizers at \(c_*\). Their certified enclosures, rounded outward here, are
\[
\begin{aligned}
h&\in[0.7654588611,\ 0.7654588654],\\
a&\in[0.9063240880,\ 0.9063265929],\\
b&\in[0.5489575401,\ 0.5489595754].
\end{aligned}
\]
Let \(\lambda_0\) and \(\lambda_1\) be the budget derivatives of the central and unequal branches. The existing jump certificate gives
\[
1.1555315596<\lambda_1-\lambda_0<1.1555504276,
\qquad a-b>0.35736.
\]
The new certificate also verifies nondegeneracy directly. If \(x<0<y\), let
\[
v=(A(y),-A(x)),\qquad
Q=v^{\mathsf T}\{\nabla^2J_0-\lambda\nabla^2[d(x)+d(y)]\}v.
\]
The tangent vector \(v\) is nonzero and preserves the cost to first order. Exact outward-rounded evaluation gives
\[
Q(-h,h)<-0.015,\qquad
Q(-a,b)=Q(-b,a)<-0.08.
\]
Therefore all three coexisting fair maxima have strictly negative constrained second derivative. These are sign certificates, not observations inferred from plots. They supply the nondegeneracy needed for the implicit-function argument.

## 3. The bias expansion in correlation coordinates

Swapping the two symbols sends \(s\) to \(-s\) and interchanges the diagonal entries of \(T_s(z)\). Hence \(\phi_s(z)\) is even in \(s\). On compact interior correlation intervals it is analytic in \(w=s^2\), with expansion
\[
\boxed{\phi_s(z)=d(z)+w\,u(z)+O(w^2),}
\]
\[
u(z)=(1-z)\operatorname{atanh}z-\frac{z}{1+z},
\qquad
u'(z)=-\operatorname{atanh}z+\frac{z}{(1+z)^2}.
\]
The remainders are uniform with the finitely many derivatives used below on a fixed neighborhood of the coexisting pairs.

To derive the coefficient, put \(a_0=(1+z)/4\), \(d_0=(1-z)/4\). The two diagonal entries are
\(a_0\pm s/2+d_0s^2\), and the off-diagonal entries are \(d_0(1-s^2)\). Expand \(t\log t\) entry by entry and subtract twice the symbol entropy term. The coefficient of \(s^2\) is
\[
2d_0\log(a_0/d_0)+\frac1{4a_0}-1
 =(1-z)\operatorname{atanh}z-\frac{z}{1+z}.
\]
This also shows why the leading shift is quadratic in the coin bias. The lower endpoint of the full correlation domain moves with \(s\), but all three transition configurations lie a fixed distance inside that domain. No expansion at the singular boundary is used.

For a stationary fair pair \((-a,b)\) with multiplier \(\lambda\), the derivative of its optimized value with respect to \(w\), at fixed budget, is
\[
\boxed{E(a,b;\lambda)=
(a+b)\{u'(b)-u'(-a)\}
 -\lambda\{u(-a)+u(b)\}.}
\]
Indeed the parameter derivative of the Lagrangian is the displayed expression; the derivatives of the optimizing coordinates cancel by stationarity. Let
\[
E_L=E(a,b;\lambda_1),\quad E_R=E(b,a;\lambda_1),
\quad E_0=E(h,h;\lambda_0).
\]
The interval certificate yields
\[
\begin{aligned}
101.67618&<E_L<101.68744,\\
1.69562&<E_R<1.69586,\\
11.31141&<E_0<11.31142,\\
99.98032&<E_L-E_R<99.99182.
\end{aligned}
\]
Thus a positive small bias favors the pair with the larger negative correlation magnitude. The separation of the two reflected optimized values starts at a strictly positive multiple of \(s^2\).

## 4. Why no untracked maximizer can intervene

A local implicit-function calculation alone would not prove a global transition. We now reduce the full nearby optimization to the three tracked branches.

Use the signed entropy coordinate
\[
e=\operatorname{sgn}(z)\sqrt{2\phi_s(z)},\qquad z=v_w(e).
\]
Near the compact set relevant to the fair transition, its inverse is analytic in \((w,e)\). At zero this follows from \(\phi_s''(0)=1\); away from zero it follows from strict convexity and a nonzero derivative. The even dependence on \(s\) supplies an analytic extension in \(w\) around zero.

Every straddling cost-\(c\) pair is parameterized by the fixed compact interval
\[
\begin{aligned}
z_-&=v_w(-\sqrt{2c}\cos\theta),\\
z_+&=v_w(\sqrt{2c}\sin\theta),
\qquad 0\le\theta\le\pi/2.
\end{aligned}
\]
Choose \(\eta\) and the bias range small enough that these pairs remain interior and the budget remains below the biased law's singular threshold. This is possible since \(c_*<\log2\) and the threshold is continuous at fairness. The resulting objective is analytic near the three fair maxima and continuous uniformly on the full compact parameter interval.

At \((w,c)=(0,c_*)\), exactly three points maximize. Choose disjoint small neighborhoods of them. Compactness gives a strict value gap on the complement. Uniform continuity preserves that gap for all sufficiently small \(|w|\) and \(|c-c_*|\). The negative constrained curvatures in Section 2 give, after shrinking the neighborhoods, strict local concavity in each and one analytic stationary maximizing branch by the implicit-function theorem.

Consequently the nearby global optimum is exactly the maximum of three analytic value branches,
\[
V_0(c,w),\qquad V_L(c,w),\qquad V_R(c,w).
\]
This step rules out a maximizer emerging elsewhere in the feasible set. It uses the earlier exhaustive fair-transition result, not a new numerical scan.

## 5. Selecting the branch and locating the shifted crossing

At \(w=0\), reflection symmetry gives \(V_L(c,0)=V_R(c,0)\) throughout a neighborhood of \(c_*\). The positive certified difference \(E_L-E_R\) and continuity imply
\[
V_L(c,w)-V_R(c,w)>0
\]
for all sufficiently small positive \(w\) and nearby \(c\). The reflected branch is therefore globally excluded in this neighborhood.

Put \(D(c,w)=V_L(c,w)-V_0(c,w)\). At the fair crossing,
\[
D(c_*,0)=0,\qquad
D_c(c_*,0)=\lambda_1-\lambda_0>1.15.
\]
The implicit-function theorem supplies a unique analytic crossing \(c=c_t(w)\). After restricting to a sufficiently small rectangle, \(D_c>0\) everywhere there. Hence the central branch uniquely wins below the crossing and the selected unequal branch uniquely wins above it; exactly two maximize on the crossing.

Differentiating \(D(c_t(w),w)=0\) gives
\[
\beta=c_t'(0)=-\frac{E_L-E_0}{\lambda_1-\lambda_0}.
\]
The exact interval arithmetic encloses this ratio in
\[
[-78.2116456711,\ -78.2006299865]
 \subset(-78.212,-78.200).
\]
Returning to \(w=s^2\) proves the displayed transition expansion.

For the signed correlation-magnitude imbalance
\(g=-z_--z_+\), the two coexisting branches tend to \(0\) and \(a-b\). Their jump therefore tends to the previously certified value above \(0.35736\). The slope jump tends to \(\lambda_1-\lambda_0>1.1555\). Continuity gives the conservative \(0.35\) and \(1.1\) bounds in the theorem on a possibly smaller, still positive bias interval.

This proves persistence, local branch uniqueness, and orientation selection together. The word local refers to the neighborhood of the transition in bias and budget; every maximum compared inside that neighborhood is a global maximum over the full scalar feasible set.

## 6. Reproducibility and limits

Reproduce with `python3 continuation/biased_transition_persistence.py`.

The receipt `results/biased_transition_persistence.json` hashes its two prerequisite certificates and records new outward-rounded bounds for both curvatures, three perturbation coefficients, the reflection preference, the crossing slope, and the quadratic transition shift. Fourteen additional checks audit the entrywise expansion and its derivative identity.

A separate 85-digit Decimal calculation solves the coexistence equations at fairness and at biases \(10^{-4}\), \(10^{-5}\), and \(10^{-6}\).

The resulting ratios \((c_t(s)-c_t(0))/s^2\) are approximately
\[
-78.20316276,\qquad -78.20611330,\qquad -78.20614295.
\]
These are solutions of stationary coexistence equations, not interval-certified global optima or proof that those particular biases lie within the theorem's unspecified neighborhood. An initial undamped Newton attempt at \(s=10^{-3}\) failed from the fair seed; the receipt preserves that failure and draws no mathematical conclusion from it.

No earlier theorem required correction. The finite-bias \(p=2/5\) transition remains a numerical conjecture. An explicit bias cutoff, the full biased phase diagram, and a possible endpoint of its first-order transition curve remain open. The proof uses standard compactness and implicit-function ideas; the specific certified perturbation coefficients and constrained optimization result are derivations in this notebook, with novelty and external validation unresolved.
