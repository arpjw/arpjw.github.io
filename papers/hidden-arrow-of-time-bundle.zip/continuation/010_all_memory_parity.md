# Continuation 10: the parity formula at every memory length

Status: a computer-assisted theorem. A graph and word-overlap proof covers every memory length k>=10; 494 exact rational primal/dual certificates cover k=3,...,9. The previous all-memory conjecture is resolved within this draft. Independent expert review and novelty verification remain open.

## 1. The theorem

The coefficient in Continuation 9 has the exact formula

\[
\boxed{
\alpha_k=
\begin{cases}
\dfrac12+\dfrac1{k+1},&k\ge3\text{ odd},\\[4pt]
\dfrac12+\dfrac1{2(k-1)},&k\ge4\text{ even}.
\end{cases}}
\]

Consequently, for each fixed \(k\ge3\),

\[
T_k(\tau)=2^{1-k}\log2-\alpha_k\tau\log(1/\tau)+O_k(\tau).
\]

The explicit upper and lower threshold bounds from Continuation 9
remain valid with this closed coefficient. The big-O constant is
allowed to depend on memory. This result does not identify the exact
threshold at a fixed positive tolerance for general memory.

Two periodic-cycle constructions already prove the lower bounds at
all memory lengths. The new work is the matching upper bound.
Its reason is combinatorial: short cycles in the de Bruijn graph
are the only local obstructions to a baseline bound of one half.
A two-cycle creates the larger odd-memory correction; a triangle
near a constant word creates the even-memory correction.

## 2. The coefficient and three symmetries

Put \(n=k-1\). The directed binary de Bruijn graph has vertices of
length \(n\) and edges of length \(k\); an edge runs from its prefix
to its suffix. For a nonpalindromic word \(w=aub\), the two marked
edges are

\[
e_-=au,\qquad e_+=u(1-b).
\]

The objective is \(\ell_w(v)=v_{e_+}-v_{e_-}\), over stationary
signed flows satisfying \(\sum_e v_e=0\) and \(\sum_e|v_e|\le2\).
A dual witness consists of \(g\) on vertices and \(\lambda,t\) with

\[
|\ell_w(e)+g(\operatorname{tail}e)-g(\operatorname{head}e)
+\lambda|\le t\quad\text{for every edge }e.
\]

It proves \(\alpha_w\le2t\), since both incidence and total-mass
terms vanish on a feasible flow.

Complementation and reversal preserve \(\alpha_w\), as proved in
Continuation 9. There is a third useful symmetry: flipping both
endpoints preserves it too. With \(w'=(1-a)u(1-b)\), conservation gives

\[
\ell_{w'}(v)=-\ell_w(v).
\]

The feasible set is centrally symmetric, so the maxima agree.
As edge coefficient vectors, the two objectives add to the incidence
row for vertex \(u\). Thus endpoint flipping negates the dual mass
multiplier, with a corresponding change to the vertex potential.

If \(u\) is constant, nonpalindromicity forces \(a\ne b\).
Either the marked edges coincide, or their flows agree by conservation
at the constant vertex. Hence \(\alpha_w=0\). We assume below that
\(u\) is nonconstant and the marked edges are distinct.

## 3. A dual criterion using cycles

Write

\[
p=t+\lambda,\qquad q=t-\lambda,
\]

and assume \(p,q\ge0\). Replace every original edge \(x\to y\)
by two constraint arcs:

- a forward arc \(x\to y\) with cost \(p+\ell_w(e)\);
- a backward arc \(y\to x\) with cost \(q-\ell_w(e)\).

The dual inequalities are precisely the difference constraints
\(g(y)\le g(x)+\text{cost}(x,y)\). Such a potential exists if every
directed cycle has nonnegative cost: add a source with zero-cost arcs
to every vertex and take shortest-path distances. In a finite graph
without a negative cycle, removing nonnegative cycles leaves finitely
many simple paths, so these distances are finite and satisfy all
constraints. Conversely, a negative cycle contradicts the sum of the
constraints around that cycle.

Only two arcs can have negative costs: the forward copy of \(e_-\)
and the backward copy of \(e_+\). **Both enter \(u\).** A simple
cycle therefore contains at most one of them.
If it also contains a marked arc with a positive unit contribution,
the unit terms cancel and its cost is nonnegative. Otherwise it uses
exactly one marked edge and its cost is

\[
pF+qB-1,
\]

where \(F,B\) count forward and backward constraint arcs.
Call such a cycle critical. It is enough to prove

\[
pF+qB\ge1\quad\text{for every critical simple cycle}.
\]

For \(p=q=1/4\), only critical cycles of length at most three can
cause trouble. A forward/backward traversal of the same original
edge has cancelling unit terms and is not critical.

## 4. Two elementary word-overlap facts

### Short cycles

For \(n\ge2\), an original edge is determined by its tail and head,
so there are no parallel edges in the same direction.
A loop is a constant word. A two-cycle consists of the two alternating
words. A triangle is one of two types:

- a directed three-cycle, coming from a primitive period-three word;
- a mixed triangle with vertices
\[
c^n,\qquad (1-c)c^{n-1},\qquad c^{n-1}(1-c),
\]
with edges from the second vertex to the first and third, and from
the first to the third.

For the mixed case, orient its long side as a directed two-step path
and its shortcut as a directed one-step path with the same endpoints.
The overlap equations force the middle vertex to be constant; the
other two vertices must be the displayed distinct alternatives.
This proves the classification. A short cycle touching a marked edge
passes through \(u\), so only constant, almost-constant, alternating,
or period-three contexts need special treatment.

### One arc against the others

Suppose a simple cycle has a directed path of length \(m\ge2\)
and one edge in the opposite traversal direction, a shortcut with
the same initial and final vertices. Write the long path as a word
\(x_0\cdots x_{n+m-1}\). The shortcut imposes

\[
x_{m+j}=x_{j+1}\quad(0\le j\le n-2).
\]

Therefore the central word

\[
x_1\cdots x_{n+m-2}
\]

has period \(m-1\). The interior of every edge word in this cycle,
obtained by deleting its first and last bits, is a substring of this
central word, so it also has period \(m-1\).

We will also use two direct consequences of periodicity:

- A period-\(d\) word containing an alternating block of length at least
\(d+1\) must have even \(d\), and then the whole word is alternating.
Indeed an odd shift would equate opposite bits; an even shift and
one full period determine every residue class.
- A word with periods 3 and \(d\), where \(d\) is not divisible by 3,
is constant if its length is at least \(d+3\). The three comparisons
between positions \(i\) and \(i+d\), for \(i=0,1,2\), equate all three
residue classes modulo 3.

These are elementary finite-word arguments; no unproved periodicity
classification is used.

## 5. Generic and period-three contexts

From now on assume \(k\ge10\). The context types in the short-cycle
classification are disjoint, apart from constant degeneracies already
removed.

If no short cycle has exactly one marked edge, choose
\(p=q=1/4\). Every critical cycle has length at least four, proving
\(\alpha_w\le1/2\).

Now let \(u\) be nonconstant with period three. There is a unique
directed three-cycle through it. If both marked edges belong to that
cycle, their contributions cancel; if neither does, it has no marked
contribution. These cases again permit \(p=q=1/4\).

If exactly one marked edge belongs to the three-cycle, assign cost
\(1/3\) to its negative traversal orientation and \(1/6\) to the
opposite orientation. Thus \(t=1/4\) and \(\lambda=\pm1/12\).
The distinguished critical triangle has cost zero.

There can be no other short critical cycle: a mixed triangle would
make \(u\) almost constant, and a two-cycle would make it alternating.
For cycles of length at least four, a cost below one before the unit
subtraction could only arise from:

- a cycle entirely in the cheap direction, of length four or five;
- three cheap arcs and one expensive arc.

In the first case a marked edge has period \(d=4\) or 5, while its
interior has period three. That interior has length \(k-2\ge8\),
so the preceding periodicity fact makes it constant, contrary to its
nonconstant period-three pattern. In the second case the one-opposing-arc
lemma gives period two to the interior, again a contradiction.
Thus every cycle has nonnegative cost and \(\alpha_w\le1/2\).

## 6. The near-constant triangle bound

Complementation, reversal, and endpoint flipping reduce this case to

\[
u=0^{k-2}1,\qquad a=0,
\]

with either value of \(b\). Choose

\[
p=\frac{k-2}{2(k-1)},\qquad q=\frac1{k-1},
\qquad 2t=p+q=\frac{k}{2(k-1)}.
\]

For a critical cycle:

- If \(F\ge3\), then \(pF\ge1\), since \(k\ge4\).
- If \(F=2\) and \(B\ge1\), then \(2p+q=1\).
The remaining possibility \(F=2,B=0\) would be an alternating
original two-cycle through a near-constant marked edge, which is impossible.
- If \(F=0\), the cycle contains the backward copy of \(e_+\)
and avoids \(e_-\). Reverse its traversal. The resulting original
directed cycle enters \(u\) through \(1u=10^{k-2}1\), since the other
incoming edge is the forbidden marked edge \(e_-\). This word has
no period smaller than \(k-1\), so \(B\ge k-1\) and \(qB\ge1\).
- If \(F=1\) and the negative marked arc is \(e_-\), the other arcs
would give an original directed path from \(0^{k-1}\) to \(u\)
avoiding \(e_-\). No such simple path exists: the only nonloop exit
from the constant vertex is \(e_-\).
- If \(F=1\) and the negative marked arc is \(e_+\), apply the
one-opposing-arc lemma with long path length \(B\). The interior of
\(e_+\) is \(0^{k-3}1\), whose shortest period is \(k-2\).
Thus \(B-1\ge k-2\), giving \(B\ge k-1\) and \(p+qB\ge1\).
A two-arc forward/backward cycle cannot be critical, so the lemma's
requirement \(B\ge2\) causes no omission.

This covers every possibility and proves

\[
\alpha_w\le\frac12+\frac1{2(k-1)}.
\]

## 7. Alternation and why parity matters

Let \(u\) alternate. If both marked edges alternate, the unique
two-cycle contains both and their contributions cancel. If neither
alternates, there is no marked two-cycle. Both cases give
\(\alpha_w\le1/2\) by the generic argument.

If \(k\) is even, \(|u|=k-1\) is odd and \(u=u^R\).
Nonpalindromicity of \(aub\) forces \(a\ne b\); checking the alternating
extensions then shows that either both or neither marked edge
alternates. **There is no one-marked-edge obstruction at even memory.**

For odd \(k=2r+1\), the remaining case has exactly one alternating
marked edge. Complementation and endpoint flipping reduce it to

\[
u=(01)^r,\qquad w=0(01)^r1,
\qquad e_-=0(01)^r,\quad e_+=(01)^r0.
\]

Choose

\[
p=\frac1{k+1},\qquad q=\frac12,
\qquad 2t=p+q=\frac12+\frac1{k+1}.
\]

Every critical cycle with \(B\ge2\) already has \(pF+qB\ge1\).

If \(B=0\), the original directed cycle contains \(e_-\) and avoids
\(e_+\). Immediately after \(e_-\), it must append 1, so it contains
the word \(w=0(01)^r1\). This word has no period shorter than \(k+1\):
a shift of at most \(k-1\) would repeat its unique initial 00, and
a shift of \(k\) would equate its first 0 with its final 1. Therefore
\(F\ge k+1\), as required.

It remains to exclude \(B=1\) with \(F<r+1=(k+1)/2\).
A critical two-arc forward/backward cycle is impossible. For \(F\ge2\),
apply the one-opposing-arc lemma. Its central word has period
\(d=F-1\le r-1\).

If the negative marked arc is \(e_+\), it is the single backward
shortcut. Its alternating interior has length \(k-2=2r-1\ge d+1\).
The central word must therefore alternate. This forces the first
edge of the forward path from \(u\) to be \(e_+\) itself, contrary
to criticality.

If the negative marked arc is \(e_-\), it lies on the forward path.
The central word contains at least \(k-2\) alternating bits from its
tail, and therefore again alternates. Unless \(e_-\) is the first
path edge, its initial 00 is also inside the central word, a contradiction.
If it is first, \(F=2\) would give period one to an alternating block,
also impossible. For \(F\ge3\), the next appended bit is inside the
central word and is forced to be 0. The next path edge is then
\(e_+\), again contrary to criticality.

Hence \(F\ge r+1\) whenever \(B=1\), and
\(pF+q\ge1\). All dual constraints are feasible, proving

\[
\alpha_w\le\frac12+\frac1{k+1}.
\]

## 8. Completion, exact base cases, and an independent audit

The short-cycle classification exhausts every context for \(k\ge10\).
The generic and period-three bounds are one half; the near-constant
bound is \(1/2+1/[2(k-1)]\); and the extra alternating obstruction
occurs only for odd memory, where its bound is larger. These upper
bounds match the all-memory lower constructions from Continuation 9.

For \(3\le k\le9\), the existing 494 rational primal/dual certificates
cover every nonpalindromic word class under complementation and reversal.
The script \(\texttt{parity\_dual.py}\) rechecks their exact feasibility,
coverage, and equality with the displayed formula. This finite base
plus the analytic argument proves the theorem for every \(k\ge3\).

The same script implements the explicit large-memory choices of
\(t\) and \(\lambda\), constructs vertex potentials by integer
shortest-path relaxation, and checks every dual edge inequality exactly.
This supplies a separate finite audit of the graph argument through
memory 13, including a new memory beyond the earlier LP table.
It covers 7,632 word representatives and checks 44,417,024 integer
edge inequalities. It does not replace the arbitrary-memory proof.

Reproduce with `python3 continuation/parity_dual.py --max-k 13`.
The receipt is `results/parity_dual.json`, with class counts and example
potentials; the run log is `results/parity_dual_run.log`.
No optimization library is imported. The earlier 4,030 LP witnesses,
proofs, and archives remain unchanged.

The threshold reduction in Continuation 9 was reread: the nonpalindromic
zero-edge condition, positive reverse edge, bounded marginal KL correction,
and entropy-continuity lower bound remain valid. No correction was needed.
The present theorem resolves its parity conjecture but does not establish
uniqueness of the leading-order perturbation or the full finite-tolerance
optimizer at larger memory. Novelty and independent expert review remain
open.
