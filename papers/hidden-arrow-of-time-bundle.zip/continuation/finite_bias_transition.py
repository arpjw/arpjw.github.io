"""Exact interval exclusion proving a global optimizer change for a 40/60 coin.

Floating-point inverses only propose brackets. Exact outward-rounded inequalities
validate every bracket and every exclusion; failed proposals cannot pass silently.
The sharp certificate proves unique branches and one transverse crossing in its
displayed budget bracket. It does not cover the whole biased phase diagram.
"""
from __future__ import annotations

from fractions import Fraction as Q
from decimal import Decimal as D, localcontext
from functools import lru_cache
import hashlib
import json
from pathlib import Path

from intervals import I, SCALE, log
from explore_biased_scalar import inverse as propose_inverse

P, MU = Q(2, 5), Q(4, 25)
CLO, CHI = Q(2867, 10000), Q(1441, 5000)
GAPLO, GAPHI = Q(1, 250), Q(3, 250)


@lru_cache(maxsize=100000)
def cost(x: Q) -> I:
    entries=(x, P-x, P-x, 1-2*P+x)
    base=(P*P, P*(1-P), P*(1-P), (1-P)**2)
    return sum((I.point(a)*log(I.point(a/b)) for a,b in zip(entries,base) if a),I.point(0))


@lru_cache(maxsize=100000)
def slope(x: Q) -> I:
    return log(I.point(x*(1-2*P+x)/(P-x)**2))


def objective(x: Q,y: Q) -> I:
    assert 0<x<=MU<=y<P
    return (y-x)*(slope(y)-slope(x))


def derivatives(x: I) -> tuple[I,I]:
    fp=log(x*(1-2*P+x)/((P-x).square()))
    fpp=1/x+2/(P-x)+1/(1-2*P+x)
    return fp,fpp


def profile_bounds(c_low: Q,c_high: Q,a: Q,b: Q) -> tuple[I,I,I]:
    """First/second x derivatives at fixed cost, and the cost derivative."""
    remaining=I.point(c_low)-cost(a)
    remaining=I(remaining.lo,(I.point(c_high)-cost(b)).hi)
    assert remaining.lo>0
    yl,yh=inverse_range(remaining,False)
    x,y=I.hull(a,b),I.hull(yl,yh)
    fx,ax=derivatives(x);fy,ay=derivatives(y)
    bx=-1/x.square()+2/(P-x).square()-1/(1-2*P+x).square()
    by=-1/y.square()+2/(P-y).square()-1/(1-2*P+y).square()
    distance,gap=y-x,fy-fx
    jx,jy=-gap-distance*ax,gap+distance*ay
    jxx,jyy,jxy=2*ax-distance*bx,2*ay+distance*by,-ax-ay
    lam=jy/fy
    first=jx-lam*fx
    second=jxx-2*jxy*fx/fy+jyy*(fx/fy).square()-lam*(ax+ay*(fx/fy).square())
    return first,second,lam


INVERSE_CHECKS=0


@lru_cache(maxsize=100000)
def inverse_point(target: Q,left: bool) -> tuple[Q,Q]:
    global INVERSE_CHECKS
    assert target>=0
    if target==0:return MU,MU
    proposal=Q(format(propose_inverse(float(P),float(target),left),'.17g'))
    radius=Q(1,10**13)
    bound=I.point(target)
    for _ in range(20):
        low=max(Q(1,10**30) if left else MU,proposal-radius)
        high=min(MU if left else P-Q(1,10**30),proposal+radius)
        if left:
            valid=cost(low).lo>=bound.hi and cost(high).hi<=bound.lo
        else:
            valid=cost(low).hi<=bound.lo and cost(high).lo>=bound.hi
        if valid:
            INVERSE_CHECKS+=1
            return low,high
        radius*=10
    raise AssertionError(('unvalidated inverse proposal',str(target),left))


def inverse_range(target: I,left: bool) -> tuple[Q,Q]:
    low,high=target.fraction_bounds()
    assert low>=0
    a=inverse_point(low,left)
    b=inverse_point(high,left)
    return (b[0],a[1]) if left else (a[0],b[1])


def feasible_lower(c: Q) -> tuple[I,dict]:
    rows=[]
    for x in (Q(1,2000),Q(1,1250),Q(13,10000),Q(1,50),Q('0.0008532243'),Q('0.0198327187')):
        remaining=I.point(c)-cost(x)
        if remaining.lo<=0:continue
        y=inverse_range(remaining,False)[0]
        assert (cost(x)+cost(y)).hi<=I.point(c).lo
        score=objective(x,y)
        rows.append((score,{'x':str(x),'y':str(y),'cost_upper':(cost(x)+cost(y)).decimal_bounds()[1],
                            'objective_lower':score.decimal_bounds()[0]}))
    assert rows
    return max(rows,key=lambda row:row[0].lo)


def certify_strip(c_low: Q,c_high: Q,x_low: Q,x_high: Q,label: str) -> dict:
    lower,witness=feasible_lower(c_low)
    stack=[(x_low,x_high,0)]
    cover=[]
    smallest=None
    while stack:
        a,b,depth=stack.pop()
        # f is decreasing to MU. A cost-c pair is impossible if f(b)>c_high.
        fb=cost(b)
        if fb.lo>I.point(c_high).hi:
            cover.append({'x':[str(a),str(b)],'reason':'infeasible'})
            continue
        fa=cost(a)
        upper_remaining=I.point(c_high)-I(fb.lo,fa.hi)
        upper_target=Q(max(0,upper_remaining.hi),SCALE)
        y_high=inverse_point(upper_target,False)[1]
        upper=objective(a,y_high)
        if upper.hi<lower.lo:
            margin=lower.lo-upper.hi
            smallest=margin if smallest is None else min(smallest,margin)
            cover.append({'x':[str(a),str(b)],'reason':'strict value gap','objective_upper':upper.decimal_bounds()[1]})
            continue
        assert depth<35,('unresolved box',label,str(a),str(b),upper.decimal_bounds(),lower.decimal_bounds())
        mid=(a+b)/2
        stack.extend(((mid,b,depth+1),(a,mid,depth+1)))
    # Independently audit the exact contiguous cover, including no missing edges.
    intervals=sorted((Q(row['x'][0]),Q(row['x'][1])) for row in cover)
    assert intervals[0][0]==x_low and intervals[-1][1]==x_high
    assert all(a[1]==b[0] for a,b in zip(intervals,intervals[1:]))
    return {'label':label,'cost':[str(c_low),str(c_high)],'domain_x':[str(x_low),str(x_high)],
            'feasible_witness_at_lower_cost':witness,'smallest_strict_gap':I(smallest,smallest).decimal_bounds()[0],
            'boxes':len(cover),'cover':cover}


def sharp_certificate() -> dict:
    cl,ch=Q('0.2874097'),Q('0.2874098')
    left=(Q('0.0008'),Q('0.0009'))
    right=(Q('0.019'),Q('0.021'))
    xmin=inverse_point(ch,True)[0]
    exclusions=[certify_strip(cl,ch,xmin,left[0],'sharp: below left neighborhood'),
                certify_strip(cl,ch,left[1],right[0],'sharp: between neighborhoods'),
                certify_strip(cl,ch,right[1],MU,'sharp: above right neighborhood'),
                certify_strip(cl,cl,xmin,right[0],'sharp lower endpoint: exclude left branch'),
                certify_strip(ch,ch,left[1],MU,'sharp upper endpoint: exclude right branch')]
    branches=[]
    for label,(a,b) in (('strong',left),('mild',right)):
        assert profile_bounds(cl,ch,a,a)[0].lo>0
        assert profile_bounds(cl,ch,b,b)[0].hi<0
        boxes=[];stack=[(a,b,0)]
        while stack:
            lo,hi,depth=stack.pop()
            first,second,lam=profile_bounds(cl,ch,lo,hi)
            if second.hi<0:
                boxes.append({'x':[str(lo),str(hi)],'curvature':second.decimal_bounds(),'budget_derivative':lam.decimal_bounds()})
                continue
            assert depth<20,(label,'curvature not certified',str(lo),str(hi))
            mid=(lo+hi)/2;stack.extend(((lo,mid,depth+1),(mid,hi,depth+1)))
        intervals=sorted((Q(row['x'][0]),Q(row['x'][1])) for row in boxes)
        assert intervals[0][0]==a and intervals[-1][1]==b
        assert all(v[1]==w[0] for v,w in zip(intervals,intervals[1:]))
        branches.append({'label':label,'x_neighborhood':[str(a),str(b)],
                         'left_endpoint_derivative':profile_bounds(cl,ch,a,a)[0].decimal_bounds(),
                         'right_endpoint_derivative':profile_bounds(cl,ch,b,b)[0].decimal_bounds(),
                         'boxes':boxes,'budget_derivative':[
                             str(min(Q(row['budget_derivative'][0]) for row in boxes)),
                             str(max(Q(row['budget_derivative'][1]) for row in boxes))]})
    slope_gap=Q(branches[0]['budget_derivative'][0])-Q(branches[1]['budget_derivative'][1])
    assert slope_gap>20
    return {'status':'PASS: exactly two tracked global candidates, unique analytic local branches, transverse unique crossing in this cost interval',
            'cost_interval':[str(cl),str(ch)],'slope_jump_lower_bound':str(slope_gap),'x_jump_lower_bound':str(right[0]-left[1]),
            'exclusions':exclusions,'branches':branches}


def decimal_diagnostic() -> dict:
    from biased_transition_persistence import pair,linear_solve
    with localcontext() as ctx:
        ctx.prec=60
        s=D('.2');z=list(map(D,('-.6625','.1','-.584','.412','.2874')));zero=D(0)
        for iteration in range(30):
            a,b,c,d,budget=z
            ca,ja,ka,fa,fb,jax,jay,kax,kay=pair(s,a,b)
            cc,jc,kc,fc,fd,jcx,jcy,kcx,kcy=pair(s,c,d)
            residual=[ca-budget,ka,cc-budget,kc,ja-jc]
            error=max(map(abs,residual))
            if error<D('1e-45'):
                return {'status':'separate 60-digit stationary coexistence solve, not an interval certificate',
                        'budget':str(z[-1]),'physical_parameters':[str(D('.16')+D('.24')*v) for v in z[:4]],
                        'strong_slope':str(jay/fb),'mild_slope':str(jcy/fd),'max_residual':str(error),'iterations':iteration}
            jac=[[fa,fb,zero,zero,-D(1)],[kax,kay,zero,zero,zero],
                 [zero,zero,fc,fd,-D(1)],[zero,zero,kcx,kcy,zero],[jax,jay,-jcx,-jcy,zero]]
            step=linear_solve(jac,[-v for v in residual]);z=[v+dv for v,dv in zip(z,step)]
        raise AssertionError('Decimal diagnostic did not converge')


def main() -> None:
    threshold=cost(Q(0))
    assert threshold.lo>I.point(CHI).hi
    assert cost(GAPLO).hi<I.point(CLO).lo
    x_min=inverse_point(CHI,True)[0]
    rows=[certify_strip(CLO,CLO,x_min,GAPHI,'lower endpoint: exclude the small-x region'),
          certify_strip(CHI,CHI,GAPLO,MU,'upper endpoint: exclude the large-x region')]
    count=40
    for i in range(count):
        a=CLO+(CHI-CLO)*i/count
        b=CLO+(CHI-CLO)*(i+1)/count
        rows.append(certify_strip(a,b,GAPLO,GAPHI,f'gap strip {i+1}/{count}'))
    assert rows[2]['cost'][0]==str(CLO) and rows[-1]['cost'][1]==str(CHI)
    assert all(a['cost'][1]==b['cost'][0] for a,b in zip(rows[2:],rows[3:]))
    sharp=sharp_certificate()
    receipt={'status':'PASS: exhaustive exact interval exclusions; global coexistence and unavoidable optimizer change follow from the written continuity proof',
             'p':str(P),'cost_interval':[str(CLO),str(CHI)],'excluded_x_gap':[str(GAPLO),str(GAPHI)],
             'singular_budget':threshold.decimal_bounds(),'common_positive_x_lower_bound':str(x_min),
             'strips':len(rows),'boxes':sum(row['boxes'] for row in rows),'validated_inverse_brackets':INVERSE_CHECKS,
             'sharp_exclusion_boxes':sum(row['boxes'] for row in sharp['exclusions']),
             'sharp_curvature_boxes':sum(len(row['boxes']) for row in sharp['branches']),
             'smallest_exclusion_margin':min(row['smallest_strict_gap'] for row in rows),
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'interval_library_sha256':hashlib.sha256(Path('continuation/intervals.py').read_bytes()).hexdigest(),
             'limits':['unique crossing and branch uniqueness are certified only in the sharp displayed interval','does not give the full biased phase diagram','does not quantify the small-bias theorem neighborhood'],
             'sharp_certificate':sharp,'separate_decimal_diagnostic':decimal_diagnostic(),'rows':rows}
    Path('results/finite_bias_transition.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({key:value for key,value in receipt.items() if key not in ('rows','sharp_certificate')},indent=2))
    print(json.dumps({key:value for key,value in sharp.items() if key not in ('exclusions','branches')},indent=2))


if __name__=='__main__':main()
