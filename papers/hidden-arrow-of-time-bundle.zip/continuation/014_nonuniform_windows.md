# Unequal frequencies change which rare word hides time's arrow

Status: written mathematical proofs with exact rational and interval audits. This is a research draft, not an independently reviewed result or a verified novelty claim. All logarithms and rates below use nats.

## 1. Statement and the memory-three change

Fix a strictly positive symbol law \(\pi=(\pi_1,\ldots,\pi_m)\), \(m\ge2\). We consider stationary Markov sources of order at most \(k\) whose every length-\(k\) word has exactly the independent law \(\pi^{\otimes k}\). Individual kernels are strictly positive. Write

\[
\delta=H(\pi)-h,\qquad
\sigma=\lim_{n\to\infty}\frac1nD(P_n\Vert P_n^R),
\]

and let \(M_{\pi,k}(d)\) be the supremum of \(\sigma\) under \(\delta\le d\). Sort the frequencies and denote the two smallest by \(p\le q\), counting multiplicity. Define

\[
F(A,B)=(1-A-B)\log(1-A-B)
 -(1-A)\log(1-A)-(1-B)\log(1-B),
\]

with \(0\log0=0\), for \(A+B\le1\).

**Theorem.** For \(m\ge3\), the exact threshold for infinite supremum is

\[
\boxed{\Delta_{\pi,k}=
\begin{cases}
p^{k-1}F(p,q),&k=1,2,\\
p^{k-2}qF(p,p),&k\ge3.
\end{cases}}
\]

For a binary alphabet, \(\sigma\equiv0\) when \(k=1,2\); for \(k\ge3\), the second formula applies. In every nontrivial case, \(M_{\pi,k}(d)<\infty\) for \(d<\Delta_{\pi,k}\), while \(M_{\pi,k}(d)=\infty\) for \(d\ge\Delta_{\pi,k}\).

At memories one and two, the cheapest irreversible missing word has the two rarest distinct symbols at its endpoints. From memory three onward, equal rare endpoints and a nonpalindromic middle context attain the threshold. If the rarest symbol is unique, this change is strict: the latter construction is cheaper than every missing word with unequal endpoints.

The finite subcritical quantity is a supremum over positive kernels. Unlike the uniform case, this proof does not assert that a positive kernel attains it. A zero at a palindrome can appear below the irreversible threshold; such a zero contributes nothing to word-reversal divergence.

## 2. Exact transport-block representation

For a middle context \(u\) of length \(k-1\), put \(r_u=\prod_{x\in u}\pi_x\). Every feasible length-\((k+1)\) flow is uniquely

\[
Q(aub)=r_u T_u(a,b),\qquad
\sum_bT_u(a,b)=\pi_a,\quad \sum_aT_u(a,b)=\pi_b.
\]

Thus each \(T_u\) is a probability matrix with both margins equal to \(\pi\). Conversely these constraints construct a stationary order-at-most-\(k\) source, with transition probability \(T_u(a,b)/\pi_a\). Let \(B=\pi\otimes\pi\). Direct calculation gives

\[
\delta=\sum_u r_u D(T_u\Vert B),\qquad
\sigma=\sum_{u,a,b}r_u T_u(a,b)
 \log\frac{T_u(a,b)}{T_{u^R}(b,a)}.
\]

The formula uses observable reversal, including reversal of the context. For every \(n\ge k\), the stronger finite identities hold:

\[
D(P_n\Vert\pi^{\otimes n})=(n-k)\delta,
\qquad D(P_n\Vert P_n^R)=(n-k)\sigma.
\]

Indeed \(P_n/\pi^{\otimes n}\) is the product over windows of \(T_u(a,b)/(\pi_a\pi_b)\). In \(P_n/P_n^R\), the endpoint factors from the stationary initial laws and transition denominators cancel, leaving the product of \(T_u(a,b)/T_{u^R}(b,a)\). Stationarity gives the displayed expectations. This cancellation is essential for nonuniform \(\pi\).

## 3. The least entropy cost of suppressing one word

Fix a matrix entry \(T(a,b)=z\), and set \(A=\pi_a\), \(B_0=\pi_b\). In this section write \(B_0\) simply as \(B\). The feasible interval is
\(\max(0,A+B-1)\le z\le\min(A,B)\). The unique entropy-minimizing matrix is

\[
T^{a,b}_z(i,j)=
\begin{cases}
z,&i=a,\ j=b,\\
(A-z)\pi_j/(1-B),&i=a,\ j\ne b,\\
(B-z)\pi_i/(1-A),&i\ne a,\ j=b,\\
(1-A-B+z)\pi_i\pi_j/[(1-A)(1-B)],&i\ne a,\ j\ne b.
\end{cases}
\]

Its cost \(f_{A,B}(z)\) is the relative entropy of the four masses
\((z,A-z,B-z,1-A-B+z)\) against
\((AB,A(1-B),(1-A)B,(1-A)(1-B))\).
More precisely, for every matrix \(T\) with the prescribed margins and corner,

\[
D(T\Vert\pi\otimes\pi)-f_{A,B}(z)=D(T\Vert T^{a,b}_z).
\]

To prove the identity, the density \(T_z/(\pi\otimes\pi)\) is constant on each of the four groups, and their masses are fixed. Hence the cross-entropy term is unchanged. Zero groups have zero mass for every feasible competitor. Nonnegativity and the equality case of relative entropy prove uniqueness, including at the boundary.

For \(A+B\le1\), the zero-entry cost is \(f_{A,B}(0)=F(A,B)\). A zero at word \(aub\) therefore costs at least \(r_uF(A,B)\), with equality exactly when its block is \(T^{a,b}_0\) and every other block is independent.

## 4. Minimizing the missing-word cost

For \(A+B<1\), elementary differentiation gives

\[
\partial_A F=\log\frac{1-A}{1-A-B}>0,\qquad
\partial_B^2F=\frac{A}{(1-B)(1-A-B)}>0.
\]

The symmetric derivative is also positive. Since \(F(A,0)=0\), strict convexity implies that \(F(A,B)/B\) is strictly increasing in \(B>0\), with the endpoint interpreted by continuity. In particular

\[
pF(p,q)\ge qF(p,p),
\]

strictly when \(p<q\).

If \(k=1,2\), every middle context is palindromic. A nonpalindromic word therefore requires different endpoints. For \(m\ge3\), its least cost is \(p^{k-1}F(p,q)\), attained with the two rarest endpoints and a rarest-symbol middle context. These endpoints satisfy \(p+q<1\), so the minimizing matrix has exactly one zero and the reversed entry is positive. For binary alphabets, every matrix with equal row and column margins is symmetric; every context is palindromic at these memories, proving \(\sigma=0\).

Now suppose \(k\ge3\). A nonpalindromic middle word has probability at least \(p^{k-2}q\). If the smallest frequency is unique, such a word must include a different symbol; if it is tied, the bound is simply \(p^{k-1}\). The bound is attained by a middle word containing one second-rarest symbol in a noncentral position and otherwise a rarest symbol.

A nonpalindromic full word with equal endpoints thus costs at least \(p^{k-2}qF(p,p)\), attained with rarest endpoints. One with different endpoints costs at least \(p^{k-1}F(p,q)\), which is no smaller by the displayed inequality. This proves the claimed minimum. In the fair binary case, the minimizing block has two zeros; putting it at a nonpalindromic context still leaves both reversed words positive in the independent reverse-context block.

For completeness, a divergent sequence of rates has a subsequence converging in the finite flow polytope, with some nonpalindromic word probability tending to zero. Otherwise every term contributing to reversal is uniformly bounded. The entropy cost of that zero is at least the displayed threshold. For binary sources, words with palindromic middle context contribute zero identically and can be omitted. This proves finiteness below the threshold by compactness. The reversal functional extends continuously to the closed subcritical feasible set, because all entries that can contribute are bounded away from zero; its maximum there equals the positive-kernel supremum by mixing with the independent source.

Conversely, mix a threshold boundary construction with the independent source with weight \(\varepsilon>0\). All transitions become positive, its deficit is strictly below \(\Delta_{\pi,k}\), and an entry tending to zero has a reverse tending to a positive number. Its reversal rate diverges. This proves the exact threshold, including equality.

Every limit of a divergent sequence with deficit at most the threshold is one of the one-block equality constructions just identified, with a genuinely irreversible missing word. For \(p<q\) and \(k\ge3\), both endpoints must be the unique rarest symbol; the middle context has one second-rarest symbol away from the center and otherwise rarest symbols. Ties allow further equality cases. This is a boundary classification, not finite-budget optimizer uniqueness.

## 5. The globally optimal divergence asymptotic

Exclude the fair binary law temporarily. Define

\[
(A,B,R)=
\begin{cases}
(p,q,p^{k-1}),&m\ge3,\ k=1,2,\\
(p,p,p^{k-2}q),&k\ge3,
\end{cases}
\quad s=1-A-B>0.
\]

The threshold is \(RF(A,B)\). For \(0<d<\Delta_{\pi,k}\), let \(z_d\in(0,AB)\) be the unique solution of \(Rf_{A,B}(z_d)=d\). Uniqueness follows from

\[
f'_{A,B}(z)=\log\frac{z(1-A-B+z)}{(A-z)(B-z)}<0
\quad(0<z<AB).
\]

Then, with \(\pi,k\) fixed as \(d\uparrow\Delta_{\pi,k}\),

\[
\boxed{M_{\pi,k}(d)=C\log\frac{AB}{s z_d}+o(1)},
\qquad
C=\begin{cases}
\displaystyle\frac{RABs}{(1-A)(1-B)},&k=1,2,\\
RAB,&k\ge3.
\end{cases}
\]

Here and below the error is additive. The explicit one-block family is therefore asymptotically globally optimal, not merely correct to leading order.

For a nonpalindromic middle context its exact rate is

\[
\sigma_z=R(z-AB)\log\frac{z(s+z)}{(A-z)(B-z)}.
\]

For a palindromic middle context and distinct endpoints, put \(D_0=(1-A)(1-B)\) and \(c_z=AB(s+z)/D_0\). Pairing opposite entries gives

\[
\frac{\sigma_z}{R}=(z-c_z)\log\frac{z}{c_z}
 +\frac{s(AB-z)}{D_0}
 \log\frac{(A-z)(B-z)D_0}{AB(s+z)^2}.
\]

Expansion gives the same logarithm \(\log(AB/(sz))\), with the two coefficients stated above. When \(k\ge3\) and \(p=q\), palindromic-context critical constructions can tie in threshold cost, but their divergence coefficient is strictly smaller by the factor \(s/D_0<1\). Nonpalindromic contexts attain the larger coefficient.

To prove the global upper bound, take any sequence of nearly maximizing positive sources as the budget tends to the threshold. Its rates diverge by the explicit lower construction. Along subsequences its limiting flow is one of the critical sources classified above. Denote its designated small joint entry by \(z\), and compare it with the one-block source \(Q_z\) having exactly that entry. The fixed-entry identity yields

\[
\delta(Q)-\delta(Q_z)=D(Q\Vert Q_z),\qquad
D(Q\Vert Q_z)\le R[F(A,B)-f_{A,B}(z)]
=O(z\log(1/z)).
\]

Pinsker implies \(\|Q-Q_z\|_1=O(\sqrt{z\log(1/z)})\). All other entries of \(Q_z\) stay bounded away from zero, and its small entry agrees exactly with that of \(Q\). Isolating the single singular reversal pair therefore gives

\[
\sigma(Q)=\sigma(Q_z)+
 O\bigl(\sqrt z\,[\log(1/z)]^{3/2}\bigr)
=\sigma(Q_z)+o(1).
\]

The constants are uniform over the finitely many critical templates for fixed \(\pi,k\). Also \(Rf_{A,B}(z)\le d\), hence \(z\ge z_d\) eventually. The comparison formulas, with the largest coefficient when tied templates occur, give the upper bound. Taking the explicit family at \(z_d\) gives the matching lower bound. This subsequence argument applies to suprema and does not assume positive-kernel maximizers exist.

Writing \(\eta=\Delta_{\pi,k}-d\) and \(L=\log(1/\eta)\), integration of \(f'\) gives

\[
\eta=Rz_d\{\log(1/z_d)+1+\log(AB/s)+O(z_d)\},
\]

so the budget form is

\[
\boxed{M_{\pi,k}(d)=C\{L+\log L+\log(RAB/s)\}+o(1)}.
\]

For uniform \(m\ge3\), substituting \(A=B=1/m\), \(R=m^{-(k-1)}\), and \(z_d=t_d/m\) recovers Continuation 13, including its constant term.

## 6. A fair coin is a singular limit

For \(\pi=(1/2,1/2)\), \(k\ge3\), put \(R=2^{-(k-1)}\). The threshold is \(R\log2\), and the critical block has two zero entries. Both equal \(z\) in its positive regularization. Its exact rate and entropy gap are

\[
\sigma_z=2R(1/4-z)\log\frac{1/2-z}{z},\qquad
\eta=2Rz\{\log(1/z)+1-\log2+O(z)\}.
\]

Every binary matrix with the prescribed margins has the two corresponding entries equal. Thus the comparison argument fixes both small entries exactly, and the same relative-entropy proof applies. It gives

\[
\boxed{M_{(1/2,1/2),k}(d)
=2^{-k}\{L+\log L+(1-k)\log2\}+o(1)}.
\]

This exposes a discontinuity in a singular asymptotic coefficient. For a fixed biased coin \(\pi=(p,1-p)\), \(p<1/2\), the leading coefficient at memory \(k\ge3\) is \(p^k(1-p)\). As \(p\uparrow1/2\), it tends to \(2^{-(k+1)}\), exactly half the fair-coin coefficient \(2^{-k}\). The thresholds themselves converge continuously.

There is no discontinuity assertion at a fixed interior entropy budget. The two limits, removing the bias and approaching the singular entropy threshold, need not commute. For every fixed biased coin only one entry of the critical block vanishes; at exact fairness a second entry vanishes with it. This explains the doubled coefficient.

## 7. Reproducibility, limitations, and an audit correction

Reproduce with `python3 continuation/nonuniform_threshold.py`.

The receipt `results/nonuniform_threshold.json` checks 168 fixed-margin and relative-entropy cases, 1,181 exact finite paths, and 4,126 nonpalindromic missing-word costs for several rational laws through memory five. It also checks stationary word laws, formal logarithm coefficients, and the displayed closed rate formulas. The small-entry examples evaluate explicit sources and their asymptotic residuals; they are not numerical global optimizations. The global statements depend on the proofs above.

The code uses standard-library fractions and the existing outward-rounded integer interval library. It covers unique rare symbols, tied rare symbols, a uniform ternary law, biased binary laws, and the fair binary limit. No floating-point search is used as proof evidence.

One tempting extrapolation from the uniform theorem required correction during this continuation: below the irreversible threshold, not every transition is necessarily positive in the closed feasible set. A cheap missing palindrome can occur first. For example, with \(\pi=(1/10,1/5,7/10)\) and \(k=1\), eliminating the rare diagonal entry costs \(F(1/10,1/10)<F(1/10,1/5)\) and leaves a reversible source. The statement here consequently distinguishes finiteness of the positive-kernel supremum from its attainment. This does not change the earlier uniform theorem or its archives.

The finite-budget optimizing source for general nonuniform laws remains unresolved. So does the crossover asymptotic when coin bias and distance to threshold vanish together. The entropy minimization and relative-entropy projection identities are standard tools; the rare-event explanation is established background. These derivations do not establish novelty or publication priority, and independent expert review remains open.
