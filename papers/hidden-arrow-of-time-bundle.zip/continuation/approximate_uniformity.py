"""Stationary-flow projection, exact algebra checks, and singular example.

Fractions certify the flow/projection/TV identities. Integer intervals certify
the displayed entropy gap and regularized rates. Random floating-point entropy
and reversal comparisons are diagnostics, explicitly labeled in the receipt.
"""

from __future__ import annotations

from fractions import Fraction as Q
import json
from math import fsum, log
from pathlib import Path
import random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hidden_arrow import deficit, inverse_deficit, words
from intervals import I, ln2, log as interval_log

Flow = dict[str, Q]


def fair_flow(k: int) -> Flow:
    return {word: Q(1, 2 ** (k + 1)) for word in words(k + 1)}


def cycle_flow(k: int, cycle: str) -> Flow:
    result = {word: Q(0) for word in words(k + 1)}
    for start in range(len(cycle)):
        word = "".join(cycle[(start + j) % len(cycle)] for j in range(k + 1))
        result[word] += Q(1, len(cycle))
    return result


def mix(left: Flow, right: Flow, weight: Q) -> Flow:
    return {word: (1 - weight) * value + weight * right[word] for word, value in left.items()}


def marginals(q: Flow) -> Flow:
    k = len(next(iter(q))) - 1
    prefix = {s: q[s + "0"] + q[s + "1"] for s in words(k)}
    suffix = {s: q["0" + s] + q["1" + s] for s in words(k)}
    assert prefix == suffix
    assert sum(q.values()) == 1
    assert all(value >= 0 for value in q.values())
    return prefix


def kernel(q: Flow) -> Flow:
    pi = marginals(q)
    assert min(pi.values()) > 0
    return {word: value / pi[word[:-1]] for word, value in q.items()}


def tv(left: Flow, right: Flow) -> Q:
    return sum((abs(value - right[word]) for word, value in left.items()), Q()) / 2


def project(q: Flow) -> tuple[Flow, dict[str, Q]]:
    k = len(next(iter(q))) - 1
    pi, trans = marginals(q), kernel(q)
    theta = {}
    for u in words(k - 1):
        p0, p1 = pi["0" + u], pi["1" + u]
        m0, m1 = 2 * trans["0" + u + "0"] - 1, 2 * trans["1" + u + "0"] - 1
        theta[u] = (p0 * m0 - p1 * m1) / (p0 + p1)
    projected = {
        word: (1 + (1 if word[0] == word[-1] else -1) * theta[word[1:-1]]) / 2 ** (k + 1)
        for word in q
    }
    assert set(marginals(projected).values()) == {Q(1, 2**k)}
    return projected, theta


def entropy_deficit(q: Flow) -> float:
    trans = kernel(q)
    return log(2) + fsum(float(value) * log(float(trans[word])) for word, value in q.items() if value)


def reversal_rate(q: Flow) -> float:
    trans = kernel(q)
    return fsum(float(value) * log(float(trans[word] / trans[word[::-1]])) for word, value in q.items() if value)


def deficit_interval(q: Flow) -> I:
    trans = kernel(q)
    result = ln2()
    for word, value in q.items():
        if value:
            result += I.point(value) * interval_log(I.point(trans[word]))
    return result


def rate_interval(q: Flow) -> I:
    trans = kernel(q)
    result = I.point(0)
    for word, value in q.items():
        if value:
            result += I.point(value) * interval_log(I.point(trans[word] / trans[word[::-1]]))
    return result


def path_probability(q: Flow, word: str) -> Q:
    k = len(next(iter(q))) - 1
    pi, trans = marginals(q), kernel(q)
    result = pi[word[:k]]
    for j in range(k, len(word)):
        result *= trans[word[j - k : j + 1]]
    return result


def singular_flow(weight: Q) -> Flow:
    original = {
        word: Q(1 + (1 if word[0] == word[-1] else -1) * (word[1:-1] == "01"), 16)
        for word in words(4)
    }
    return mix(original, cycle_flow(3, "01"), weight)


def sharp_singular_flow(tau: Q) -> Flow:
    assert 0 < tau < Q(1, 16)
    a, c, e, z = Q(1, 8) - tau / 4, Q(1, 8) + tau / 2, Q(1, 8), 3 * tau / 4
    pi = {"000": e, "001": a, "010": c, "011": a, "100": a, "101": c, "110": a, "111": e}
    q = {}
    for word in words(4):
        u = word[1:-1]
        q[word] = pi[word[:-1]] * pi[word[1:]] / (pi["0" + u] + pi["1" + u])
    q.update({"0010": a, "0011": Q(0), "1010": z, "1011": a})
    assert marginals(q) == pi
    assert tv(pi, {s: Q(1, 8) for s in pi}) == tau
    assert q["1100"] == a * a / (a + c)
    assert sum(value == 0 for value in q.values()) == 1
    return q


def sharp_lower_interval(tau: Q) -> I:
    z = I.point(3 * tau / 4)
    return I.point(Q(1, 4) - tau) * ln2() - z * (1 + interval_log(I.point(Q(1, 8) + tau) / z))


def binary_entropy_interval(value: Q) -> I:
    assert 0 <= value <= 1
    if value in (0, 1):
        return I.point(0)
    p, other = I.point(value), I.point(1 - value)
    return -p * interval_log(p) - other * interval_log(other)


def sharp_upper_formula_interval(tau: Q) -> I:
    def d(value: Q) -> I:
        return ln2() - binary_entropy_interval((1 + value) / 2)
    return (
        I.point((1 + tau) / 4) * ln2()
        - I.point((1 + 4 * tau) / 8) * binary_entropy_interval(6 * tau / (1 + 4 * tau))
        + I.point((1 - tau) / 2) * d(tau / (1 - tau))
        + I.point((1 + tau) / 4) * d(3 * tau / (1 + tau))
    )


def audit_order_three_linear_bounds(pi: Flow) -> None:
    a, b, c, d, e, f = (pi[s] for s in ("001", "011", "010", "101", "000", "111"))
    assert pi["100"] == a and pi["110"] == b and c + b == a + d
    tau = tv(pi, {s: Q(1, 8) for s in pi})
    plus, minus = c - a, b - a
    assert plus == d - b == Q(3, 4) * (c + d) + Q(1, 4) * (e + f) - Q(1, 4)
    assert minus == d - c == (2 * (b - a) + d - c) / 3
    assert abs(plus) <= 3 * tau / 4 and abs(minus) <= 2 * tau / 3


def exact_projection_audit(q: Flow) -> tuple[Flow, Q, Q]:
    k = len(next(iter(q))) - 1
    pi, kp = marginals(q), kernel(q)
    projected, theta = project(q)
    kq = kernel(projected)
    uniform = {s: Q(1, 2**k) for s in pi}
    tau = tv(pi, uniform)
    epsilon = min(kp.values())
    b = 1 - 2 * epsilon
    assert min(kq.values()) >= epsilon
    weighted_distance = sum(pi[s] * abs(kp[s + "0"] - kq[s + "0"]) for s in pi)
    uniform_distance = sum(uniform[s] * abs(kp[s + "0"] - kq[s + "0"]) for s in pi)
    assert weighted_distance <= (1 + b) * tau
    assert uniform_distance <= (1 + 2 * b) * tau
    assert tv(q, projected) <= (2 + b) * tau
    for u in theta:
        p0, p1 = pi["0" + u], pi["1" + u]
        p = p0 + p1
        m0, m1 = 2 * kp["0" + u + "0"] - 1, 2 * kp["1" + u + "0"] - 1
        v, w = pi[u + "0"] - pi[u + "1"], p0 - p1
        assert m0 - theta[u] == (v - w * m0) / p
        assert -m1 - theta[u] == -(v + w * m1) / p
        assert abs(v) <= 2 * tau and abs(w) <= 2 * tau
        pair_distance = sum(pi[a + u] * abs(kp[a + u + "0"] - kq[a + u + "0"]) for a in "01")
        assert pair_distance == p0 * p1 * abs(m0 + m1) / p
        assert pair_distance <= (abs(v) + b * abs(w)) / 2
    return projected, tau, epsilon


def main() -> None:
    rng = random.Random(716050)
    trials = 500
    worst_entropy_excess = worst_rate_excess = -1.0
    largest_boundary = 0.0
    forced_floor_checks = 0
    for index in range(trials):
        k = rng.choice((2, 3, 4, 5))
        cycle = "".join(rng.choice("01") for _ in range(rng.randint(2, 14)))
        alpha = Q(rng.randint(1, 20), 1000 if index % 2 else 100)
        q = mix(fair_flow(k), cycle_flow(k, cycle), alpha)
        projected, tau, epsilon = exact_projection_audit(q)
        if k == 3:
            audit_order_three_linear_bounds(marginals(q))
        ep, ta = float(epsilon), float(tau)
        b = 1 - 2 * ep
        dp, dq = entropy_deficit(q), entropy_deficit(projected)
        sp, sq = reversal_rate(q), reversal_rate(projected)
        constant = 2 * (2 + b) * log((1 - ep) / ep) + 2 * (1 + 2 * b) / ep
        entropy_excess = dq - dp - deficit(b) * ta
        rate_excess = abs(sp - sq) - constant * ta
        worst_entropy_excess = max(worst_entropy_excess, entropy_excess)
        worst_rate_excess = max(worst_rate_excess, rate_excess)
        assert entropy_excess < 2e-12 and rate_excess < 2e-12
        ncontexts = 2 ** (k - 1)
        target = ncontexts * (dp + ta * log(2))
        if ta < 1 / ncontexts and 0 <= target < log(2):
            forced = (1 - inverse_deficit(target) - 4 * ncontexts * ta / (1 - ncontexts * ta)) / 2
            if forced > 0:
                assert ep >= forced - 2e-12
                forced_floor_checks += 1
        if index < 24:
            pi = marginals(q)
            boundary = fsum(float(p) * log(float(p / pi[s[::-1]])) for s, p in pi.items())
            largest_boundary = max(largest_boundary, boundary)
            for n in range(k, k + 3):
                paths = {word: path_probability(q, word) for word in words(n)}
                assert sum(paths.values()) == 1
                divergence = fsum(float(p) * log(float(p / paths[s[::-1]])) for s, p in paths.items())
                assert abs(divergence - boundary - (n - k) * sp) < 2e-12

    lam = Q(1, 1000)
    singular = singular_flow(lam)
    pi = marginals(singular)
    assert singular["0011"] == 0 and singular["1100"] == (1 - lam) / 16
    assert all(pi[s] == pi[s[::-1]] for s in pi)
    assert tv(pi, {s: Q(1, 8) for s in pi}) == 3 * lam / 4
    trans = kernel(singular)
    assert trans["0010"] == 1 and trans["0011"] == 0
    assert trans["1010"] == 4 * lam / (1 + 3 * lam)
    assert trans["0100"] == (1 - lam) / (2 * (1 + 3 * lam))
    singular_deficit = deficit_interval(singular)
    gap = ln2() / 4 - singular_deficit
    assert gap.lo > I.point("0.00308").hi
    regularizations = []
    for exponent in (2, 4, 8, 16, 24):
        eta = Q(1, 10**exponent)
        q = mix(singular, fair_flow(3), eta)
        delta, rate = deficit_interval(q), rate_interval(q)
        assert min(q.values()) > 0
        assert delta.hi < singular_deficit.lo
        assert tv(marginals(q), {s: Q(1, 8) for s in pi}) == (1 - eta) * 3 * lam / 4
        regularizations.append({
            "eta": str(eta),
            "entropy_deficit_interval": delta.decimal_bounds(),
            "reversal_rate_interval": rate.decimal_bounds(),
            "minimum_kernel_probability": str(min(kernel(q).values())),
        })
    asymptotic_diagnostics = []
    for exponent in (2, 3, 4, 5, 6):
        weight = Q(1, 10**exponent)
        tau = float(3 * weight / 4)
        reduction = log(2) / 4 - entropy_deficit(singular_flow(weight))
        asymptotic_diagnostics.append({"lambda": str(weight), "tau": tau, "threshold_reduction": reduction, "reduction_over_tau_log_inverse_tau": reduction / (tau * log(1 / tau))})
    sharp_examples = []
    for tau in (Q(3, 4000), Q(1, 10000), Q(1, 1000000)):
        q = sharp_singular_flow(tau)
        audit_order_three_linear_bounds(marginals(q))
        upper, lower = deficit_interval(q), sharp_lower_interval(tau)
        formula = sharp_upper_formula_interval(tau)
        assert max(upper.lo, formula.lo) <= min(upper.hi, formula.hi)
        assert lower.hi < upper.lo < (ln2() / 4).lo
        if tau == Q(3, 4000):
            assert upper.hi < singular_deficit.lo
        zplus = marginals(q)["010"] - marginals(q)["001"]
        assert zplus == 3 * tau / 4
        positive = mix(q, fair_flow(3), Q(1, 10**16))
        regularized_deficit, regularized_rate = deficit_interval(positive), rate_interval(positive)
        assert regularized_deficit.hi < upper.lo
        sharp_examples.append({
            "window_tv": str(tau),
            "lower_threshold_bound_interval": lower.decimal_bounds(),
            "upper_threshold_bound_interval": upper.decimal_bounds(),
            "construction_threshold_reduction_interval": (ln2() / 4 - upper).decimal_bounds(),
            "activated_edge_flow": str(zplus),
            "activated_flow_over_window_tv": str(zplus / tau),
            "divergence_log_coefficient": str(q["1100"]),
            "regularization_eta": "1/10000000000000000",
            "regularized_entropy_deficit_interval": regularized_deficit.decimal_bounds(),
            "regularized_reversal_rate_interval": regularized_rate.decimal_bounds(),
        })
    report = {
        "status": "PASS: exact flow/projection checks and interval-certified singular example",
        "seed": 716050,
        "exact_random_flow_checks": trials,
        "exact_checks_scope": "Stationary rational flows, projection floor, weighted and unweighted kernel TV, joint TV, coordinate identities.",
        "floating_point_diagnostics": {
            "trials": trials,
            "max_entropy_bound_excess": worst_entropy_excess,
            "max_rate_bound_excess": worst_rate_excess,
            "positive_forced_floor_cases": forced_floor_checks,
            "finite_word_reversal_identity_cases": 72,
            "largest_initial_reversal_divergence": largest_boundary,
            "tolerance": 2e-12,
        },
        "certified_example": {
            "lambda": str(lam), "window_tv": str(3 * lam / 4),
            "exact_uniform_singular_threshold_interval": (ln2() / 4).decimal_bounds(),
            "entropy_deficit_interval": singular_deficit.decimal_bounds(),
            "threshold_reduction_interval": gap.decimal_bounds(),
            "divergence_log_coefficient": str((1 - lam) / 16),
            "zero_edge": "0011", "positive_reverse_edge": "1100",
            "regularizations": regularizations,
        },
        "floating_point_asymptotic_diagnostics": asymptotic_diagnostics,
        "sharp_asymptotic_threshold": {
            "proved_leading_coefficient": "3/4",
            "statement": "T_3(tau) = log(2)/4 - (3/4) tau log(1/tau) + O(tau)",
            "certified_examples": sharp_examples,
            "closed_formula_flow_interval_checks": len(sharp_examples),
            "proof": "continuation/006_sharp_threshold_shift.md",
            "limit": "The leading coefficient is sharp; the exact finite-tau threshold and linear correction remain unresolved.",
        },
        "scope": "Universal results and infinite-divergence limits have written proofs in continuations 5 and 6. Samples and finite regularizations are checks, not substitutes for those proofs. No exact finite-tau threshold or novelty claim.",
    }
    Path("results/approximate_uniformity.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
