"""Exploratory capped-bias frontier, not a global certificate."""

from __future__ import annotations

import json
from math import atanh
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hidden_arrow import deficit, golden_maximum, inverse_deficit


def capped_pair(r: float, b: float, grid: int = 120) -> tuple[float, float, float]:
    capacity = deficit(b)
    low, high = r / 2, min(r, capacity)
    if r == 0:
        return 0.0, 0.0, 0.0

    def evaluate(s: float) -> float:
        x = min(b, inverse_deficit(s))
        y = min(b, inverse_deficit(max(0, r - s)))
        return (x + y) * (atanh(x) + atanh(y))

    points = [low + (high - low) * i / grid for i in range(grid + 1)]
    values = [evaluate(s) for s in points]
    candidates = [(points[0], values[0]), (points[-1], values[-1])]
    for index in range(1, grid):
        if values[index] >= values[index - 1] and values[index] >= values[index + 1]:
            candidates.append(golden_maximum(evaluate, points[index - 1], points[index + 1]))
    allocation, objective = max(candidates, key=lambda item: item[1])
    return objective, inverse_deficit(allocation), inverse_deficit(max(0, r - allocation))


def main() -> None:
    rows = []
    for b in (0.2, 0.5, 0.8, 0.95, 0.999):
        capacity = 2 * deficit(b)
        points = []
        for index in range(121):
            r = capacity * index / 120
            value, x, y = capped_pair(r, b)
            points.append({"r": r, "value": value, "x": x, "y": y})
        differences = [points[i + 1]["value"] - 2 * points[i]["value"] + points[i - 1]["value"] for i in range(1, 120)]
        ratios = [row["value"] / row["r"] for row in points[1:]]
        rows.append({
            "cap": b,
            "minimum_discrete_second_difference": min(differences),
            "minimum_ratio_increment": min(ratios[i + 1] - ratios[i] for i in range(len(ratios) - 1)),
            "points": points,
        })
    result = {"status": "floating-point exploration only", "rows": rows}
    Path("results/noise_exploration.json").write_text(json.dumps(result, indent=2) + "\n")
    for row in rows:
        print({key: value for key, value in row.items() if key != "points"})


if __name__ == "__main__":
    main()
