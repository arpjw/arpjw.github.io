"""Rational Taylor identities and separately labeled Decimal diagnostics.

The written proof establishes local uniqueness and exact entropy allocation.
The finite computations audit coefficients and stationary-flow identities;
Decimal critical points do not certify a global optimum or a validity range.
"""
from __future__ import annotations

from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
from itertools import product
import json
from math import factorial
from pathlib import Path

from intervals import I, log as ilog
from nonuniform_threshold import cost, overlap, prod

DEGREE = 9
Poly = list[Q]


def poly(*coefficients: Q) -> Poly:
    return list(coefficients) + [Q(0)] * (DEGREE + 1 - len(coefficients))


def add(a: Poly, b: Poly) -> Poly:
    return [x + y for x, y in zip(a, b)]


def scale(a: Poly, scalar: Q) -> Poly:
    return [scalar * x for x in a]


def mul(a: Poly, b: Poly) -> Poly:
    return [sum((a[j] * b[i-j] for j in range(i + 1)), Q(0)) for i in range(DEGREE + 1)]


def power(a: Poly, n: int) -> Poly:
    result = poly(Q(1))
    for _ in range(n):
        result = mul(result, a)
    return result


def derivative_at_mean(p: Q, n: int) -> Q:
    q = 1 - p
    return factorial(n - 2) * ((-1) ** n * (p ** (-2 * (n - 1)) + q ** (-2 * (n - 1)))
                               + 2 * (p * q) ** (-(n - 1)))


def coefficients(p: Q) -> dict[str, Q]:
    q, r, s = 1 - p, p * (1 - p), 1 - 2 * p
    g2, g3, g4, g5, g6 = (derivative_at_mean(p, n) for n in range(2, 7))
    k2 = g4 / (3 * g2 ** 2)
    k3 = g6 / (45 * g2 ** 3) - g4 ** 2 / (18 * g2 ** 4)
    midpoint = (g5 - 2 * g3 * g4 / g2) / (24 * g2 ** 3)
    imbalance = s * s / (3 * r)
    assert g2 == 1 / r ** 2
    assert k2 == 2 * (1 - 3 * r) ** 2 / (3 * r ** 2)
    assert midpoint == -s * s * (1 - 6 * r * r) / (12 * r * r)
    assert k2 > 0
    return {'quadratic': k2, 'cubic': k3, 'midpoint': midpoint, 'entropy_imbalance': imbalance}


def taylor_audit() -> dict:
    rows = []
    coefficient_checks = 0
    for p in (Q(1, 100), Q(1, 10), Q(1, 5), Q(1, 3), Q(2, 5), Q(49, 100), Q(1, 2)):
        g = {n: derivative_at_mean(p, n) for n in range(2, DEGREE + 3)}
        cs = coefficients(p)
        # Physical midpoint m = u*h^4 is stationary through the required order.
        u = cs['midpoint'] * g[2] ** 2
        h, middle = poly(Q(0), Q(1)), poly(Q(0), Q(0), Q(0), Q(0), u)
        plus, minus = add(middle, h), add(middle, scale(h, -1))
        def expansion(argument: Poly, derivative: int) -> Poly:
            result = poly()
            for n in range(max(2, derivative), DEGREE + 1 + derivative):
                result = add(result, scale(power(argument, n - derivative), g[n] / factorial(n - derivative)))
            return result
        fplus, fminus = expansion(plus, 0), expansion(minus, 0)
        fpplus, fpminus = expansion(plus, 1), expansion(minus, 1)
        fppplus, fppminus = expansion(plus, 2), expansion(minus, 2)
        budget = add(fplus, fminus)
        fp_difference = add(fpplus, scale(fpminus, -1))
        rate = scale(mul(h, fp_difference), 2)
        cm, ch = add(fpplus, fpminus), fp_difference
        jm = scale(mul(h, add(fppplus, scale(fppminus, -1))), 2)
        jh = add(scale(fp_difference, 2), scale(mul(h, add(fppplus, fppminus)), 2))
        stationarity = add(mul(jm, ch), scale(mul(jh, cm), -1))
        assert all(x == 0 for x in stationarity[:7])
        residual = add(rate, scale(budget, -4))
        residual = add(residual, scale(power(budget, 2), -cs['quadratic']))
        residual = add(residual, scale(power(budget, 3), -cs['cubic']))
        assert all(x == 0 for x in residual[:8])
        # Audit the positive-coefficient formula for the whole left branch.
        q = 1 - p
        for n in range(40):
            a = p ** (-2 * (n + 1)) + q ** (-2 * (n + 1)) + 2 * (-1) ** n * (p * q) ** (-(n + 1))
            assert a >= 0
            if n % 2:
                assert a == (p ** (-(n + 1)) - q ** (-(n + 1))) ** 2
            coefficient_checks += 1
        rows.append({'p': str(p), **{key: str(value) for key, value in cs.items()},
                     'stationarity_zero_coefficients_through_degree': 6,
                     'frontier_residual_zero_coefficients_through_degree': 7})
    return {'formal_series_cases': len(rows), 'left_curvature_coefficient_checks': coefficient_checks, 'rows': rows}


def flow_audit() -> dict:
    cases = 0
    for p in (Q(1, 10), Q(1, 3), Q(1, 2)):
        pi = (p, 1 - p)
        for k in range(3, 7):
            u = (1,) + (0,) * (k - 2)
            reverse = u[::-1]
            r = p ** (k - 2) * (1 - p)
            for fraction in (Q(1, 10), Q(1, 100)):
                h = p * p * fraction
                x, y = p * p - h, p * p + h
                def block(w) -> Q:
                    parameter = x if w[1:-1] == u else y if w[1:-1] == reverse else p * p
                    return ((parameter, p - parameter), (p - parameter, 1 - 2 * p + parameter))[w[0]][w[-1]]
                flow = {w: prod(pi[a] for a in w[1:-1]) * block(w) for w in product(range(2), repeat=k + 1)}
                for w in product(range(2), repeat=k):
                    assert sum(flow[w + (a,)] for a in range(2)) == prod(pi[a] for a in w)
                    assert sum(flow[(a,) + w] for a in range(2)) == prod(pi[a] for a in w)
                direct_cost = sum((mass * ilog(I.point(mass / prod(pi[a] for a in w))) for w, mass in flow.items()), I.point(0))
                direct_rate = sum(((mass - flow[w[::-1]]) * ilog(I.point(mass / flow[w[::-1]]))
                                   for w, mass in flow.items() if w < w[::-1]), I.point(0))
                def slope(z: Q) -> I:
                    return ilog(I.point(z)) + ilog(I.point(1 - 2 * p + z)) - 2 * ilog(I.point(p - z))
                overlap(direct_cost, r * (cost(p, p, x) + cost(p, p, y)))
                overlap(direct_rate, r * (y - x) * (slope(y) - slope(x)))
                cases += 1
    return {'exact_two_block_flow_and_rate_cases': cases}


def decimal_diagnostics() -> dict:
    rows = []
    with localcontext() as ctx:
        ctx.prec = 85
        for p_fraction in (Q(1, 10), Q(1, 3), Q(1, 2)):
            p = D(p_fraction.numerator) / D(p_fraction.denominator)
            q, mu = 1 - p, p * p
            cs = {key: D(value.numerator) / D(value.denominator) for key, value in coefficients(p_fraction).items()}
            def f(x: D) -> D:
                return (x * (x / (p*p)).ln() + 2*(p-x)*((p-x)/(p*q)).ln()
                        + (1-2*p+x)*((1-2*p+x)/(q*q)).ln())
            def derivatives(x: D) -> tuple[D, D, D]:
                return (x.ln()+(1-2*p+x).ln()-2*(p-x).ln(),
                        1/x+2/(p-x)+1/(1-2*p+x),
                        -1/(x*x)+2/(p-x)**2-1/(1-2*p+x)**2)
            for exponent in (3, 4, 6):
                budget = D(10) ** -exponent
                x, y = mu - p*q*budget.sqrt(), mu + p*q*budget.sqrt()
                for iteration in range(30):
                    fx, ax, bx = derivatives(x)
                    fy, ay, by = derivatives(y)
                    distance, slope_gap = y-x, fy-fx
                    jx, jy = -slope_gap-distance*ax, slope_gap+distance*ay
                    jxx, jyy, jxy = 2*ax-distance*bx, 2*ay+distance*by, -ax-ay
                    energy_error, stationary_error = f(x)+f(y)-budget, jx*fy-jy*fx
                    if max(abs(energy_error), abs(stationary_error)) < D('1e-68'):
                        break
                    kx, ky = jxx*fy-jxy*fx-jy*ax, jxy*fy+jx*ay-jyy*fx
                    determinant = fx*ky-fy*kx
                    dx = (-energy_error*ky+fy*stationary_error)/determinant
                    dy = (kx*energy_error-fx*stationary_error)/determinant
                    x, y = x+dx, y+dy
                    assert 0 < x < mu < y < p
                else:
                    raise AssertionError('Decimal Newton diagnostic did not converge')
                rate = (y-x)*(derivatives(y)[0]-derivatives(x)[0])
                approximation = 4*budget+cs['quadratic']*budget**2+cs['cubic']*budget**3
                rows.append({'p': str(p_fraction), 'budget': str(budget), 'x': str(x), 'y': str(y),
                             'iterations': iteration, 'energy_residual': str(energy_error),
                             'stationarity_residual': str(stationary_error),
                             'rate': str(rate), 'cubic_expansion_error_over_budget_fourth': str((rate-approximation)/budget**4),
                             'midpoint_shift_over_budget_squared': str(((x+y)/2-mu)/budget**2),
                             'predicted_midpoint_coefficient': str(cs['midpoint']),
                             'entropy_imbalance_over_budget_three_halves': str((f(x)-f(y))/(budget*budget.sqrt())),
                             'predicted_entropy_imbalance_coefficient': str(cs['entropy_imbalance'])})
    return {'status': '85-digit Decimal Newton diagnostics, not interval-certified global optima or a validity cutoff', 'cases': rows}


def main() -> None:
    receipt = {'status': 'exact rational identities and interval flow checks; numerical critical points labeled separately',
               'formal_series': taylor_audit(), 'flows': flow_audit(), 'decimal_diagnostics': decimal_diagnostics()}
    Path('results/biased_local_frontier.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'formal_series_cases': receipt['formal_series']['formal_series_cases'],
                      'left_curvature_coefficient_checks': receipt['formal_series']['left_curvature_coefficient_checks'],
                      **receipt['flows'], 'decimal_diagnostic_cases': len(receipt['decimal_diagnostics']['cases'])}, indent=2))


if __name__ == '__main__':
    main()
