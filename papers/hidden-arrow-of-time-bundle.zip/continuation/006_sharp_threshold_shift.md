# Continuation 6: a sharp asymptotic law for imperfect fairness

Status: written proof with a rational-flow construction and interval-certified examples. Independent review and novelty verification remain outstanding.

Update: [Continuation 7](007_exact_near_threshold.md) now gives the exact threshold for `0<tau<=1/10000`. The construction below remains valid but is not exactly optimal; its proved leading coefficient remains sharp.

## The result

Let `T_3(tau)` be the infimum entropy-rate deficit for which stationary binary Markov sources of order at most three, with strictly positive kernels and
`TV(P_3,U_3)<=tau`, have unbounded observable time-reversal KL rate. All entropies use natural logarithms.

The exact-fairness result gives `T_3(0)=log2/4`. We now obtain the sharp leading perturbation:

\[
\boxed{T_3(\tau)=\frac{\log2}{4}
-\frac34\tau\log\frac1\tau+O(\tau),\qquad\tau\downarrow0.}
\]

The coefficient `3/4` is proved, not fitted. It comes from the conservation laws of binary three-word probabilities. The simpler alternating-orbit construction in Continuation 5 achieves coefficient `2/3`; optimizing its stationary masses improves this to the sharp value.

## 1. Two conservation identities

For any stationary three-word distribution write

\[
\pi(001)=\pi(100)=a,\quad
\pi(011)=\pi(110)=b,\quad
\pi(010)=c,\quad \pi(101)=d,\quad
\pi(000)=e,\quad \pi(111)=f.
\]

Stationarity implies `c+b=a+d`; normalization is `2a+2b+c+d+e+f=1`. Define

\[
z_+=c-a=d-b,\qquad z_-=b-a=d-c.
\]

These linear functionals have the exact representations

\[
z_+=\frac34(c+d)+\frac14(e+f)-\frac14,
\qquad
z_-=\frac{2(b-a)+(d-c)}{3}.
\]

The first is the difference of expectations, between `pi` and the uniform law, of a function taking values `3/4` on `010,101`, `1/4` on `000,111`, and zero elsewhere. The second uses values `-1/3` on `001,100,010`, `1/3` on `011,110,101`, and zero elsewhere. The oscillation bound for total variation gives

\[
\boxed{|z_+|\le\tfrac34\tau,\qquad |z_-|\le\tfrac23\tau.}
\]

Both coefficients can be attained by stationary distributions. Only the first is needed for the sharp extremal construction below.

## 2. Why these differences control a singular transition

Partition four-word flows according to their middle two bits. In a block with middle `01` or `10`, prescribe one edge to have zero mass. Its opposite corner is the other edge that was zero in the corresponding exactly uniform deterministic block. The mass newly available at that opposite corner is one of `z_+,-z_+,z_-,-z_-`, hence is at most `3 tau/4`.

For example, if `q(0011)=0`, conservation of row and column margins forces

\[
q(0010)=a,\quad q(1010)=c-a=z_+,
\quad q(1011)=b.
\]

If `q(0010)=0`, the newly available mass is `q(1011)=b-a=z_-`. The remaining cases follow by exchanging the missing corner, reversing words, or complementing bits.

The block entropy deficit has the form

\[
p\log2-p_jH_2(z/p_j),
\]

where `p` is its context mass, `p_j` is the nondeterministic row mass, and `0<=z<=3 tau/4`. All other blocks have nonnegative deficit. The stationary masses satisfy
`p>=1/4-tau` and `p_j<=1/8+tau`.

For `0<tau<1/16`, the estimate

\[
p_jH_2(z/p_j)\le z\log\frac{e p_j}{z}
\le\frac{3\tau}{4}
\log\frac{e(1/8+\tau)}{3\tau/4}
\]

is valid, with the zero case understood by continuity. The second inequality uses monotonicity in both arguments over this range. Therefore every stationary flow with a zero edge in a middle-`01` or middle-`10` block has deficit at least

\[
L(\tau)=\left(\frac14-\tau\right)\log2
-\frac{3\tau}{4}\log\frac{e(1/8+\tau)}{3\tau/4}.
\]

## 3. A rigorous lower bound for the infinite-divergence threshold

Suppose a sequence at fixed budget and window tolerance has unbounded reversal rate. The space of stationary four-word flows is compact. Because `tau<1/16`, all three-word masses remain bounded below by `1/8-tau>0`, and the entropy rate is continuous on the resulting closed flow set, including zero edges.

Every edge with middle `00` or `11` is either its own reverse or belongs to one of the pairs `0001,1000` and `0111,1110`. The two members in each such pair have equal flow, by conservation at the vertices `000` and `111`. They contribute no joint-flow reversal divergence.

Thus unbounded divergence forces, after passing to a subsequence, some edge with middle `01` or `10` to tend to zero. If all eight such edges were bounded below, `D(q||q^R)` would be bounded, and so would
`sigma=D(q||q^R)-D(pi||pi^R)`.

The limiting flow has deficit at most the sequence's budget and at least `L(tau)` by Section 2. Consequently

\[
\boxed{T_3(\tau)\ge L(\tau)
=\frac{\log2}{4}-\frac34\tau\log\frac1\tau-O(\tau).}
\]

This compactness argument needs no assumed lower bound on the kernels. It also avoids assuming that the limiting reverse edge is positive; both may tend to zero in an arbitrary sequence.

## 4. A construction attaining the leading coefficient

Take `0<tau<1/16` and set

\[
a=b=\frac18-\frac\tau4,
\qquad c=d=\frac18+\frac\tau2,
\qquad e=f=\frac18,
\qquad z=\frac{3\tau}{4}.
\]

These values define a stationary three-word law at TV distance exactly `tau`. In the middle-`01` block set

\[
\begin{pmatrix}q(0010)&q(0011)\\q(1010)&q(1011)\end{pmatrix}
=\begin{pmatrix}a&0\\z&a\end{pmatrix}.
\]

For each other middle context `u`, define the strictly positive block by the product of its prescribed margins:

\[
q(\alpha u\beta)=
\frac{\pi(\alpha u)\pi(u\beta)}{\pi(0u)+\pi(1u)}.
\]

Every block has the prescribed row and column margins. The complete flow is stationary, has exactly one zero edge, and its reverse has positive mass

\[
q(1100)=\frac{a^2}{a+c}>0.
\]

Its exact entropy deficit is

\[
\begin{aligned}
U(\tau)={}&\frac{1+\tau}{4}\log2
-\frac{1+4\tau}{8}H_2\!\left(\frac{6\tau}{1+4\tau}\right)\\
&+\frac{1-\tau}{2}d\!\left(\frac{\tau}{1-\tau}\right)
+\frac{1+\tau}{4}d\!\left(\frac{3\tau}{1+\tau}\right).
\end{aligned}
\]

The last two terms are the costs of the product-margin blocks and are `O(tau^2)`. Expanding the binary entropy gives

\[
\frac{\log2}{4}-U(\tau)
=\frac34\tau\log\frac1\tau
+\tau\left[\frac34(1-\log6)-\frac14\log2\right]
+O(\tau^2).
\]

As before, mix the flow with weight `eta>0` of the fair i.i.d. flow. The mixture has a strictly positive kernel, window TV `(1-eta)tau`, and deficit at most `(1-eta)U(tau)` by concavity of conditional entropy. Its reversal rate satisfies

\[
\sigma_\eta=\frac{a^2}{a+c}\log\frac1\eta+O_\tau(1)
\longrightarrow\infty.
\]

Thus `T_3(tau)<=U(tau)`. Together with the lower bound this proves

\[
L(\tau)\le T_3(\tau)\le U(\tau),\qquad
T_3(\tau)=\frac{\log2}{4}-\frac34\tau\log\frac1\tau+O(\tau).
\]

## 5. Scope and next questions

This determines the sharp leading asymptotic coefficient, not the exact function `T_3(tau)` or its linear correction. The displayed construction need not be optimal at finite `tau`. The two explicit bounds are reproducible without numerical optimization.

For larger memory, the leading coefficient should depend on how stationary word-mass conservation allows one of two forbidden edges to reopen. The order-three proof reduces that issue to two elementary linear functionals. A general graph formulation and its dependence on `k` remain open here.

The new evidence is independent of the interval proof of optimizer uniqueness: this perturbation theorem uses only the original exact-uniform threshold, elementary finite-flow conservation, entropy inequalities, and compactness. The initial result and all earlier checkpoints remain unchanged.
