# Continuation 7: the exact singular threshold near uniformity

Status: written proof with six rigorous logarithm-interval inequalities. The entire parameter interval is certified; numerical sampling is supplementary. Independent expert review and novelty verification remain outstanding.

## 1. Exact formula and what changed

For every `0<tau<=1/10000`, the order-three singular threshold from Continuation 6 is exactly

\[
\boxed{T_3(\tau)=V(\tau),}
\]

where

\[
\begin{aligned}
V(\tau)={}&\frac{1-\tau}{4}\log2
-\frac{1+2\tau}{8}H_2\!\left(\frac{6\tau}{1+2\tau}\right)\\
&+\frac{1+\tau}{2}d\!\left(\frac{\tau}{1+\tau}\right)
+\frac{1-\tau}{4}d\!\left(\frac{3\tau}{1-\tau}\right).
\end{aligned}
\]

Here `H_2` is binary entropy in nats and `d(x)=log2-H_2((1+x)/2)`. If the entropy deficit is below `V(tau)`, the reversal-rate supremum is finite. At or above it, the supremum is infinite, even though every source in the approximating sequence has a strictly positive kernel.

Consequently the next asymptotic term is also identified:

\[
T_3(\tau)=\frac{\log2}{4}-\frac34\tau\log\frac1\tau
+\left(\frac34\log6-\frac34-\frac14\log2\right)\tau
+O(\tau^2).
\]

The linear coefficient is about `0.4205328067810549233`.

The previous construction `U(tau)` remains a valid upper bound and its sharp leading coefficient `3/4` remains correct. It is not exactly optimal: forbidding the alternating word `1010` is better than forbidding `0011`. The improvement is `(log2) tau/2+O(tau^2)`. The earlier handoff proposed testing `U` for exact optimality; the present comparison refutes that proposed extension. No earlier theorem needs retraction.

## 2. Classify the possible singular edges

As before, write stationary three-word masses as

`pi(000)=e, pi(001)=pi(100)=a, pi(010)=c,`
`pi(011)=pi(110)=b, pi(101)=d, pi(111)=f`,

with `c+b=a+d`. All three-word masses are positive for the tolerance range considered here.

Zero edges capable of causing observable reversal divergence fall into three orbits under word reversal and bit complementation:

| Type | Possible missing edges | Representative |
|---|---|---|
| A | `0011,1100` | `0011` |
| B | `1010,0101` | `1010` |
| C | `0010,0100,1011,1101` | `0010` |

Every edge with middle `00` or `11` is self-reversing or has the same stationary flow as its reverse, so cannot produce divergence. This is exactly the classification used in Continuation 6, now keeping the two distinct `z_+` orbits separate. Types A and B both have the leading coefficient `3/4`; type C has at most `2/3`.

## 3. Symmetry and convexity reduce A and B to a polygon

Let `R` reverse all four bits and `C` complement them. The operation `CR` fixes both representative missing words `0011` and `1010`. Average a feasible flow with its `CR` transform. This preserves stationarity and the zero-edge constraint. It cannot increase the window TV. Conditional entropy is concave in the joint flow and invariant under `CR`, so the average cannot have larger deficit.

Every stationary binary three-word law is reversal invariant. Therefore the averaged marginal is complement invariant, giving

\[
a=b,\qquad c=d,\qquad e=f,\qquad 2a+c+e=1/2.
\]

At fixed marginal, each unconstrained middle-context block maximizes conditional entropy uniquely when it is the product of its row and column margins. The constrained block is fixed by its margins and its zero edge. For `f(x)=x log x`, with `f(0)=0`, the resulting deficits are

\[
F_A=\log2+f(z)+4f(a)+2f(e)-2f(e+a)-f(a+c),\quad z=c-a\ge0,
\]

\[
F_B=\log2+f(z)+2f(a)+2f(c)+2f(e)-2f(e+a)-f(a+c),\quad z=a-c\ge0.
\]

These are convex functions of the marginal variables on their feasible domains: they are partial minimizations of the convex conditional-entropy deficit over affine flow constraints. This argument avoids having to infer convexity from the displayed differences of `x log x` terms.

Set `E=e-1/8`. For type A,

\[
a=1/8-(z+E)/3,\qquad c=1/8+(2z-E)/3,
\]

and for type B,

\[
a=1/8+(z-E)/3,\qquad c=1/8-(2z+E)/3.
\]

The TV constraints are respectively

\[
\frac{2|z+E|+|2z-E|}{3}+|E|\le\tau,
\qquad
\frac{2|z-E|+|2z+E|}{3}+|E|\le\tau.
\]

Put `z_0=3 tau/4`. The candidate vertex is `(z,E)=(z_0,0)` for both types. Direct triangle inequalities give the global feasible bounds

\[
\begin{array}{c|cc}
&E\ge0&E\le0\\\hline
A&z-z_0\le-E&z-z_0\le E/2\\
B&z-z_0\le-E/2&z-z_0\le E.
\end{array}
\]

Because `F_A,F_B` are convex, a supporting gradient at the vertex proves global optimality. It suffices to have `F_z<0` and

\[
F_{A,z}<F_{A,E}<-F_{A,z}/2,
\qquad
F_{B,z}/2<F_{B,E}<-F_{B,z}.
\]

For example, when type B has `E>=0`, the supporting-plane increase is at least `(F_E-F_z/2)E`; when `E<=0`, it is at least `(F_z+F_E)E`. Both are strictly positive away from `E=0`. At `E=0`, decreasing `z` also strictly increases the supporting plane. Thus these strict inequalities prove that the vertex is the unique optimum in the symmetrized polygon.

## 4. The six uniform inequalities

At the vertex let `p=a+c`, `w=e+a`, and `e=1/8`. Write `F_z=log z+R`. Differentiation gives

\[
R_A=-\frac43\log a+\frac23\log w-\frac13\log p,
\]

\[
F_{A,E}=-\frac43\log a+2\log e-\frac43\log w+\frac23\log p,
\]

\[
R_B=\frac23\log a-\frac43\log c-\frac23\log w+\frac13\log p,
\]

\[
F_{B,E}=-\frac23\log a-\frac23\log c+2\log e-\frac43\log w+\frac23\log p.
\]

For A the vertex has `a=1/8-tau/4,c=1/8+tau/2`; for B it has `a=1/8+tau/4,c=1/8-tau/2`. All logarithms in `R_A,R_B,F_E` remain regular at `tau=0`.

The exact interval script encloses those smooth expressions on the single interval `0<=tau<=1/10000`. It handles `log z` using
`log z <= log(3/40000)`, so it never evaluates `log(0)`. It obtains

`F_A,z < -7.1872`, `F_B,z < -7.6489`,

and the following strict lower bounds valid over the whole interval:

| Quantity | Certified lower bound, rounded down |
|---|---:|
| `F_A,E - F_A,z` | `6.7250` |
| `-F_A,z/2 - F_A,E` | `4.0551` |
| `F_B,E - F_B,z/2` | `3.3619` |
| `-F_B,z - F_B,E` | `8.1106` |
| `(U-V)'` | `0.3459` |
| `(L_C-V)'` | `0.0182` |

The first four prove exact vertex optimality for A and B. Substitution into the entropy formulas gives type-A value `U(tau)` from Continuation 6 and type-B value `V(tau)` above.

For the fifth bound, the singular logarithms cancel:

\[
(U-V)'=\frac34(R_A-R_B)>0.
\]

Since `U(0)=V(0)=log2/4`, type A is strictly worse for every positive tolerance in the certified interval.

For type C, replace `3/4` by `2/3` in the lower-bound argument of Continuation 6:

\[
L_C(\tau)=\left(\frac14-\tau\right)\log2
-\frac{2\tau}{3}\log\frac{e(1/8+\tau)}{2\tau/3}.
\]

The derivative difference is

\[
\begin{aligned}
(L_C-V)'={}&-\frac1{12}\log\tau-\log2
-\frac23\log\frac{1/8+\tau}{2/3}
-\frac{2\tau}{3(1/8+\tau)}\\
&-\frac34\log\frac34-\frac34R_B.
\end{aligned}
\]

Use `-log tau>=log 10000` and the same smooth interval enclosure. This gives the sixth bound. As `L_C(0)=V(0)`, every type-C boundary flow also has strictly greater deficit than `V`.

All signs use outward-rounded integer intervals and explicit logarithm-series tails. This is a small computer-assisted step over a continuum, not an assertion based on a grid. The full decimal bounds and reproduction code are saved in `results/exact_near_threshold.json` and `continuation/exact_near_threshold.py`.

## 5. Attainment in the boundary and the strictly positive sequence

For the minimizing type B, set

\[
a=b=1/8+\tau/4,\qquad c=d=1/8-\tau/2,\qquad e=f=1/8,
\quad z=3\tau/4.
\]

The middle-`01` flow block is

\[
\begin{pmatrix}q(0010)&q(0011)\\q(1010)&q(1011)\end{pmatrix}
=\begin{pmatrix}c&z\\0&c\end{pmatrix}.
\]

Use product margins for the other three blocks. The flow is stationary, has marginal TV exactly `tau`, and has precisely one zero edge, `1010`. Its reverse has mass

\[
q(0101)=\frac{c^2}{a+c}>0.
\]

Its deficit is `V(tau)`. Mixing with weight `eta` of the fair i.i.d. flow makes all transitions positive, decreases TV to `(1-eta)tau`, and gives deficit at most `(1-eta)V(tau)`. The reversal rate diverges as

\[
\sigma_\eta=\frac{c^2}{a+c}\log\frac1\eta+O_\tau(1).
\]

This proves infinite supremum at budget `V(tau)`. Conversely, any unbounded sequence below that budget has a compact-limit flow with a singular edge in A, B, or C. The preceding minimizations and bound show its deficit is at least `V(tau)`, a contradiction. Thus the exact threshold and the finite/infinite distinction follow.

## 6. Uniqueness of the critical boundary source

Up to observable reversal, exactly one boundary flow minimizes the deficit among flows capable of producing the singular threshold, for every positive tolerance in the certified range.

Types A and C are strictly excluded. For B, the strict supporting-gradient inequalities force the symmetrized marginal vertex uniquely, and conditional-entropy maximization at fixed margins fixes every unconstrained block uniquely. To exclude an unsymmetrized flow with the same value, equality in the conditional-entropy concavity step forces it and its `CR` transform to have identical row kernels. Their average is the constructed flow, so they share its kernel.

That kernel is irreducible. Every transition is allowed except `1010`: from any context, append `111000` to reach `000`; from `000`, append any three target bits to reach the desired context. Neither route uses `1010`. A finite irreducible kernel has a unique stationary law, so the original flow equals its symmetrized optimizer. The other missing word `0101` gives exactly the reversal partner.

This is uniqueness of the critical boundary construction, not an assertion of a finite maximizing positive kernel when the supremum is infinite.

## 7. Certified numbers, audit, and open scope

At `tau=1/10000`,

`T_3(tau)` lies in `(0.17263809414514177968, 0.17263809414514177969)` nats.

At `tau=1/1000000`, it lies in `(0.17327685404199963757, 0.17327685404199963758)` nats. These shortened brackets are outward enclosures of the full 40-decimal certificate.

At the earlier example `tau=0.00075`, the new construction gives an improved upper bound about `0.16955595755112`. That tolerance lies outside the interval certified here, so exact optimality is not asserted there.

The script also tests 2,000 feasible polygon competitors and 48 finite-difference gradient comparisons. These are numerical diagnostics, separate from the uniform sign certificate. It compares the closed entropy formula with independently summed rational-flow conditional entropies at three tolerances, and certifies strictly positive regularizations.

The coefficient `3/4` proof from Continuation 6 survives this audit. The nonoptimality of `U` corrects only a proposed continuation, not the earlier bound or theorem. The interval `1/10000` is a convenient proved range, not a claimed phase boundary. Extending the exact formula, finding where the marginal optimum leaves the vertex, and handling larger memory remain open.
