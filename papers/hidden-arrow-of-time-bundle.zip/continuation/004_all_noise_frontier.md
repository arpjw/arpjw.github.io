# Continuation 4: the full entropy-and-noise frontier

Status: written proof building on the computer-assisted uniqueness theorem in Continuation 3. The statements remain research-draft results pending independent review and a broader priority search.

## The surprising resolution

The capped pair envelope can appear nonconvex numerically, so the convexity proof used in the high-noise regime does not extend directly. Nevertheless, the same saturation structure holds at **every** positive noise floor.

The reason is not convexity of the capped envelope. It is a combination of rearranging which magnitudes are paired, local convexity of fully interior optimal pairs, and a strict marginal-value comparison for a pair with exactly one capped magnitude.

Let `0<b<1`, `c_b=d(b)`, and `C=2c_b`. Define the exact capped-pair envelope

\[
F_b(r)=\max_{r/2\le s\le\min(r,c_b)}
[a(s)+a(r-s)][A(a(s))+A(a(r-s))],
\qquad 0\le r\le C.
\]

Let `N=2^(k-1)`, `P=2^ceil((k-1)/2)`, and `m=(N-P)/2`. The cap `b` corresponds to transition floor `epsilon=(1-b)/2`.

**Theorem.** Set `R=min(N delta,m C)`, `j=floor(R/C)`, and `q=R-j C`. At `R=m C` set `j=m,q=0`. Then

\[
\boxed{M_{k,\epsilon}(\delta)=\frac{4j b A(b)+F_b(q)}{N}.}
\]

An optimizer saturates `j` reversed pairs at `(+b,-b)`, uses at most one further pair, and leaves all other biases zero. Thus the full Markov optimization, for every memory length and every positive noise floor, reduces to one bounded scalar optimization.

For `b=0` or `m=0`, the value is zero. If the budget exceeds the cost of saturating all useful pairs, surplus allowance need not be used.

## 1. Pair large magnitudes with large magnitudes

For nonnegative magnitudes, write `J(x,y)=(x+y)(A(x)+A(y))`. Its cross terms are `x A(y)+y A(x)`. If `w>=x>=y>=z>=0`, then

\[
J(w,x)+J(y,z)-J(w,y)-J(x,z)
=(w-z)(A(x)-A(y))+(x-y)(A(w)-A(z))\ge0,
\]

and

\[
J(w,x)+J(y,z)-J(w,z)-J(x,y)
=(w-y)(A(x)-A(z))+(x-z)(A(w)-A(y))\ge0.
\]

Repeated exchanges therefore show that an optimal assignment pairs adjacent entries in the sorted list of magnitudes. Cost and the cap are unchanged. Opposite signs maximize each pair, and palindromic contexts can be set to zero.

In particular, all capped magnitudes are paired with each other, except possibly one cap that is paired with the largest remaining uncapped magnitude. There is at most one pair with exactly one capped coordinate.

## 2. There cannot be two positive fully interior pairs

Consider a globally optimal configuration after the preceding rearrangement. A pair with neither coordinate capped and positive cost must have both magnitudes positive: a vanishing smaller magnitude can be increased with only second-order cost and first-order objective gain.

It is a local maximizer at its own fixed cost. If it is symmetric, it belongs to the feasible local family `S(r)`, which is strictly convex in cost.

If it is unequal and its cost is below `r_t`, the symmetric pair at the same cost is feasible, since its common magnitude lies between the two unequal magnitudes. It strictly improves the objective, by Continuation 3. Thus this case is impossible in a global configuration.

If it is unequal at cost at least `r_t`, the stationary-curve classification in Continuation 3 applies. The first curve segment gives local minima, the middle segment lies below `r_t`, and the increasing upper segment is the only possible local maximum. This segment has strictly positive curvature as an objective-versus-cost family, because its multiplier increases and its cost increases. Its cost is always below `log2`.

There are no unequal stationary points at cost `log2` or higher: all three curve regions in Continuation 3 lie below `log2`. A symmetric point at such a cost is locally unstable, so a fully interior optimal pair cannot have that cost either.

Consequently every positive fully interior pair has a locally feasible, strictly convex objective-versus-cost family through it. If two such pairs existed, vary their costs as `r_1+s` and `r_2-s`. The resulting sum is strictly convex in `s`, and hence cannot have a local maximum at the interior point `s=0`. This is a contradiction.

The argument also covers coexistence at `r_t`: use the smooth symmetric or unequal family corresponding to the pair actually chosen. An upward corner in the global envelope is not needed for this local argument.

## 3. A singly capped pair cannot coexist with an interior pair

Suppose both types are present. By sorted pairing, their magnitudes have the form

\[
(b,y),\quad (x,z),\qquad b>y\ge x\ge z>0.
\]

The singly capped pair's marginal value when increasing the entropy cost of `y` is

\[
\mu=\frac{A(b)+A(y)+(b+y)/(1-y^2)}{A(y)}.
\]

Define the symmetric-pair marginal value at magnitude `w`:

\[
T(w)=2+\frac{2w}{(1-w^2)A(w)}=S'(2d(w)).
\]

This function strictly increases, by the convexity of `S`. Since `b>y`,

\[
\mu-T(y)=\frac{A(b)-A(y)+(b-y)/(1-y^2)}{A(y)}>0.
\]

The interior pair is stationary, so its multiplier can be computed using the derivative in its larger coordinate:

\[
\lambda=\frac{A(x)+A(z)+(x+z)/(1-x^2)}{A(x)}\le T(x),
\]

with equality exactly when `x=z`. Therefore

\[
\mu>T(y)\ge T(x)\ge\lambda.
\]

Transfer a sufficiently small positive amount of cost from the interior pair to the uncapped coordinate `y` of the singly capped pair. The first-order objective change is positive, contradicting optimality. The case `y=0` cannot occur alongside a positive interior pair in a sorted assignment; it can also be excluded by the square-root gain from activating `y`.

## 4. Completion of the saturation theorem

There is at most one positive fully interior pair, at most one singly capped pair, and these types cannot coexist. Every other positive pair has both coordinates at the cap.

The objective increases when a noncapped positive magnitude is increased. Thus the budget is used until every useful pair is saturated. The number of full pairs and the remaining pair cost are exactly `j` and `q` in the theorem. The last pair contributes `F_b(q)`. This proves the formula.

This is an existence theorem for a canonical optimizer. Relabeling contexts, changing signs, and unused entropy allowance can produce further equivalent optimizers. It is not a uniqueness claim for the full labeled Markov source.

## 5. The remaining scalar problem has an explicit candidate list

The scalar envelope need not be evaluated by a blind search. Write

\[
B_b(r)=[b+a(r-c_b)][A(b)+A(a(r-c_b))],
\quad c_b\le r\le2c_b.
\]

Let `(x_r,y_r)`, `x_r>y_r`, be the unique ordered unequal optimizer of the uncapped problem for `r_t<r<log2`, as established in Continuation 3.

For feasible budgets:

1. If `0<=r<=r_t`, then `F_b(r)=S(r)`.
2. If `r_t<r<log2` and `x_r<=b`, then `F_b(r)=F(r)`.
3. If `r_t<r<log2` and `x_r>b`, then `F_b(r)=max(S(r),B_b(r))`. In this case `r>c_b`, so the boundary expression is defined.
4. If `log2<=r<=2c_b`, then `F_b(r)=B_b(r)`.

For the third case, the only possible interior unequal local maximum is the uncapped optimizer, which lies outside the cap. The remaining maximum must be symmetric or on the cap boundary. For the fourth case there are no unequal interior stationary points, and symmetry is a strict local minimum unless the feasible interval is a singleton. The cap boundary therefore maximizes.

At `r=r_t`, the symmetric candidate always attains the value; the unequal candidate also attains it when it fits under the cap. At `r=2c_b`, the feasible pair is simply `(b,b)`.

For `b<=z_c`, this reduces to the high-noise closed formula from Continuation 2. The nonconvex behavior suggested by the low-noise plots does not invalidate the saturation theorem: the proof uses pairing and marginal comparisons instead of global convexity of `F_b`.

## Numerical falsification attempt

`continuation/stress_all_noise.py` tested 1,500 deterministic competing configurations using seed 716031, eight caps from 0.2 through 0.999, and two, three, or five reversed pairs. Competing magnitudes were sorted and paired optimally to make the comparison stronger. No competitor exceeded the predicted saturated construction beyond the stated `1e-9` floating-point tolerance. The worst signed difference was about `-1.1e-13` in an essentially tied saturated case. The receipt is `results/all_noise_stress.json`.

These are numerical diagnostics, not a proof. In particular, the last-pair optimizer used by this test is a sampled and locally refined numerical lower bound; the written theorem above carries the global claim.
