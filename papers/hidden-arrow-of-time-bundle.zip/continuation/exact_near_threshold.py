"""Certify the exact order-three nearby singular threshold for 0 < tau <= 1e-4.

The proof reduces the universal claim to six interval inequalities on one
closed interval. log(tau) is separated analytically; log(0) is never evaluated.
Fractions define flows exactly. Floating-point stress checks are separate.
"""

from __future__ import annotations

from fractions import Fraction as Q
import json
from math import log
from pathlib import Path
import random

from intervals import I, ln2, log as ilog
from approximate_uniformity import (
    Flow, binary_entropy_interval, deficit_interval, entropy_deficit,
    fair_flow, kernel, marginals, mix, rate_interval, sharp_singular_flow, tv, words,
)


TAU_MAX = Q(1, 10000)


def smooth_gradients(tau: I, kind: str) -> tuple[I, I]:
    """Return F_z-log(z) and F_E at z=3*tau/4, E=0."""
    e = I.point(Q(1, 8))
    if kind == "A":
        a, c = e - tau / 4, e + tau / 2
    elif kind == "B":
        a, c = e + tau / 4, e - tau / 2
    else:
        raise ValueError(kind)
    p, w = a + c, a + e
    if kind == "A":
        remainder = -4 * ilog(a) / 3 + 2 * ilog(w) / 3 - ilog(p) / 3
        transverse = -4 * ilog(a) / 3 + 2 * ilog(e) - 4 * ilog(w) / 3 + 2 * ilog(p) / 3
    else:
        remainder = 2 * ilog(a) / 3 - 4 * ilog(c) / 3 - 2 * ilog(w) / 3 + ilog(p) / 3
        transverse = -2 * ilog(a) / 3 - 2 * ilog(c) / 3 + 2 * ilog(e) - 4 * ilog(w) / 3 + 2 * ilog(p) / 3
    return remainder, transverse


def interval_certificate() -> dict:
    t = I.hull(0, TAU_MAX)
    ra, ea = smooth_gradients(t, "A")
    rb, eb = smooth_gradients(t, "B")
    # Each actual F_z(t) is <= this interval's upper endpoint.
    za_upper = ilog(I.point(3 * TAU_MAX / 4)) + ra
    zb_upper = ilog(I.point(3 * TAU_MAX / 4)) + rb
    assert za_upper.hi < 0 and zb_upper.hi < 0
    proxies = {
        "A_E_minus_z": ea - za_upper,
        "A_minus_z_over_2_minus_E": -za_upper / 2 - ea,
        "B_E_minus_z_over_2": eb - zb_upper / 2,
        "B_minus_z_minus_E": -zb_upper - eb,
        "U_minus_V_derivative": 3 * (ra - rb) / 4,
        # L_C'(tau)-V'(tau) = -(1/12)log(tau) plus a smooth remainder.
        "C_lower_bound_minus_V_derivative": (
            -ilog(I.point(TAU_MAX)) / 12 - ln2()
            - 2 * ilog((I.point(Q(1, 8)) + t) / Q(2, 3)) / 3
            - 2 * t / (3 * (I.point(Q(1, 8)) + t))
            - 3 * ilog(I.point(Q(3, 4))) / 4 - 3 * rb / 4
        ),
    }
    assert all(value.lo > 0 for value in proxies.values())
    return {
        "tau_domain": ["0 (excluded for the singular logarithm)", str(TAU_MAX)],
        "A_smooth_z_remainder": ra.decimal_bounds(),
        "B_smooth_z_remainder": rb.decimal_bounds(),
        "A_transverse_derivative": ea.decimal_bounds(),
        "B_transverse_derivative": eb.decimal_bounds(),
        "A_z_derivative_upper_bound": za_upper.decimal_bounds()[1],
        "B_z_derivative_upper_bound": zb_upper.decimal_bounds()[1],
        "positive_margin_lower_bounds": {key: value.decimal_bounds()[0] for key, value in proxies.items()},
        "interpretation": "The stored numbers are rigorous lower bounds over the whole interval, not samples. log(tau)<=log(tau_max) and its negation handle the endpoint at zero analytically.",
    }


def alternating_forbidden_flow(tau: Q) -> Flow:
    assert 0 < tau < Q(1, 16)
    a, c, e, z = Q(1, 8) + tau / 4, Q(1, 8) - tau / 2, Q(1, 8), 3 * tau / 4
    pi = {"000": e, "001": a, "010": c, "011": a, "100": a, "101": c, "110": a, "111": e}
    q = {word: pi[word[:-1]] * pi[word[1:]] / (pi["0" + word[1:-1]] + pi["1" + word[1:-1]]) for word in words(4)}
    q.update({"0010": c, "0011": z, "1010": Q(0), "1011": c})
    assert marginals(q) == pi
    assert tv(pi, {s: Q(1, 8) for s in pi}) == tau
    assert q["0101"] == c * c / (a + c)
    assert sum(value == 0 for value in q.values()) == 1
    return q


def threshold_formula(tau: Q) -> I:
    def d(x: Q) -> I:
        return ln2() - binary_entropy_interval((1 + x) / 2)
    return (
        I.point((1 - tau) / 4) * ln2()
        - I.point((1 + 2 * tau) / 8) * binary_entropy_interval(6 * tau / (1 + 2 * tau))
        + I.point((1 + tau) / 2) * d(tau / (1 + tau))
        + I.point((1 - tau) / 4) * d(3 * tau / (1 - tau))
    )


def reduced_deficit(z: float, transverse: float, kind: str) -> float:
    e = 0.125 + transverse
    if kind == "A":
        a = 0.125 - (z + transverse) / 3
        c = 0.125 + (2 * z - transverse) / 3
    else:
        a = 0.125 + (z - transverse) / 3
        c = 0.125 - (2 * z + transverse) / 3
    def f(x: float) -> float:
        return x * log(x) if x else 0.0
    if kind == "A":
        return log(2) + f(z) + 4 * f(a) + 2 * f(e) - 2 * f(e + a) - f(a + c)
    return log(2) + f(z) + 2 * f(a) + 2 * f(c) + 2 * f(e) - 2 * f(e + a) - f(a + c)


def main() -> None:
    certificate = interval_certificate()
    examples = []
    for tau in (TAU_MAX, Q(1, 1000000), Q(3, 4000)):
        flow = alternating_forbidden_flow(tau)
        flow_value, formula_value = deficit_interval(flow), threshold_formula(tau)
        assert max(flow_value.lo, formula_value.lo) <= min(flow_value.hi, formula_value.hi)
        old_value = deficit_interval(sharp_singular_flow(tau))
        assert flow_value.hi < old_value.lo
        eta = Q(1, 10**20)
        regularized = mix(flow, fair_flow(3), eta)
        regularized_value = deficit_interval(regularized)
        assert regularized_value.hi < flow_value.lo
        examples.append({
            "tau": str(tau),
            "scope": "exact threshold" if tau <= TAU_MAX else "improved upper bound only; outside certified optimality interval",
            "threshold_or_bound_interval": flow_value.decimal_bounds(),
            "improvement_over_previous_U_interval": (old_value - flow_value).decimal_bounds(),
            "divergence_log_coefficient": str(flow["0101"]),
            "eta": str(eta),
            "positive_regularization_deficit": regularized_value.decimal_bounds(),
            "positive_regularization_rate": rate_interval(regularized).decimal_bounds(),
        })

    rng = random.Random(716070)
    trials = 2000
    smallest_gap = 1.0
    gradient_audits = 0
    for index in range(trials):
        tau = float(TAU_MAX) * (0.0001 + 0.9999 * rng.random())
        kind = "A" if index % 2 else "B"
        z, transverse = rng.random(), 2 * rng.random() - 1
        if kind == "A":
            norm = (2 * abs(z + transverse) + abs(2 * z - transverse)) / 3 + abs(transverse)
        else:
            norm = (2 * abs(z - transverse) + abs(2 * z + transverse)) / 3 + abs(transverse)
        scale = tau * rng.random() / norm
        z, transverse = z * scale, transverse * scale
        value = reduced_deficit(z, transverse, kind)
        optimal = reduced_deficit(3 * tau / 4, 0, kind)
        gap = value - optimal
        smallest_gap = min(smallest_gap, gap)
        assert gap > -2e-14
        if index < 24:
            point = Q(str(tau))
            r, de = smooth_gradients(I.point(point), kind)
            predicted_z = log(3 * tau / 4) + float(sum(r.fraction_bounds()) / 2)
            predicted_e = float(sum(de.fraction_bounds()) / 2)
            step = tau * 1e-3
            observed_z = (reduced_deficit(3 * tau / 4 + step, 0, kind) - reduced_deficit(3 * tau / 4 - step, 0, kind)) / (2 * step)
            observed_e = (reduced_deficit(3 * tau / 4, step, kind) - reduced_deficit(3 * tau / 4, -step, kind)) / (2 * step)
            assert abs(predicted_z - observed_z) < 3e-5
            assert abs(predicted_e - observed_e) < 3e-5
            gradient_audits += 2
    linear = 3 * ilog(I.point(6)) / 4 - I.point(Q(3, 4)) - ln2() / 4
    report = {
        "status": "PASS: exact threshold certified on the entire interval 0 < tau <= 1/10000",
        "proof": "continuation/007_exact_near_threshold.md",
        "universal_interval_certificate": certificate,
        "linear_asymptotic_coefficient_interval": linear.decimal_bounds(),
        "certified_examples": examples,
        "floating_point_diagnostics": {"seed": 716070, "polygon_trials": trials, "smallest_competitor_gap": smallest_gap, "finite_difference_gradient_checks": gradient_audits, "gradient_tolerance": 3e-5},
        "scope": "Convexity, symmetry reduction, edge classification and compactness have written proofs. Six exact logarithm-interval inequalities certify the only remaining uniform signs. The random samples and finite differences are diagnostics only. No novelty or independent review claim.",
    }
    Path("results/exact_near_threshold.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
