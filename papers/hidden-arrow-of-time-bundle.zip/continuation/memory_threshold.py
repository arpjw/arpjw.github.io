"""Rational constructions and bounds for the all-memory asymptotic theorem."""

from fractions import Fraction as Q
import json
from pathlib import Path

from approximate_uniformity import (
    Flow, binary_entropy_interval, deficit_interval, fair_flow, marginals,
    mix, rate_interval, tv,
)
from intervals import I, ln2, log as ilog
from memory_coefficient import check_certificate, complement, objective, words


def cycle_law(k: int, cycle: str) -> dict[str, Q]:
    result = {word: Q(0) for word in words(k)}
    for offset in range(len(cycle)):
        word = "".join(cycle[(offset+j) % len(cycle)] for j in range(k))
        result[word] += Q(1, len(cycle))
    return result


def long_run_direction(k: int) -> tuple[str, dict[str, Q]]:
    left, right = cycle_law(k, "1" + "0"*(k-2)), cycle_law(k, "1" + "0"*(k-1))
    return "0"*(k-1) + "11", {word: Q(k, 2) * (left[word]-right[word]) for word in left}


def alternating_direction(k: int) -> tuple[str, dict[str, Q]]:
    assert k >= 3 and k % 2 == 1
    missing = "0" + "01"*((k-1)//2) + "1"
    left, right = cycle_law(k, "01"), cycle_law(k, missing)
    return missing, {word: left[word]-right[word] for word in left}


def check_direction(k: int, missing: str, direction: dict[str, Q], expected: Q) -> None:
    assert sum(direction.values()) == 0 and sum(abs(x) for x in direction.values()) == 2
    for u in words(k-1):
        assert sum(direction[a+u] for a in "01") == sum(direction[u+b] for b in "01")
    assert missing != missing[::-1]
    assert sum(value * direction[edge] for edge, value in objective(missing).items()) == expected


def boundary_flow(k: int, missing: str, direction: dict[str, Q], tau: Q) -> Flow:
    h = Q(1, 2**k)
    assert 0 < tau <= h/4
    pi = {word: h + tau * direction.get(word, Q(0)) for word in words(k)}
    assert min(pi.values()) > 0
    q = {word: pi[word[:-1]] * pi[word[1:]] / (pi["0"+word[1:-1]] + pi["1"+word[1:-1]]) for word in words(k+1)}
    a, u, b = missing[0], missing[1:-1], missing[-1]
    aa, bb = complement(a), complement(b)
    z = pi[u+bb] - pi[a+u]
    assert z > 0
    q.update({a+u+b: Q(0), a+u+bb: pi[a+u], aa+u+b: pi[u+b], aa+u+bb: z})
    assert marginals(q) == pi
    assert tv(pi, {word:h for word in pi}) == tau
    assert sum(x == 0 for x in q.values()) == 1
    assert q[missing[::-1]] > 0
    return q


def lower_bound(k: int, alpha: Q, tau: Q) -> I:
    h, z = Q(1, 2**k), alpha*tau
    return (2*h-tau)*ln2() - z*(1+ilog(I.point((h+tau)/z)))


def upper_bound(k: int, alpha: Q, tau: Q) -> I:
    h, z = Q(1, 2**k), alpha*tau
    remainder = 2*tau*tau / ((2*h-tau)**2-4*tau*tau)
    return (2*h+tau)*ln2() - z*ilog(I.point((h-tau)/z)) + remainder


def main() -> None:
    certificate = json.loads(Path("results/memory_coefficient.json").read_text())
    construction_checks = []
    # These checks supplement, and do not replace, the all-k cycle proof.
    for k in range(3, 17):
        missing, direction = long_run_direction(k)
        check_direction(k, missing, direction, Q(k, 2*(k-1)))
        construction_checks.append({"k": k, "family": "long run", "coefficient": str(Q(k, 2*(k-1)))})
        if k % 2:
            missing, direction = alternating_direction(k)
            check_direction(k, missing, direction, Q(1,2)+Q(1,k+1))
            construction_checks.append({"k": k, "family": "alternating", "coefficient": str(Q(1,2)+Q(1,k+1))})
    examples = []
    for k in (3, 4, 7, 10):
        row = next(row for row in certificate["table"] if row["k"] == k)
        record = next(record for record in certificate["certificates"] if record["k"] == k and record["missing_word"] == row["maximizing_representatives"][0])
        alpha = check_certificate(record)
        direction = {word: Q(value) for word, value in record["direction"].items()}
        tau = Q(1, 1000000 * 2**k)
        q = boundary_flow(k, record["missing_word"], direction, tau)
        value, low, high = deficit_interval(q), lower_bound(k,alpha,tau), upper_bound(k,alpha,tau)
        assert low.hi < value.lo <= value.hi < high.lo
        normalized = (Q(1, 2**(k-1))*ln2() - value) / (tau*ilog(I.point(1/tau)))
        positive = mix(q, fair_flow(k), Q(1,10**30))
        positive_value = deficit_interval(positive)
        assert positive_value.hi < value.lo
        examples.append({
            "k": k, "alpha": str(alpha), "tau": str(tau), "missing_word": record["missing_word"],
            "universal_lower_bound": low.decimal_bounds(), "constructed_deficit": value.decimal_bounds(),
            "universal_construction_upper_bound": high.decimal_bounds(),
            "normalized_threshold_shift_of_construction": normalized.decimal_bounds(),
            "divergence_log_coefficient": str(q[record["missing_word"][::-1]]),
            "positive_regularization_eta": "1/1000000000000000000000000000000",
            "positive_regularization_deficit": positive_value.decimal_bounds(),
            "positive_regularization_rate": rate_interval(positive).decimal_bounds(),
        })
    report = {
        "status": "PASS: exact constructions, general-bound examples, and positive regularizations",
        "proof": "continuation/009_memory_coefficient.md",
        "cycle_construction_checks": construction_checks, "certified_examples": examples,
        "scope": "The all-k asymptotic and bounds require the written proof. These exact rational flows and interval examples are reproducible checks, not finite sampling used to infer an infinite theorem.",
    }
    Path("results/memory_threshold.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
