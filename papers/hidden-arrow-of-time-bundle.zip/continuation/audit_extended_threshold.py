"""Independent exact orthant enumeration for Continuation 8's TV polytope."""

from fractions import Fraction as Q
from itertools import combinations, product
import json
from pathlib import Path

from extended_near_threshold import BALANCE, WEIGHTS, tv_vertices


def solve(matrix: list[list[Q]], rhs: list[Q]) -> list[Q] | None:
    a = [row[:] + [b] for row, b in zip(matrix, rhs)]
    for column in range(len(rhs)):
        pivot = next((i for i in range(column, len(rhs)) if a[i][column]), None)
        if pivot is None:
            return None
        a[column], a[pivot] = a[pivot], a[column]
        denominator = a[column][column]
        a[column] = [x / denominator for x in a[column]]
        for i in range(len(rhs)):
            if i != column:
                factor = a[i][column]
                a[i] = [x - factor*y for x, y in zip(a[i], a[column])]
    return [row[-1] for row in a]


def main() -> None:
    vertices, systems, feasible = set(), 0, 0
    for signs in product((-1, 1), repeat=6):
        for support in combinations(range(6), 3):
            matrix = [[Q(WEIGHTS[i]) for i in support],
                      [Q(BALANCE[i]) for i in support],
                      [Q(WEIGHTS[i] * signs[i]) for i in support]]
            solution = solve(matrix, [Q(0), Q(0), Q(2)])
            systems += 1
            if solution is None or any(x*signs[i] < 0 for x, i in zip(solution, support)):
                continue
            point = [Q(0)] * 6
            for i, x in zip(support, solution):
                point[i] = x
            assert sum(w*x for w, x in zip(WEIGHTS, point)) == 0
            assert sum(w*x for w, x in zip(BALANCE, point)) == 0
            assert sum(w*abs(x) for w, x in zip(WEIGHTS, point)) == 2
            vertices.add(tuple(point))
            feasible += 1
    assert vertices == set(tv_vertices())
    receipt = {"status": "PASS: independent orthant basic-feasible-solution enumeration agrees",
               "rational_linear_systems": systems, "feasible_systems_with_duplicates": feasible,
               "distinct_vertices": len(vertices),
               "scope": "This audits the previous cross-product enumeration using Gaussian elimination in all 64 orthants; the completeness argument is in Continuation 8."}
    Path("results/extended_threshold_vertex_audit.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
