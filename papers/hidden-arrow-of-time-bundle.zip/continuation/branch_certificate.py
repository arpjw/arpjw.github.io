"""Rigorous stationary-branch bounds for the hidden-arrow scalar problem.

All certificate decisions use outward-rounded integer intervals. Mathematical
prerequisites are derived in 001_unique_transition.md. Exploratory floats are
not used to accept or reject an interval.
"""

from __future__ import annotations

import json
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path

from intervals import I, SCALE, check_library, entropy_cost, ln2, log, sinh_cosh


def branch_coefficients(t: I) -> tuple[I, I]:
    s, c = sinh_cosh(t)
    return c / (t * s) + 1 / s.square(), c / s.square() + 1 / (t * s)


def stationarity(t: I, z: I) -> I:
    b, c = branch_coefficients(t)
    if z.lo == 0 and z.hi == 0:
        return 1 - b - c
    sz, cz = sinh_cosh(z)
    return sz / z - b * cz - c


@lru_cache(maxsize=32768)
def root_z(t: Q, tolerance: Q = Q(1, 10**26)) -> I:
    tt = I.point(t)
    b, c = branch_coefficients(tt)
    if (1 - b - c).lo <= 0:
        raise ValueError("t is not certified above the local threshold")
    low, high = Q(0), t
    while high - low > tolerance:
        mid = (low + high) / 2
        sz, cz = sinh_cosh(I.point(mid))
        value = sz / I.point(mid) - b * cz - c
        if value.lo > 0:
            low = mid
        elif value.hi < 0:
            high = mid
        else:
            raise ArithmeticError("precision insufficient for root sign")
    return I.hull(low, high)


def critical_t() -> I:
    low, high = Q(2), Q(3)
    while high - low > Q(1, 10**24):
        mid = (low + high) / 2
        s, c = sinh_cosh(I.point(mid))
        value = I.point(mid) * (c - 2) - s
        if value.lo > 0:
            high = mid
        elif value.hi < 0:
            low = mid
        else:
            raise ArithmeticError("critical root unresolved")
    return I.hull(low, high)


def branch_cost(t: I, z: I) -> I:
    s, c = sinh_cosh(t)
    sz, cz = sinh_cosh(z)
    denominator = c + cz
    return (t * s + z * sz) / denominator - log(denominator / 2)


def branch_objective(t: I, z: I) -> I:
    s, c = sinh_cosh(t)
    _, cz = sinh_cosh(z)
    return 2 * t * s / (c + cz)


def branch_derivative(t: I, z: I) -> I:
    s, c = sinh_cosh(t)
    sz, cz = sinh_cosh(z)
    b, _ = branch_coefficients(t)
    bprime = -1 / (t * s.square()) - c / (t.square() * s) - 2 * c / (s.square() * s)
    cprime = -(c.square() + 1) / (s.square() * s) - 1 / (t.square() * s) - c / (t * s.square())
    ht = -bprime * cz - cprime
    hz = (z * cz - sz) / z.square() - b * sz
    if hz.hi >= 0:
        raise ArithmeticError("root derivative sign not isolated")
    zp = -ht / hz
    denominator = (c + cz).square()
    rt = (t * (1 + c * cz) - z * s * sz) / denominator
    rz = (z * (1 + c * cz) - t * s * sz) / denominator
    return rt + rz * zp


def symmetric_objective(r: I) -> I:
    low, high = Q(0), Q(3)
    while high - low > Q(1, 10**23):
        mid = (low + high) / 2
        value = 2 * entropy_cost(I.point(mid)) - r
        if value.lo > 0:
            high = mid
        elif value.hi < 0:
            low = mid
        else:
            raise ArithmeticError("symmetric root sign unresolved")
    field = I.hull(low, high)
    s, c = sinh_cosh(field)
    return 4 * field * s / c


def root_cost_point(t: Q) -> I:
    return branch_cost(I.point(t), root_z(t))


def refined_cost_root(low: Q, high: Q, r: I, increasing: bool) -> I:
    while high - low > Q(1, 10**18):
        mid = (low + high) / 2
        value = root_cost_point(mid) - r
        if value.lo > 0:
            if increasing:
                high = mid
            else:
                low = mid
        elif value.hi < 0:
            if increasing:
                low = mid
            else:
                high = mid
        else:
            raise ArithmeticError("cost root sign unresolved")
    return I.hull(low, high)


def certify_budget(raw: str) -> dict:
    r = I.point(raw)
    tc = critical_t()
    start = Q(tc.hi, SCALE) + Q(1, 10**12)
    near_critical = branch_cost(I.hull(Q(tc.lo, SCALE), start), I.hull(0, root_z(start)))
    if near_critical.lo <= r.hi:
        raise AssertionError("near-critical segment not excluded")
    if entropy_cost(I.point(3)).lo <= r.hi:
        raise AssertionError("upper bound t < 6 not proved")

    stack = [(start, Q(6))]
    roots = []
    excluded = 1
    nodes = 0
    direct_exclusions = 0
    monotone_exclusions = 0
    symmetric = symmetric_objective(r)
    while stack:
        low, high = stack.pop()
        nodes += 1
        if nodes > 200000:
            raise RuntimeError("cover budget exceeded; no certificate issued")
        interval_t = I.hull(low, high)
        interval_z = I.hull(root_z(low), root_z(high))
        cost_range = branch_cost(interval_t, interval_z)
        if cost_range.hi < r.lo or cost_range.lo > r.hi:
            excluded += 1
            direct_exclusions += 1
            continue
        derivative = None
        try:
            derivative = branch_derivative(interval_t, interval_z)
        except ArithmeticError:
            pass
        if derivative is not None and (derivative.lo > 0 or derivative.hi < 0):
            left = root_cost_point(low) - r
            right = root_cost_point(high) - r
            if (left.lo > 0 and right.lo > 0) or (left.hi < 0 and right.hi < 0):
                excluded += 1
                monotone_exclusions += 1
                continue
            if (left.lo > 0 and right.hi < 0) or (left.hi < 0 and right.lo > 0):
                refined = refined_cost_root(low, high, r, derivative.lo > 0)
                tl, th = refined.fraction_bounds()
                zr = I.hull(root_z(tl), root_z(th))
                value = branch_objective(refined, zr)
                roots.append({
                    "t_interval": refined.decimal_bounds(),
                    "z_interval": zr.decimal_bounds(),
                    "objective": value.decimal_bounds(),
                    "gap_from_symmetric": (value - symmetric).decimal_bounds(),
                    "gap_sign": "positive" if value.lo > symmetric.hi else "negative" if value.hi < symmetric.lo else "unresolved",
                    "monotonicity_on_isolating_interval": "increasing" if derivative.lo > 0 else "decreasing",
                    "isolating_interval": [str(low), str(high)],
                    "derivative_bound": derivative.decimal_bounds(),
                })
                continue
        mid = (low + high) / 2
        stack.extend([(low, mid), (mid, high)])
    if any(root["gap_sign"] == "unresolved" for root in roots):
        raise AssertionError("objective ordering unresolved")
    return {
        "budget": raw,
        "budget_over_ln2": (r / ln2()).decimal_bounds(),
        "complete_stationary_cover": True,
        "cover_nodes": nodes,
        "excluded_leaves": excluded,
        "direct_exclusions": direct_exclusions,
        "monotone_exclusions": monotone_exclusions,
        "symmetric_objective": symmetric.decimal_bounds(),
        "unequal_stationary_points": sorted(roots, key=lambda root: root["t_interval"][0]),
        "global_symmetry_status": "suboptimal" if any(root["gap_sign"] == "positive" for root in roots) else "strictly optimal up to exchanging coordinates",
    }


def main() -> None:
    check_library()
    tc = critical_t()
    result = {
        "status": "partial rigorous branch checkpoint",
        "interval_digits": 40,
        "critical_t": tc.decimal_bounds(),
        "critical_budget": (2 * entropy_cost(tc / 2)).decimal_bounds(),
        "critical_budget_over_ln2": (2 * entropy_cost(tc / 2) / ln2()).decimal_bounds(),
        "points": [],
    }
    for raw in ("2.02", "2.03", "2.04", "2.05", "2.1", "2.123", "2.2", "2.5", "3", "4", "6"):
        t = Q(raw)
        z = root_z(t)
        cost = branch_cost(I.point(t), z)
        derivative = branch_derivative(I.point(t), z)
        result["points"].append({"t": raw, "z": z.decimal_bounds(), "cost": cost.decimal_bounds(), "cost_derivative": derivative.decimal_bounds()})
    path = Path("results/branch_checkpoint.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def certify_transition() -> None:
    check_library()
    lower = certify_budget("0.663391796")
    upper = certify_budget("0.663391798")
    if lower["global_symmetry_status"] != "strictly optimal up to exchanging coordinates":
        raise AssertionError("proposed lower bound failed")
    if upper["global_symmetry_status"] != "suboptimal":
        raise AssertionError("proposed upper bound failed")
    report = {
        "status": "PASS: exhaustive interval certificate at both budgets",
        "prerequisites": "The analytic stationary-curve classification and unique-global-transition proof in continuation/001_unique_transition.md.",
        "arithmetic": "Exact integer intervals, 40 decimal places, rigorous Taylor remainder bounds; no floating point acceptance decisions.",
        "transition_budget_nats": [lower["budget"], upper["budget"]],
        "transition_budget_over_ln2": [lower["budget_over_ln2"][0], upper["budget_over_ln2"][1]],
        "lower": lower,
        "upper": upper,
    }
    Path("results/transition_certificate.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


def certify_noise_threshold() -> None:
    check_library()
    s, c = sinh_cosh(critical_t() / 2)
    bias = s / c
    report = {
        "status": "rigorous interval enclosure using the critical-field root",
        "critical_bias": bias.decimal_bounds(),
        "critical_noise_floor": ((1 - bias) / 2).decimal_bounds(),
    }
    Path("results/noise_threshold.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    import sys
    if "--transition" in sys.argv:
        certify_transition()
    elif "--noise-threshold" in sys.argv:
        certify_noise_threshold()
    else:
        main()
