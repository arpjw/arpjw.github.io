"""Exact optimal-face certificates for the singular-threshold perturbations.

Complementary slackness gives allowed edge signs. Nonnegative circulations
cannot use edges outside directed cycles. Rational row rank then proves
uniqueness, or constancy of the context mass on a higher-dimensional face.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path

from memory_coefficient import check_certificate, complement, objective, representative, words
from memory_threshold import alternating_direction, long_run_direction
from parity_dual import conjectured, flip_ends


def rank(rows: list[list[Q]]) -> int:
    matrix = [row[:] for row in rows]
    if not matrix:
        return 0
    pivot = 0
    for col in range(len(matrix[0])):
        chosen = next((i for i in range(pivot,len(matrix)) if matrix[i][col]),None)
        if chosen is None:
            continue
        matrix[pivot],matrix[chosen] = matrix[chosen],matrix[pivot]
        divisor=matrix[pivot][col]
        matrix[pivot]=[x/divisor for x in matrix[pivot]]
        for i in range(pivot+1,len(matrix)):
            if matrix[i][col]:
                multiple=matrix[i][col]
                matrix[i]=[x-multiple*y for x,y in zip(matrix[i],matrix[pivot])]
        pivot+=1
        if pivot==len(matrix):
            break
    return pivot


def reaches(adjacency: dict[str,list[str]],start: str,target: str) -> bool:
    seen,stack={start},[start]
    while stack:
        node=stack.pop()
        if node==target:
            return True
        for nxt in adjacency[node]:
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return False


def construction_orbit(k: int) -> list[tuple[str,dict[str,Q]]]:
    w,v=alternating_direction(k) if k%2 else long_run_direction(k)
    result=[]
    for rev in (False,True):
        for comp in (False,True):
            for ends in (False,True):
                ww=w[::-1] if rev else w
                vv={e[::-1] if rev else e:x for e,x in v.items() if x}
                if comp:
                    ww=complement(ww)
                    vv={complement(e):x for e,x in vv.items()}
                if ends:
                    ww=flip_ends(ww)
                    vv={e:-x for e,x in vv.items()}
                result.append((ww,vv))
    return result


def face_certificate(record: dict) -> dict:
    alpha=check_certificate(record)
    k,w=record['k'],record['missing_word']
    ell=objective(w)
    potential={u:Q(x) for u,x in record['potential'].items()}
    mass,radius=Q(record['mass_multiplier']),Q(record['dual_radius'])
    adjacency=defaultdict(list)
    tight=[]
    for edge in words(k):
        residual=ell.get(edge,Q(0))+potential.get(edge[:-1],Q(0))-potential.get(edge[1:],Q(0))+mass
        if abs(residual)==radius:
            sign=1 if residual>0 else -1
            tail,head=(edge[:-1],edge[1:]) if sign>0 else (edge[1:],edge[:-1])
            tight.append((edge,sign,tail,head))
            adjacency[tail].append(head)
    allowed=[(e,s) for e,s,a,b in tight if reaches(adjacency,b,a)]
    nodes=sorted({x for e,_ in allowed for x in (e[:-1],e[1:])})
    matrix=[[Q(sign*((e[:-1]==u)-(e[1:]==u))) for e,sign in allowed] for u in nodes]
    matrix.extend([[Q(sign) for _,sign in allowed],[Q(1) for _ in allowed]])
    r=rank(matrix)
    u=w[1:-1]
    context=[Q(sign) if e[1:]==u else Q(0) for e,sign in allowed]
    assert rank(matrix+[context])==r
    direction={e:Q(x) for e,x in record['direction'].items()}
    context_value=sum(direction.get(a+u,Q(0)) for a in '01')
    expected_magnitude=1-alpha if k%2 else alpha-Q(1,2)
    assert abs(context_value)==expected_magnitude
    if k>=4:
        assert r==len(allowed)
        candidates=[v for word,v in construction_orbit(k) if word==w]
        assert candidates and all(v==direction for v in candidates)
    else:
        assert len(allowed)-r==1
        interiors=[v for word,v in construction_orbit(k) if word==w]
        assert interiors and all(sign*v.get(e,Q(0))>0 for e,sign in allowed for v in interiors)
    return {'k':k,'missing_word':w,'alpha':str(alpha),'tight_edges':len(tight),
            'cyclic_tight_edges':[{'word':e,'sign':s} for e,s in allowed],
            'affine_rank':r,'affine_nullity':len(allowed)-r,
            'context_mass_constant_on_face':str(context_value),
            'unique_direction':r==len(allowed)}


def main() -> None:
    saved=json.loads(Path('results/memory_coefficient.json').read_text())
    base_count=0
    for record in saved['certificates']:
        if record['k']<=9:
            check_certificate(record)
            base_count+=1
    assert base_count==494
    rows=[]
    for k in range(3,13):
        records=[r for r in saved['certificates'] if r['k']==k]
        if k<=9:
            expected={representative(w) for w in words(k+1) if w!=w[::-1]}
            assert len(records)==len(expected) and {r['missing_word'] for r in records}==expected
        assert max(Q(r['coefficient']) for r in records)==conjectured(k)
        maximizers=[r for r in records if Q(r['coefficient'])==conjectured(k)]
        expected_max={representative(w) for w,_ in construction_orbit(k)}
        assert {r['missing_word'] for r in maximizers}==expected_max
        rows.extend(face_certificate(r) for r in maximizers)
    report={'status':'PASS: exact complementary-slackness, cycle-support, and rational-rank checks',
            'base_certificates_rechecked':base_count,'faces':rows,
            'scope':'Finite proof for memories 3 through 9; later rows audit the all-memory equality proof. Memory 3 has a one-dimensional tie, with constant context mass. Every listed face at k>=4 is a singleton.'}
    Path('results/leading_face.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'base_certificates':base_count,'faces':len(rows),
                      'unique_faces':sum(r['unique_direction'] for r in rows),'nonunique_memory_three_faces':2},indent=2))


if __name__=='__main__':
    main()
