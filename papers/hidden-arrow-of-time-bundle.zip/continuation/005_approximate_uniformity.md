# Continuation 5: approximate fairness, stability, and a singular threshold shift

Status: written proofs, an explicit rational-flow construction, and separate numerical diagnostics. These results remain research drafts. No independent expert review or publication-priority claim is implied.

## 1. What changes when short windows are only nearly fair?

The exact-uniformity assumption is robust if a fixed positive transition-noise floor is retained. We give an explicit projection onto exactly uniform windows, preserving the floor, and a dimension-free continuity estimate for the irreversibility rate.

Without a prescribed floor, there are two distinct conclusions:

- At a fixed entropy budget strictly below the exact-uniformity threshold, sufficiently small window error still forces every transition away from zero. The infinite-divergence phenomenon cannot appear arbitrarily close to uniformity at that fixed budget.
- The threshold itself is sensitive: already for order three, a window error of size `tau` can lower a sufficient budget for infinite divergence by order `tau log(1/tau)`. We construct this explicitly. Thus a linear threshold-shift bound would be false.

These statements concern Markov order at most `k`. Approximate short-window fairness without a memory-order restriction is a different problem.

## 2. General stationary flows and reversal

Let `pi(s)` be the stationary law of a binary `k`-word, and let

\[
q(aub)=\pi(au)K(b\mid au),\qquad |u|=k-1.
\]

Stationarity means that the prefix and suffix `k`-word marginals of `q` agree. Write `U_k` for the uniform law and assume

\[
\operatorname{TV}(\pi,U_k)\le\tau.
\]

For a strictly positive kernel, the observable reversal rate is

\[
\sigma(P)=\sum_{a,u,b}q(aub)
 \log\frac{K(b\mid au)}{K(a\mid b u^R)}.
\]

Equivalently, `sigma = D(q || q^R) - D(pi || pi^R)`. For every `n>=k`,

\[
D(P_n\Vert P_n^R)=D(\pi\Vert\pi^R)+(n-k)\sigma(P).
\]

The initial divergence need not vanish when windows are merely approximately uniform. This boundary term is essential; the exact-uniformity formulas cannot be copied unchanged.

## 3. A floor-preserving projection

Set `N=2^(k-1)`. For each middle context `u`, write

\[
p_a=\pi(au),\quad p=p_0+p_1,\quad
m_a=K(0\mid au)-K(1\mid au),\quad
\theta_u=\frac{p_0m_0-p_1m_1}{p}.
\]

Define a new kernel

\[
K_Q(b\mid au)=\frac{1+(-1)^{a+b}\theta_u}{2}.
\]

It has exactly uniform `k`-windows. If every transition of `P` lies in `[epsilon,1-epsilon]`, put `b=1-2 epsilon`. Then `|m_a|<=b`, so `|theta_u|<=b` by convex averaging. The projection preserves the same noise floor. Positive stationary masses suffice for its definition; all processes considered here have them.

Let `delta_P=log2-h(P)`. Convexity of the binary deficit `d` gives

\[
p\,d(\theta_u)\le p_0d(m_0)+p_1d(m_1).
\]

Since `0<=d(theta_u)<=d(b)` and the `u`-marginal is within `tau` of uniform,

\[
\boxed{\delta_Q\le\delta_P+d(b)\tau.}
\]

This is one-sided, which is exactly what an upper-bound transfer needs.

For the kernel distance, set `w_u=p_0-p_1` and
`v_u=pi(u0)-pi(u1)=p_0m_0+p_1m_1`. A direct calculation gives

\[
\sum_{a=0}^1p_a\operatorname{TV}(K_P(\cdot\mid au),K_Q(\cdot\mid au))
=\frac{p_0p_1}{p}|m_0+m_1|
\le\frac{|v_u|+b|w_u|}{2}.
\]

Here `p(m_0+m_1)=2v_u-w_u(m_0-m_1)` and `p_0p_1<=p^2/4`. Summing and using
`sum_u |v_u|<=2 tau` and `sum_u |w_u|<=2 tau` yields

\[
E_\pi\operatorname{TV}(K_P,K_Q)\le(1+b)\tau,
\qquad \operatorname{TV}(q_P,q_Q)\le(2+b)\tau.
\]

Each row distance is at most `b`. Changing its weighting from `pi` to `U_k` therefore gives

\[
E_{U_k}\operatorname{TV}(K_P,K_Q)\le(1+2b)\tau.
\]

## 4. A dimension-free rate estimate

Let `L=log((1-epsilon)/epsilon)` and

\[
C_\epsilon=2(2+b)L+\frac{2(1+2b)}{\epsilon}.
\]

Then

\[
\boxed{|\sigma(P)-\sigma(Q)|\le C_\epsilon\tau.}
\]

To prove it, write `f_P(aub)=log K_P(b|au)-log K_P(a|b u^R)` and split

\[
\sigma(P)-\sigma(Q)=\sum(q_P-q_Q)f_P+
\sum q_Q(f_P-f_Q).
\]

The first term has absolute value at most `2L TV(q_P,q_Q)`, since `f_P` lies in `[-L,L]`. For the second, `log` is `1/epsilon`-Lipschitz on the kernel range. In a binary row the absolute probability change is the same for either outcome. Both forward and reverse context marginals under `q_Q` are uniform, so the second term is bounded by `2 E_U TV(K_P,K_Q)/epsilon`. Combining the preceding estimates proves the claim. The constant is intentionally coarse; its independence of `k` is the useful feature.

Let `M_{k,epsilon}(delta)` denote the exact-uniformity frontier from Continuation 4, and let `M^near_{k,epsilon}(delta,tau)` allow window error at most `tau`. Taking suprema gives

\[
\boxed{M_{k,\epsilon}(\delta)\le
M^{\rm near}_{k,\epsilon}(\delta,\tau)\le
M_{k,\epsilon}(\delta+d(b)\tau)+C_\epsilon\tau.}
\]

The upper bound uses the already proved exact frontier, including its noise cap and saturation convention. It is a comparison bound, not a claim that the projected source is extremal.

## 5. A noise floor forced by entropy and approximate uniformity

A prescribed noise floor is unnecessary if the entropy budget is kept a fixed distance below the singular threshold. Suppose `tau<1/N`,

\[
N(\delta+\tau\log2)<\log2,
\qquad B=a\bigl(N(\delta+\tau\log2)\bigr),
\]

and define

\[
\epsilon_* =\frac12\left(1-B-\frac{4N\tau}{1-N\tau}\right).
\]

If `epsilon_*>0`, then **every** feasible kernel has all transitions in `[epsilon_*,1-epsilon_*]`.

Indeed, apply the entropy projection with `b=1`. Since all its nonnegative context costs sum to at most `N(delta+tau log2)`, every `|theta_u|<=B`. The context mass satisfies `p>=1/N-tau`; also `|w_u|,|v_u|<=2 tau`. The identities

\[
m_0-\theta_u=(v_u-w_um_0)/p,
\qquad -m_1-\theta_u=-(v_u+w_um_1)/p
\]

give `|m_a-(-1)^a theta_u|<=4 tau/(1/N-tau)`. Hence `|m_a|<=1-2 epsilon_*`, as claimed.

For each fixed `delta<log2/N`, this sufficient condition holds for all sufficiently small `tau`, because `epsilon_*` tends to `(1-a(N delta))/2>0`. In particular, the nearby-class supremum is finite, and the bound from Section 4 applies using `epsilon_*`. No claim of a sharp robustness radius is made.

## 6. An explicit order-three singular construction

Now take `k=3`, `N=4`, and let `q_0` be the uniform-window flow with `theta_01=1` and all other biases zero, allowing zeros temporarily. Thus

\[
q_0(aub)=\frac{1+(-1)^{a+b}\mathbf 1_{u=01}}{16}.
\]

The two zero edges are `0011` and `1010`. Let `q_alt` be the stationary flow of the alternating orbit, with mass `1/2` on each of `0101` and `1010`. For `0<lambda<1`, set

\[
q_\lambda=(1-\lambda)q_0+\lambda q_{\rm alt}.
\]

Both component flows satisfy the conservation equations exactly, so their mixture is stationary. Its 3-word distribution is

\[
\pi_\lambda(010)=\pi_\lambda(101)=\frac{1+3\lambda}{8},
\qquad \pi_\lambda(s)=\frac{1-\lambda}{8}\quad\text{otherwise}.
\]

Therefore `TV(pi_lambda,U_3)=3 lambda/4`. The only nonfair kernel rows are

| Context | `K(0)` | `K(1)` |
|---|---:|---:|
| `001` | `1` | `0` |
| `101` | `4 lambda/(1+3 lambda)` | `(1-lambda)/(1+3 lambda)` |
| `010` | `(1-lambda)/(2(1+3 lambda))` | `(1+7 lambda)/(2(1+3 lambda))` |

The entropy deficit is exactly

\[
\delta_\lambda=\frac{1-\lambda}{8}\log2+
\frac{1+3\lambda}{8}
\left[d\!\left(\frac{5\lambda-1}{1+3\lambda}\right)
+d\!\left(\frac{4\lambda}{1+3\lambda}\right)\right].
\]

The edge `0011` still has zero mass, while its reverse `1100` has positive mass `(1-lambda)/16`. Thus reversal divergence is infinite. To return to the strictly positive class, mix with the fair i.i.d. flow:

\[
q_{\lambda,\eta}=(1-\eta)q_\lambda+\eta/16,
\qquad 0<\eta<1.
\]

The window error is `(1-eta)3 lambda/4`. Conditional entropy is concave in its joint flow, so `delta_{lambda,eta} <= (1-eta)delta_lambda <= delta_lambda`. Meanwhile

\[
\sigma(P_{\lambda,\eta})
=\frac{1-\lambda}{16}\log\frac1\eta+O_\lambda(1)
\longrightarrow\infty.
\]

To check the coefficient, use `sigma=D(q||q^R)-D(pi||pi^R)`: only the reverse pair containing `0011` has a vanishing edge, its nonvanishing partner tends to `(1-lambda)/16`, and all stationary masses stay positive. In fact `pi_lambda=pi_lambda^R`, so the boundary divergence vanishes for this particular example, although it does not vanish in general.

## 7. The threshold shift is at least of logarithmic order

Let `H_2` be binary entropy. The row `101` has small transition probability `t=4 lambda/(1+3 lambda)`. Rewriting its deficit gives

\[
\delta_\lambda=\frac{1+\lambda}{4}\log2
-\frac{1+3\lambda}{8}H_2(t)
+\frac{1+3\lambda}{8}d\!\left(\frac{4\lambda}{1+3\lambda}\right).
\]

Using `H_2(t)=t log(1/t)+t+O(t^2)` and `d(z)=z^2/2+O(z^4)` yields

\[
\frac{\log2}{4}-\delta_\lambda
=\frac\lambda2\log\frac1\lambda+
\lambda\left(\frac12-\frac54\log2\right)+O(\lambda^2).
\]

Writing `tau=3 lambda/4`, the leading term is

\[
\boxed{\frac{\log2}{4}-\delta_{4\tau/3}
=\frac23\tau\log\frac1\tau+O(\tau).}
\]

For every sufficiently small positive `tau`, the nearby class therefore has infinite supremum at a deficit strictly smaller than the exact-uniformity threshold. This is a constructive upper bound on the nearby singular threshold. This first construction is not optimal: [Continuation 6](006_sharp_threshold_shift.md) improves its leading coefficient from `2/3` to `3/4` and proves that the improved coefficient is sharp.

The exact logarithmic series verifier certifies a concrete instance at `lambda=1/1000`, hence `tau=3/4000`: the chosen entropy deficit is strictly below `log2/4`, yet the supremum is infinite. A sequence of strictly positive regularizations and its diagnostics are saved separately.

## 8. Audit and evidence boundaries

The all-noise allocation proof from Continuation 4 was reread. Its local two-pair variation is valid even at coexistence: each chosen pair has its own smooth strictly convex feasible family. Sorted pairing ensures the singly capped marginal comparison has `y>=x`; without that rearrangement the argument would not apply. No change to that theorem was needed.

The reversal boundary term in Section 2 is a new generalization, not a correction to the earlier exactly uniform formulas. An intermediate sign typo in the second row identity in Section 5 was corrected before this checkpoint; both saved identities are checked with exact fractions. The new script checks exact flow conservation, projection positivity, variation-distance inequalities, and a rational counterexample. Floating-point rate and entropy diagnostics remain explicitly separate from certified interval enclosures.
