"""Build the standalone finite-bias transition LaTeX source from its readable note."""
from pathlib import Path
import re

source = Path('continuation/019_finite_bias_transition.md').read_text()
body = source[source.index('## 1.'):]
preamble = r'''\documentclass[11pt]{article}
\usepackage[margin=0.80in]{geometry}
\usepackage{amsmath,amssymb,mathtools,booktabs}
\usepackage{xcolor,hyperref,microtype,fancyhdr,tikz}
\usetikzlibrary{arrows.meta}
\definecolor{ink}{HTML}{142B42}
\definecolor{accent}{HTML}{087F8C}
\definecolor{contrast}{HTML}{B35C36}
\hypersetup{colorlinks=true,linkcolor=accent,urlcolor=accent}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small\color{ink}The hidden arrow: a certified 40/60 transition}
\fancyhead[R]{\small Research draft}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}
\setlength{\parskip}{2pt}\setlength{\parindent}{0pt}
\title{\color{ink}\LARGE A certified 40/60 phase transition\\[8pt]
\large A concrete global crossing, unique branches, and a slope jump}
\author{Arya Somu}
\date{}
\begin{document}
\maketitle
\begin{center}\small
Continuation 19. A complete finite-bias interval certificate.\\
Global optimization throughout an explicit budget bracket.\\
Independent expert review and novelty verification remain open.
\end{center}
'''

def inline(line: str) -> str:
    line = re.sub(r'\*\*(.+?)\*\*',r'\\textbf{\1}',line)
    line = re.sub(r'`([^`]+)`',lambda m:' '.join((r'\path{'+token+'}') if '/' in token else (r'\texttt{\detokenize{'+token+'}}') for token in m.group(1).split()),line)
    return line

output=[]
items=False
for line in body.splitlines():
    if line.startswith('## ') or line.startswith('### '):
        if items:
            output.append(r'\end{itemize}'); items=False
        if line.startswith('### '):
            output.append(r'\subsection{'+line[4:]+'}')
        else:
            title=re.sub(r'^\d+\.\s*','',line[3:])
            output.append(r'\section{'+title+'}')
    elif line.startswith('Reproduce with `'):
        command=line.split('`')[1]
        output.append('Reproduce with:\n'+r'\begin{quote}\small\texttt{\detokenize{'+command+r'}}\end{quote}')
    elif line.startswith('- '):
        if not items:
            output.append(r'\begin{itemize}');items=True
        output.append(r'\item '+inline(line[2:]))
    elif not line.strip() and items:
        output.append(r'\end{itemize}');items=False
        output.append('')
    else:
        output.append(inline(line))
if items:
    output.append(r'\end{itemize}')
result=preamble+'\n'.join(output)+'\n\\end{document}\n'
result=result.replace('\n\n\\[','\n\\[')
Path('continuation/finite_bias_transition.tex').write_text(result)
