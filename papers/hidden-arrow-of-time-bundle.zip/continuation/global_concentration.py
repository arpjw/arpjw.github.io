"""Exact centered-ray identities supporting the written global allocation proof.

Finite interval examples corroborate strict convexity; they are not an
exhaustive certificate or a numerical solution of the matrix frontier.
"""
from __future__ import annotations

from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path

from intervals import I, log as ilog
from nonuniform_threshold import corner, cost, divergence, overlap, prod, zero_cost

Matrix = tuple[tuple[Q, ...], ...]


def independent(pi: tuple[Q, ...]) -> Matrix:
    return tuple(tuple(a*b for b in pi) for a in pi)


def shift(a: Matrix, v: Matrix, h: Q) -> Matrix:
    return tuple(tuple(x+h*y for x,y in zip(row,vr)) for row,vr in zip(a,v))


def transpose(a: Matrix) -> Matrix:
    return tuple(zip(*a))


def direction(m: int, amplitude: Q, antisymmetric: bool) -> Matrix:
    out = [[Q(0) for _ in range(m)] for _ in range(m)]
    if antisymmetric:
        for i,j in ((0,1),(1,2),(2,0)):
            out[i][j] = amplitude
            out[j][i] = -amplitude
    else:
        out[0][0] = out[1][1] = amplitude
        out[0][1] = out[1][0] = -amplitude
    return tuple(map(tuple,out))


def check_margins(pi: tuple[Q, ...], a: Matrix) -> None:
    assert all(x >= 0 for row in a for x in row)
    assert tuple(map(sum,a)) == pi
    assert tuple(map(sum,transpose(a))) == pi


def rays():
    laws = ((Q(1,10),Q(9,10)), (Q(1,3),Q(2,3)), (Q(1,2),Q(1,2)),
            (Q(1,10),Q(3,10),Q(3,5)), (Q(1,3),)*3,
            (Q(1,10),Q(1,5),Q(3,10),Q(2,5)))
    for pi in laws:
        base = independent(pi)
        small = min(x for row in base for x in row)
        for kind in ('pair','palindrome'):
            if kind == 'palindrome' and len(pi) == 2:
                continue
            v = direction(len(pi),small/4,kind == 'palindrome')
            for displaced in (False,True):
                middle = shift(base,direction(len(pi),small/8,False),Q(1)) if displaced else base
                yield pi,kind,'displaced' if displaced else 'independent',middle,v
    pi = (Q(1,10),Q(3,10),Q(3,5))
    middle = corner(pi,0,0,Q(0))
    offdiag = min(middle[i][j] for i in range(3) for j in range(3) if i != j)
    yield pi,'palindrome','zero_rare_diagonal',middle,direction(3,offdiag/4,True)


def ray_values(pi: tuple[Q, ...], kind: str, middle: Matrix, v: Matrix, h: Q) -> dict[str,I]:
    base = independent(pi)
    plus,minus = shift(middle,v,h),shift(middle,v,-h)
    check_margins(pi,plus);check_margins(pi,minus)
    ch, chh, chhh = I.point(0),Q(0),Q(0)
    if kind == 'pair':
        c = divergence(plus,base)+divergence(minus,base)
        objective = divergence(plus,minus)+divergence(minus,plus)
        for i,row in enumerate(v):
            for j,a in enumerate(row):
                if not a: continue
                x,y = plus[i][j],minus[i][j]
                ch += a*ilog(I.point(x/y))
                chh += a*a*(1/x+1/y)
                chhh += a**3*(-1/x**2+1/y**2)
    else:
        assert minus == transpose(plus)
        c = divergence(plus,base)
        objective = divergence(plus,minus)
        for i,row in enumerate(v):
            for j,a in enumerate(row):
                if not a: continue
                x = plus[i][j]
                ch += a*ilog(I.point(x/base[i][j]))
                chh += a*a/x
                chhh -= a**3/x**2
    overlap(objective,2*h*ch)
    cv = ch/(2*h)
    cvv = (h*chh-ch)/(4*h**3)
    cvvv = (h*h*chhh-3*h*chh+3*ch)/(8*h**5)
    v_squared = h*h
    first = 4*(1+v_squared*cvv/cv)
    second = 4*((cvv+v_squared*cvvv)*cv-v_squared*cvv.square())/(cv*cv*cv)
    ratio_numerator = c*first-objective
    assert cv.lo > 0 and second.lo > 0 and ratio_numerator.lo > 0
    return {'cost':c,'rate':objective,'second_derivative_wrt_cost':second,
            'rate_to_cost_increase_numerator':ratio_numerator}


def audit_rays() -> dict:
    rows=[]; coefficient_checks=0; boundary_checks=0
    for pi,kind,name,middle,v in rays():
        factor = Q(2) if kind == 'pair' else Q(1)
        for n in range(1,17):
            coefficient = factor*sum((v[i][j]**(2*n)/middle[i][j]**(2*n-1)
                                      for i in range(len(pi)) for j in range(len(pi)) if v[i][j]),Q(0))/(2*n*(2*n-1))
            assert coefficient > 0
            coefficient_checks += 1
        limit = min(middle[i][j]/abs(v[i][j]) for i in range(len(pi)) for j in range(len(pi)) if v[i][j])
        base=independent(pi)
        plus,minus=shift(middle,v,limit),shift(middle,v,-limit)
        boundary_cost=divergence(plus,base)+(divergence(minus,base) if kind=='pair' else I.point(0))
        threshold=zero_cost(pi[0],pi[0] if kind=='pair' else pi[1])
        assert boundary_cost.lo > threshold.hi
        boundary_checks+=1
        for h in (Q(1,8),Q(1,4),Q(1,2),Q(3,4)):
            values=ray_values(pi,kind,middle,v,h)
            rows.append({'pi':list(map(str,pi)),'kind':kind,'center':name,'h':str(h),
                         **{key:value.decimal_bounds() for key,value in values.items()}})
    return {'positive_even_coefficients':coefficient_checks,'boundary_cost_comparisons':boundary_checks,
            'interval_ray_cases':len(rows),'rows':rows}


def audit_flows() -> dict:
    cases=[]
    for pi,kind,name,middle,v in rays():
        if name != 'independent': continue
        for k in (3,4):
            base=independent(pi)
            plus,minus=shift(middle,v,Q(1,2)),shift(middle,v,Q(-1,2))
            u=(1,)+(0,)*(k-2) if kind=='pair' else (0,)*(k-1)
            reverse=u[::-1]
            weight=prod(pi[a] for a in u)
            def block(word):
                context=word[1:-1]
                if context==u: return plus
                if kind=='pair' and context==reverse: return transpose(minus)
                return base
            flow={w:prod(pi[a] for a in w[1:-1])*block(w)[w[0]][w[-1]]
                  for w in product(range(len(pi)),repeat=k+1)}
            for w in product(range(len(pi)),repeat=k):
                assert sum(flow[w+(a,)] for a in range(len(pi)))==prod(pi[a] for a in w)
                assert sum(flow[(a,)+w] for a in range(len(pi)))==prod(pi[a] for a in w)
            direct_cost=sum((mass*ilog(I.point(mass/prod(pi[a] for a in w))) for w,mass in flow.items()),I.point(0))
            direct_rate=sum(((mass-flow[w[::-1]])*ilog(I.point(mass/flow[w[::-1]]))
                             for w,mass in flow.items() if w<w[::-1]),I.point(0))
            expected=ray_values(pi,kind,middle,v,Q(1,2))
            overlap(direct_cost,weight*expected['cost'])
            overlap(direct_rate,weight*expected['rate'])
            cases.append({'pi':list(map(str,pi)),'kind':kind,'memory':k,'weight':str(weight),'words':len(flow)})
    return {'stationary_flow_cases':len(cases),'word_probability_checks':sum(c['words'] for c in cases),'rows':cases}


def main() -> None:
    receipt={'status':'exact rational coefficients and stationary marginals, interval identity/derivative checks; global theorem is the written analytic proof',
             'rays':audit_rays(),'flows':audit_flows()}
    Path('results/global_concentration.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'positive_even_coefficients':receipt['rays']['positive_even_coefficients'],
                      'boundary_cost_comparisons':receipt['rays']['boundary_cost_comparisons'],
                      'interval_ray_cases':receipt['rays']['interval_ray_cases'],
                      'stationary_flow_cases':receipt['flows']['stationary_flow_cases'],
                      'word_probability_checks':receipt['flows']['word_probability_checks']},indent=2))


if __name__=='__main__':
    main()
