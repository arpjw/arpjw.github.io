"""Interval perturbation coefficients and separate Decimal coexistence diagnostics.

The written compactness/implicit-function proof supplies persistence. These
intervals certify its nondegeneracy, orientation selection, and shift constants.
No explicit range of nonzero bias is certified by this script.
"""
from __future__ import annotations

from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

from intervals import I, log as ilog
from nonuniform_threshold import overlap


def atanh(z: I) -> I:
    return ilog((1+z)/(1-z))/2


def perturbation(z: I) -> I:
    return (1-z)*atanh(z)-z/(1+z)


def perturbation_derivative(z: I) -> I:
    return -atanh(z)+z/((1+z)*(1+z))


def value_variation(a: I,b: I,lam: I) -> I:
    return (a+b)*(perturbation_derivative(b)-perturbation_derivative(-a))-lam*(perturbation(-a)+perturbation(b))


def constrained_curvature(a: I,b: I,lam: I) -> I:
    x,y=-a,b
    fx,fy=atanh(x),atanh(y)
    ax,ay=1/(1-x.square()),1/(1-y.square())
    bx,by=2*x*ax.square(),2*y*ay.square()
    gap=y-x
    jxx,jyy,jxy=2*ax-gap*bx,2*ay+gap*by,-ax-ay
    return fy.square()*(jxx-lam*ax)-2*fx*fy*jxy+fx.square()*(jyy-lam*ay)


def interval_certificate() -> dict:
    source_path=Path('results/jump_certificate.json')
    source=json.loads(source_path.read_text())
    box=lambda key:I.hull(*source[key])
    a,b,h=(box(key) for key in ('unequal_larger_bias_magnitude','unequal_smaller_bias_magnitude','symmetric_bias_magnitude'))
    la,ls=box('right_envelope_derivative'),box('left_envelope_derivative')
    ea,eb,es=value_variation(a,b,la),value_variation(b,a,la),value_variation(h,h,ls)
    qa,qs=constrained_curvature(a,b,la),constrained_curvature(h,h,ls)
    beta=-(ea-es)/(la-ls)
    assert qa.hi < I.point('-.08').lo
    assert qs.hi < I.point('-.015').lo
    assert (ea-eb).lo > I.point('99').hi
    assert (la-ls).lo > I.point('1.15').hi
    assert beta.lo > I.point('-78.212').hi
    assert beta.hi < I.point('-78.200').lo
    identities=0
    for z in (Q(-9,10),Q(-3,4),Q(-1,3),Q(0),Q(1,5),Q(2,3),Q(9,10)):
        a0,d0=(1+z)/4,(1-z)/4
        from_entrywise_expansion=2*d0*ilog(I.point(a0/d0))+Q(1)/(4*a0)-1
        overlap(from_entrywise_expansion,perturbation(I.point(z)))
        assert (1-z)/(1-z*z)-1/(1+z)**2 == z/(1+z)**2
        identities+=2
    return {'status':'PASS: perturbation signs and shift coefficient certified from earlier optimizer enclosures',
            'prerequisite_hashes':{str(path):hashlib.sha256(path.read_bytes()).hexdigest()
                                   for path in (source_path,Path('results/transition_certificate.json'))},
            'larger_left_variation':ea.decimal_bounds(),'larger_right_variation':eb.decimal_bounds(),
            'central_variation':es.decimal_bounds(),'orientation_advantage_coefficient':(ea-eb).decimal_bounds(),
            'unequal_constrained_curvature':qa.decimal_bounds(),'central_constrained_curvature':qs.decimal_bounds(),
            'crossing_slope_difference':(la-ls).decimal_bounds(),'transition_shift_coefficient':beta.decimal_bounds(),
            'coarse_shift_enclosure':['-78.212','-78.200'],'perturbation_identity_checks':identities}


def linear_solve(matrix: list[list[D]],rhs: list[D]) -> list[D]:
    n=len(rhs)
    a=[row[:]+[b] for row,b in zip(matrix,rhs)]
    for col in range(n):
        pivot=max(range(col,n),key=lambda row:abs(a[row][col]))
        a[col],a[pivot]=a[pivot],a[col]
        divisor=a[col][col]
        assert divisor
        a[col]=[x/divisor for x in a[col]]
        for row in range(n):
            if row==col:continue
            factor=a[row][col]
            a[row]=[x-factor*y for x,y in zip(a[row],a[col])]
    return [row[-1] for row in a]


def quantities(s: D,z: D) -> tuple[D,D,D,D]:
    p,q=(1-s)/2,(1+s)/2
    r=p*q
    x,zoff,y=p*p+r*z,r*(1-z),q*q+r*z
    assert min(x,zoff,y)>0
    f=x*(x/(p*p)).ln()+2*zoff*(zoff/r).ln()+y*(y/(q*q)).ln()
    fp=r*(x.ln()+y.ln()-2*zoff.ln())
    fpp=r*r*(1/x+2/zoff+1/y)
    fppp=r**3*(-1/x**2+2/zoff**2-1/y**2)
    return f,fp,fpp,fppp


def pair(s: D,x: D,y: D) -> tuple[D,D,D,D,D,D,D,D,D]:
    f,fx,ax,bx=quantities(s,x)
    g,fy,ay,by=quantities(s,y)
    distance,gap=y-x,fy-fx
    j=distance*gap
    jx,jy=-gap-distance*ax,gap+distance*ay
    jxx,jyy,jxy=2*ax-distance*bx,2*ay+distance*by,-ax-ay
    k=jx*fy-jy*fx
    kx,ky=jxx*fy-jxy*fx-jy*ax,jxy*fy+jx*ay-jyy*fx
    return f+g,j,k,fx,fy,jx,jy,kx,ky


def coexistence(s: D) -> tuple[list[D],D,int]:
    z=list(map(D,('-.9063253','.5489586','-.765458863','.765458863','.663391797')))
    zero=D(0)
    for iteration in range(35):
        a,b,c,d,budget=z
        ca,ja,ka,fa,fb,jax,jay,kax,kay=pair(s,a,b)
        cc,jc,kc,fc,fd,jcx,jcy,kcx,kcy=pair(s,c,d)
        residual=[ca-budget,ka,cc-budget,kc,ja-jc]
        error=max(map(abs,residual))
        if error<D('1e-65'):return z,error,iteration
        jac=[[fa,fb,zero,zero,-D(1)],[kax,kay,zero,zero,zero],
             [zero,zero,fc,fd,-D(1)],[zero,zero,kcx,kcy,zero],
             [jax,jay,-jcx,-jcy,zero]]
        update=linear_solve(jac,[-x for x in residual])
        z=[x+dx for x,dx in zip(z,update)]
        assert z[0]<z[2]<0<z[1]<z[3]<1
    raise AssertionError('Decimal coexistence diagnostic failed to converge')


def decimal_diagnostics() -> dict:
    with localcontext() as ctx:
        ctx.prec=85
        fair,fair_error,fair_iterations=coexistence(D(0))
        rows=[]
        failed=[]
        for s in (D('.001'),D('.0001'),D('.00001'),D('.000001')):
            try:
                z,error,iterations=coexistence(s)
            except AssertionError:
                failed.append({'bias_s':str(s),'status':'undamped Newton from the fair seed failed; no mathematical conclusion'})
                continue
            rows.append({'bias_s':str(s),'p':str((1-s)/2),'strong_left_z':str(z[0]),'strong_right_z':str(z[1]),
                         'mild_left_z':str(z[2]),'mild_right_z':str(z[3]),'budget':str(z[4]),
                         'shift_over_s_squared':str((z[4]-fair[4])/(s*s)),
                         'max_equation_residual':str(error),'newton_iterations':iterations})
        return {'status':'85-digit Decimal solutions of coexistence equations, not global certificates or an explicit validity range',
                'fair_budget':str(fair[4]),'fair_max_equation_residual':str(fair_error),
                'fair_newton_iterations':fair_iterations,'rows':rows,'failed_attempts':failed}


def main() -> None:
    certificate=interval_certificate()
    diagnostics=decimal_diagnostics()
    receipt={'certificate':certificate,'separate_decimal_diagnostics':diagnostics,
             'scope':'analytic persistence for all sufficiently small positive biases; no numerical bias cutoff; p=2/5 remains unproved'}
    Path('results/biased_transition_persistence.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':certificate['status'],'transition_shift_coefficient':certificate['transition_shift_coefficient'],
                      'orientation_advantage_coefficient':certificate['orientation_advantage_coefficient'],
                      'identity_checks':certificate['perturbation_identity_checks'],
                      'decimal_bias_cases':len(diagnostics['rows']),'failed_numerical_attempts':diagnostics['failed_attempts']},indent=2))


if __name__=='__main__':
    main()
