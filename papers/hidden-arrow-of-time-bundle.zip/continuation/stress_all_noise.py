"""Deterministic falsification attempts for the all-noise saturation theorem.

These use floating point and are diagnostics, not the proof. The theorem is in
004_all_noise_frontier.md and rests on rearrangement and local variation.
"""

from __future__ import annotations

import json
from math import atanh, fsum
from pathlib import Path
import random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hidden_arrow import deficit
from explore_noise import capped_pair


def numerical_saturated_value(b: float, total_cost: float, pairs: int) -> float:
    capacity = 2 * deficit(b)
    total_cost = min(total_cost, pairs * capacity)
    full = min(pairs, int(total_cost / capacity))
    remainder = max(0.0, total_cost - full * capacity)
    value = 4 * full * b * atanh(b)
    if remainder > 1e-15:
        value += capped_pair(remainder, b, grid=160)[0]
    return value


def main() -> None:
    random_source = random.Random(716031)
    trials = 1500
    worst = None
    for index in range(trials):
        b = random_source.choice((0.2, 0.5, 0.75, 0.8, 0.9, 0.95, 0.99, 0.999))
        pairs = random_source.choice((2, 3, 5))
        values = []
        for _ in range(2 * pairs):
            choice = random_source.random()
            value = b if choice < 0.3 else 0.0 if choice < 0.4 else b * random_source.random()
            values.append(value)
        # Sorting strengthens the competing construction through the proved
        # rearrangement inequality instead of testing easy random pairings.
        values.sort(reverse=True)
        cost = fsum(deficit(value) for value in values)
        competitor = fsum((x + y) * (atanh(x) + atanh(y)) for x, y in zip(values[::2], values[1::2]))
        predicted = numerical_saturated_value(b, cost, pairs)
        gap = predicted - competitor
        if worst is None or gap < worst["gap"]:
            worst = {"trial": index, "cap": b, "pairs": pairs, "magnitudes": values, "cost": cost, "competitor": competitor, "predicted": predicted, "gap": gap}
        if gap < -1e-9:
            raise AssertionError(f"Numerical counterexample or optimization error: {worst}")
    report = {
        "status": "PASS: no numerical counterexample in the stated deterministic sample",
        "seed": 716031,
        "trials": trials,
        "caps": [0.2, 0.5, 0.75, 0.8, 0.9, 0.95, 0.99, 0.999],
        "pair_counts": [2, 3, 5],
        "tolerance": 1e-9,
        "worst_gap": worst,
        "scope": "Floating-point falsification attempts only. They supplement, and do not prove, the analytic saturation theorem.",
    }
    Path("results/all_noise_stress.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
