"""Explore and certify the next regime of the order-three singular threshold."""

from __future__ import annotations

from fractions import Fraction as Q
from itertools import combinations
import json
from math import log
from pathlib import Path
import random

from intervals import I, log as ilog, ln2
from exact_near_threshold import interval_certificate, smooth_gradients
from approximate_uniformity import (
    Flow, deficit_interval, fair_flow, marginals, mix, rate_interval, tv, words,
)


WEIGHTS = (1, 2, 2, 1, 1, 1)
BALANCE = (0, -1, 1, 1, -1, 0)
TAU_START = Q(1, 10000)
TAU_END = Q(1, 16)
C_DIRECTION = (Q(0), -Q(1, 6), Q(1, 2), -Q(2, 3), Q(0), Q(0))


def tv_vertices() -> list[tuple[Q, ...]]:
    """Vertices of the stationary marginal TV unit ball, in e,a,b,c,d,f order.

    Two independent homogeneous constraints are imposed on a weighted l1
    ball. A vertex direction has at most three nonzero coordinates. All
    circuits of those two constraints are enumerated using exact arithmetic.
    """
    vertices = set()
    for support in combinations(range(6), 3):
        i, j, k = support
        raw = [Q(0)] * 6
        raw[i] = Q(WEIGHTS[j] * BALANCE[k] - WEIGHTS[k] * BALANCE[j])
        raw[j] = Q(WEIGHTS[k] * BALANCE[i] - WEIGHTS[i] * BALANCE[k])
        raw[k] = Q(WEIGHTS[i] * BALANCE[j] - WEIGHTS[j] * BALANCE[i])
        norm = sum(w * abs(v) for w, v in zip(WEIGHTS, raw)) / 2
        if norm:
            for sign in (-1, 1):
                point = tuple(sign * v / norm for v in raw)
                assert sum(w * v for w, v in zip(WEIGHTS, point)) == 0
                assert sum(w * v for w, v in zip(BALANCE, point)) == 0
                vertices.add(point)
    return sorted(vertices)


def c_trial(tau: float) -> tuple[float, ...]:
    return (0.125, 0.125 - tau / 6, 0.125 + tau / 2,
            0.125 - 2 * tau / 3, 0.125, 0.125)


def c_value_gradient(point: tuple[float, ...]) -> tuple[float, tuple[float, ...]]:
    e, a, b, c, d, f = point
    z, w, u, p = b - a, e + a, b + f, a + d
    xlogx = lambda x: x * log(x) if x else 0.0
    value = (log(2) + xlogx(e) + 2 * xlogx(a) + xlogx(c)
             + xlogx(b) + xlogx(f) + xlogx(z)
             - xlogx(w) - xlogx(u) - xlogx(p))
    ga = 2 * log(a) + log(b) - log(w) - log(u) - log(p)
    gz = log(b) + log(z) - log(u) - log(p)
    gradient = (log(e / w), ga - gz, gz, log(c / p), 0.0, log(f / u))
    return value, gradient


def dot(left, right):
    return sum((a * b for a, b in zip(left, right)), I.point(0))


def xlogx(x: I) -> I:
    return x * ilog(x)


def b_value(tau: I, transverse: I) -> I:
    e = I.point(Q(1, 8)) + transverse
    a = I.point(Q(1, 8)) + tau / 4 - transverse / 2
    c = I.point(Q(1, 8)) - tau / 2
    z, p, w = a - c, a + c, e + a
    return (ln2() + xlogx(z) + 2 * xlogx(a) + 2 * xlogx(c)
            + 2 * xlogx(e) - 2 * xlogx(w) - xlogx(p))


def c_interval(tau: I) -> tuple[I, tuple[I, ...], tuple[I, ...]]:
    """Return trial value, full marginal gradient, and tau times its derivative."""
    e = I.point(Q(1, 8))
    a, b, c = e - tau / 6, e + tau / 2, e - 2 * tau / 3
    z, w, u, p = 2 * tau / 3, e + a, b + e, a + e
    le, la, lb, lc, lz, lw, lu, lp = map(ilog, (e, a, b, c, z, w, u, p))
    value = (ln2() + 2 * e * le + 2 * a * la + c * lc + b * lb
             + z * lz - w * lw - u * lu - p * lp)
    gradient = (le - lw, 2 * la - lz - lw, lb + lz - lu - lp,
                lc - lp, I.point(0), le - lu)
    scaled_derivative = (
        tau / (6 * w),
        -tau / (3 * a) + tau / (6 * w) - 1,
        tau / (2 * b) + 1 - tau / (2 * u) + tau / (6 * p),
        -2 * tau / (3 * c) + tau / (6 * p),
        I.point(0),
        -tau / (2 * u),
    )
    return value, gradient, scaled_derivative


def c_dominance_certificate() -> dict:
    """Mean-value enclosures cover every tau, and every TV-polytope vertex.

    D_v = C_trial - V + tau * grad(C_trial) dot (v-v_trial).
    D_v' = grad(C_trial) dot v - V' + tau*grad' dot (v-v_trial).
    All D_v > 0 imply that every type-C boundary has deficit greater than V.
    """
    vertices = tv_vertices()
    stack = [(TAU_START, TAU_END)]
    leaves = []
    processed = 0
    while stack:
        low, high = stack.pop()
        middle, radius = (low + high) / 2, (high - low) / 2
        value, grad, _ = c_interval(I.point(middle))
        v_value = b_value(I.point(middle), I.point(0))
        _, grad_box, scaled_prime = c_interval(I.hull(low, high))
        rb, _ = smooth_gradients(I.hull(low, high), "B")
        v_prime = 3 * (ilog(I.hull(3 * low / 4, 3 * high / 4)) + rb) / 4
        lower_bounds = []
        for vertex in vertices:
            delta = tuple(v - c for v, c in zip(vertex, C_DIRECTION))
            at_middle = value - v_value + middle * dot(grad, delta)
            derivative = dot(grad_box, vertex) - v_prime + dot(scaled_prime, delta)
            max_abs = I(0, max(abs(derivative.lo), abs(derivative.hi)))
            enclosure = at_middle - radius * max_abs
            lower_bounds.append(enclosure.lo)
        processed += 1
        if min(lower_bounds) > 0:
            leaves.append({
                "tau": [str(low), str(high)],
                "all_vertex_dominance_lower_bound": I(min(lower_bounds), min(lower_bounds)).decimal_bounds()[0],
            })
        else:
            assert processed < 20000, "unexpectedly expensive or failed certificate"
            assert high - low > Q(1, 10**14), "unresolved dominance interval"
            stack.extend(((middle, high), (low, middle)))
    leaves.sort(key=lambda item: Q(item["tau"][0]))
    assert Q(leaves[0]["tau"][0]) == TAU_START
    assert Q(leaves[-1]["tau"][1]) == TAU_END
    for left, right in zip(leaves, leaves[1:]):
        assert left["tau"][1] == right["tau"][0]
    return {
        "domain": [str(TAU_START), str(TAU_END)],
        "vertices": [[str(v) for v in vertex] for vertex in vertices],
        "vertex_count": len(vertices),
        "processed_intervals": processed,
        "leaf_count": len(leaves),
        "leaves": leaves,
        "method": "Exact outward-rounded mean-value enclosures, covering the full closed interval. Every one of the 34 supporting-plane bounds is strictly above V.",
    }


def transition_polynomial(tau: Q) -> Q:
    return 12 * tau * (1 + 2 * tau)**2 * (1 + tau)**2 + tau - 1


def bisect_increasing(function, low: Q, high: Q, steps: int = 100) -> tuple[Q, Q]:
    assert function(low) < 0 < function(high)
    for _ in range(steps):
        middle = (low + high) / 2
        if function(middle) < 0:
            low = middle
        else:
            high = middle
    assert function(low) < 0 < function(high)
    return low, high


def edge_polynomial(tau: Q, transverse: Q) -> Q:
    e, a, c = Q(1, 8) + transverse, Q(1, 8) + tau / 4 - transverse / 2, Q(1, 8) - tau / 2
    return e**4 * (a + c) - a*a * (e + a)**2 * (a - c)


def b_flow(tau: Q, transverse: Q) -> Flow:
    assert 0 < tau <= TAU_END and 0 <= transverse <= tau / 2
    a, c, e = Q(1, 8) + tau / 4 - transverse / 2, Q(1, 8) - tau / 2, Q(1, 8) + transverse
    pi = {"000": e, "001": a, "010": c, "011": a, "100": a, "101": c, "110": a, "111": e}
    flow = {word: pi[word[:-1]] * pi[word[1:]] / (pi["0" + word[1:-1]] + pi["1" + word[1:-1]]) for word in words(4)}
    flow.update({"0010": c, "0011": a - c, "1010": Q(0), "1011": c})
    assert marginals(flow) == pi
    assert tv(pi, {word: Q(1, 8) for word in pi}) == tau
    assert sum(value == 0 for value in flow.values()) == 1
    return flow


def c_flow(tau: Q) -> Flow:
    e = f = d = Q(1, 8)
    a, b, c = e - tau / 6, e + tau / 2, e - 2 * tau / 3
    pi = {"000": e, "001": a, "010": c, "011": b, "100": a, "101": d, "110": b, "111": f}
    flow = {word: pi[word[:-1]] * pi[word[1:]] / (pi["0" + word[1:-1]] + pi["1" + word[1:-1]]) for word in words(4)}
    flow.update({"0010": Q(0), "0011": a, "1010": c, "1011": b-a})
    assert marginals(flow) == pi
    assert tv(pi, {word: Q(1, 8) for word in pi}) == tau
    return flow


def analytic_sign_receipts() -> dict:
    """Rational endpoint bounds for the analytic A/B gradient arguments."""
    t = TAU_END
    a_margin_1 = 1 / (12 * t)  # (1+t)/(12*t*(1-t)^2) is larger.
    a_margin_2 = (1 - 2*t)**4 * (1 - t)**2 / (3*t*(1+t))
    uv_ratio = 4 * (1-t*t) * (1-4*t)**4 / ((1-2*t)**4 * (1+2*t)**2)
    assert a_margin_1 > 1 and a_margin_2 > 1 and uv_ratio > 1
    b_z_upper = (ilog(I.point(Q(3, 64))) + 2 * ilog(I.point(Q(9, 64))) / 3
                 - 4 * ilog(I.point(Q(3, 32))) / 3 - ilog(I.point(Q(1, 4))) / 3)
    assert b_z_upper.hi < 0
    return {
        "A_exp_E_minus_z_lower": str(a_margin_1),
        "A_exp_twice_minus_z_over_2_minus_E_lower": str(a_margin_2),
        "U_minus_V_derivative_log_ratio_lower": str(uv_ratio),
        "B_exp_minus_z_minus_E_lower": "3",
        "B_edge_endpoint_exp_twice_derivative_lower": "112/81",
        "B_z_derivative_upper_on_entire_edge_region": b_z_upper.decimal_bounds()[1],
    }


def main() -> None:
    old_tail = interval_certificate()
    signs = analytic_sign_receipts()
    root_low, root_high = bisect_increasing(transition_polynomial, Q(1, 20), Q(1, 16))
    root_box = I.hull(root_low, root_high)
    a, e, p, w, z = (I.point(Q(1, 8)) + root_box / 4, I.point(Q(1, 8)),
                     (1 - root_box) / 4, (1 + root_box) / 4, 3 * root_box / 4)
    mixed = -1 / (4*a) - 1 / (4*w) - 1 / (8*p) - 3 / (8*z)
    transverse_second = 2/e + 1/(2*a) - 1/(2*w) - 1/(4*p) + 1/(4*z)
    assert mixed.hi < 0 and transverse_second.lo > 0
    transition = {
        "polynomial": "12*tau*(1+2*tau)^2*(1+tau)^2 + tau - 1",
        "rational_bracket": [str(root_low), str(root_high)],
        "decimal_bracket": root_box.decimal_bounds(),
        "exact_endpoint_signs": [str(transition_polynomial(root_low)), str(transition_polynomial(root_high))],
        "right_derivative_of_optimal_E": (-mixed / transverse_second).decimal_bounds(),
        "downward_jump_in_threshold_second_derivative": (mixed.square() / transverse_second).decimal_bounds(),
    }
    dominance = c_dominance_certificate()
    examples = []
    for tau in (Q(1, 100), Q(1, 20), Q(57, 1000), Q(3, 50), Q(1, 16)):
        if transition_polynomial(tau) <= 0:
            low = high = Q(0)
        else:
            low, high = bisect_increasing(lambda x: edge_polynomial(tau, x), Q(0), tau / 2)
        bound = b_value(I.point(tau), I.hull(low, high))
        midpoint = (low + high) / 2
        flow = b_flow(tau, midpoint)
        exact_flow_value = deficit_interval(flow)
        at_midpoint = b_value(I.point(tau), I.point(midpoint))
        assert max(at_midpoint.lo, exact_flow_value.lo) <= min(at_midpoint.hi, exact_flow_value.hi)
        c_from_flow = deficit_interval(c_flow(tau))
        c_from_formula, _, _ = c_interval(I.point(tau))
        assert max(c_from_flow.lo, c_from_formula.lo) <= min(c_from_flow.hi, c_from_formula.hi)
        improvement = b_value(I.point(tau), I.point(0)) - bound
        if low > 0:
            assert improvement.lo > 0
        regularized = mix(flow, fair_flow(3), Q(1, 10**16))
        regularized_value = deficit_interval(regularized)
        assert regularized_value.hi < bound.lo
        examples.append({
            "tau": str(tau), "optimal_E_bracket": I.hull(low, high).decimal_bounds(),
            "threshold_bracket": bound.decimal_bounds(),
            "improvement_over_vertex_V": improvement.decimal_bounds(),
            "rational_midpoint_flow_formula_check": "PASS",
            "C_trial_flow_formula_check": "PASS",
            "positive_regularization_weight": "1/10000000000000000",
            "positive_regularization_deficit": regularized_value.decimal_bounds(),
            "positive_regularization_rate": rate_interval(regularized).decimal_bounds(),
        })
    rng = random.Random(816070)
    gradient_errors = []
    for _ in range(80):
        tau = 0.0001 + 0.0624 * rng.random()
        point = c_trial(tau)
        _, gradient = c_value_gradient(point)
        vertex = rng.choice(tv_vertices())
        step = 1e-7
        plus = tuple(p + step * float(v) for p, v in zip(point, vertex))
        minus = tuple(p - step * float(v) for p, v in zip(point, vertex))
        derivative = (c_value_gradient(plus)[0] - c_value_gradient(minus)[0]) / (2*step)
        predicted = sum(g * float(v) for g, v in zip(gradient, vertex))
        gradient_errors.append(abs(derivative - predicted))
    assert max(gradient_errors) < 2e-7
    report = {
        "status": "PASS: exact global threshold and unique critical boundary source for every 0 < tau <= 1/16",
        "proof": "continuation/008_extended_threshold.md",
        "near_zero_certificate_reused": old_tail,
        "analytic_sign_receipts": signs,
        "transition": transition,
        "C_global_dominance_certificate": dominance,
        "certified_examples": examples,
        "floating_point_diagnostics": {"seed": 816070, "stationary_direction_gradient_checks": len(gradient_errors), "maximum_error": max(gradient_errors)},
        "scope": "The phase structure and uniqueness have written proofs. Only type-C exclusion uses a finite interval cover. Rational root brackets are exact. Numerical finite differences are diagnostics. No independent expert review or novelty claim.",
    }
    Path("results/extended_near_threshold.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "C_global_dominance_certificate"}, indent=2))
    print("C certificate:", dominance["leaf_count"], "leaves;", dominance["processed_intervals"], "processed intervals")


def explore() -> None:
    from exact_near_threshold import reduced_deficit
    vertices = tv_vertices()
    print('stationary TV vertices:', len(vertices))
    direction = (Q(0), -Q(1, 6), Q(1, 2), -Q(2, 3), Q(0), Q(0))
    assert direction in vertices
    for tau in (0.0001, 0.001, 0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.055, 0.06):
        value, gradient = c_value_gradient(c_trial(tau))
        gaps = [(sum(g * float(v - v0) for g, v, v0 in zip(gradient, vertex, direction)), vertex)
                for vertex in vertices]
        gap, best = min(gaps)
        lower = value + tau * gap
        print(tau, 'C trial', value, 'C lower minus V', lower - reduced_deficit(3 * tau / 4, 0, 'B'),
              'support gap', gap, 'support vertex', tuple(str(v) for v in best))


if __name__ == '__main__':
    main()
