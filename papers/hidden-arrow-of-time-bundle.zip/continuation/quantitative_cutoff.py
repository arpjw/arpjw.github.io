"""Exact audits for the explicit all-memory validity cutoff.

The universal theorem uses a written cycle-decomposition proof. Exhaustive
small-graph checks below corroborate its denominator and sharpness claims.
They do not extrapolate the theorem from finitely many memories.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path

from memory_coefficient import check_certificate, objective, words
from parity_dual import conjectured
from intervals import I, ln2, log as ilog


def cycles(k: int) -> list[tuple[int, int, tuple[int, ...]]]:
    """All simple cycles of the signed, directed multigraph, once per rotation."""
    edges = words(k)
    adjacency: dict[int, list[tuple[int, int, int]]] = defaultdict(list)
    for index, edge in enumerate(edges):
        a, b = int(edge[:-1], 2), int(edge[1:], 2)
        adjacency[a].append((b, index, 1))
        adjacency[b].append((a, index, -1))
    result = []
    for root in range(2 ** (k - 1)):
        def walk(node: int, visited: set[int], path: list[tuple[int, int]]) -> None:
            for nxt, index, sign in adjacency[node]:
                if nxt < root:
                    continue
                new_path = path + [(index, sign)]
                if nxt == root:
                    vector = [0] * len(edges)
                    for e, s in new_path:
                        vector[e] += s
                    result.append((len(new_path), sum(s for _, s in new_path), tuple(vector)))
                elif nxt not in visited:
                    walk(nxt, visited | {nxt}, new_path)
        walk(root, {root}, [])
    return result


def generators(k: int) -> tuple[set[tuple[Q, ...]], dict]:
    cc = cycles(k)
    positive = [(length, mass, v) for length, mass, v in cc if mass > 0]
    negative = [(length, mass, v) for length, mass, v in cc if mass < 0]
    balanced = [(length, mass, v) for length, mass, v in cc if mass == 0]
    generated = set()
    count = 0
    max_denominator = 1
    n = 2 ** (k - 1)
    def add(numerators: tuple[int, ...], denominator: int) -> None:
        nonlocal count, max_denominator
        assert denominator % 2 == 0
        assert denominator // 2 <= n * n
        v = tuple(Q(2 * x, denominator) for x in numerators)
        assert sum(v) == 0 and sum(abs(x) for x in v) <= 2
        balance = Counter()
        for edge, value in zip(words(k), v):
            balance[edge[:-1]] += value
            balance[edge[1:]] -= value
        assert all(value == 0 for value in balance.values())
        # A common denominator <= n^2 exists, even before cancellation.
        assert all((denominator // 2) % x.denominator == 0 for x in v)
        max_denominator = max(max_denominator, denominator // 2)
        generated.add(v)
        count += 1
    for length, _, vector in balanced:
        add(vector, length)
    for lp, dp, vp in positive:
        for lm, dm, vm in negative:
            add(tuple(-dm * a + dp * b for a, b in zip(vp, vm)), -dm * lp + dp * lm)
    return generated, {'k': k, 'simple_cycles': len(cc), 'balanced_cycles': len(balanced),
                       'positive_cycles': len(positive), 'negative_cycles': len(negative),
                       'generated_before_deduplication': count, 'distinct_projected_generators': len(generated),
                       'largest_unreduced_common_denominator': max_denominator,
                       'universal_denominator_bound': n * n}


def finite_audit() -> list[dict]:
    records = json.loads(Path('results/memory_coefficient.json').read_text())['certificates']
    rows = []
    for k in (3, 4):
        gg, row = generators(k)
        alpha = conjectured(k)
        n, d = 2 ** (k - 1), alpha.denominator
        gap = Q(1, d * n * n)
        sharpness = gap / 4
        checked, singleton_maximizers = 0, 0
        observed_positive_gaps = []
        exact_sharpness = []
        other_class_maxima = []
        for record in (r for r in records if r['k'] == k):
            exact_alpha = check_certificate(record)
            ell = objective(record['missing_word'])
            vector = [ell.get(e, Q(0)) for e in words(k)]
            values = [(sum(x * y for x, y in zip(v, vector)), v) for v in gg]
            maximum = max(x for x, _ in values)
            assert maximum == exact_alpha
            maximizing = [v for x, v in values if x == maximum]
            if maximum == alpha:
                for value, v in values:
                    if value < alpha:
                        assert alpha - value >= gap
                        observed_positive_gaps.append(alpha - value)
                if k >= 4:
                    assert len(maximizing) == 1
                    star = maximizing[0]
                    for value, v in values:
                        assert alpha - value >= sharpness * sum(abs(a - b) for a, b in zip(star, v))
                    exact_c = min((alpha - value) / sum(abs(a - b) for a, b in zip(star, v))
                                  for value, v in values if value < alpha)
                    exact_sharpness.append(str(exact_c))
                    singleton_maximizers += 1
            else:
                assert maximum <= alpha - gap
                other_class_maxima.append(maximum)
            checked += 1
        row.update({'word_classes_checked': checked, 'maximizing_singleton_classes': singleton_maximizers,
                    'universal_objective_gap': str(gap), 'universal_L1_sharpness': str(sharpness),
                    'smallest_observed_positive_gap': str(min(observed_positive_gaps)),
                    'exact_sharpness_of_maximizing_classes': exact_sharpness,
                    'largest_other_class_maximum': str(max(other_class_maxima))})
        rows.append(row)
    return rows


def sharper_four(audit: list[dict]) -> dict:
    row = next(r for r in audit if r['k'] == 4)
    assert row['exact_sharpness_of_maximizing_classes'] == ['1/22', '1/22']
    assert Q(row['largest_other_class_maximum']) == Q(5, 8)
    x = Q(1, 2 ** 35)
    remainder_gradient = 3 * x / (1 - x) + 2 * x / (2 - x)
    assert remainder_gradient < Q(1, 1000)
    assert ln2().fraction_bounds()[0] > Q(693, 1000)
    assert ln2().fraction_bounds()[1] < Q(7, 10)
    assert ilog(I.point(3)).fraction_bounds()[1] < Q(11, 10)
    gradient_margin = Q(35, 22) * Q(693, 1000) - Q(11, 10) - remainder_gradient
    class_margin = Q(35, 24) * Q(693, 1000) - Q(5, 6) * Q(7, 10) - 8 * x
    assert gradient_margin > 0 and class_margin > 0
    assert x <= Q(1, 6) / 16
    return {'valid_tolerance': '2^(-39)', 'relative_tolerance_tau_over_h': '2^(-35)',
            'gradient_margin_lower_bound': str(gradient_margin),
            'other_word_class_margin_lower_bound': str(class_margin),
            'scope': 'All positive tolerances through the displayed endpoint; exact convexity and uniform remainder bounds, not a pointwise numerical test.'}


def cutoff_rows() -> list[dict]:
    # ln2 > 1/2 and ln2 < 1 are certified by the existing exact interval library.
    assert ln2().fraction_bounds()[0] > Q(1, 2)
    assert ln2().fraction_bounds()[1] < 1
    rows = []
    for k in (3, 4, 5, 6, 10, 11, 20, 50, 101):
        alpha = conjectured(k)
        rho = 1 - alpha if k % 2 else alpha - Q(1, 2)
        d, n = alpha.denominator, 2 ** (k - 1)
        exponent = 32 * d * n * n
        gap, sharpness = Q(1, d * n * n), Q(1, 4 * d * n * n)
        assert exponent >= 2 * k + 5
        assert rho >= Q(1, 2 * (k + 1))
        assert sharpness * Q(exponent, 2) == 4
        assert gap * Q(exponent, 2) == 16
        # This proves 2^-exponent <= rho/16 without materializing that tiny number.
        assert 2 ** (k + 1) >= 2 * (k + 1)
        rows.append({'k': k, 'alpha': str(alpha), 'rho': str(rho),
                     'alpha_denominator': d, 'valid_tolerance': f'2^(-{k + exponent})',
                     'binary_exponent': k + exponent,
                     'gradient_margin_lower_bound_after_ln2_gt_half': 'strictly positive for k>=4; k=3 uses the earlier exact solution',
                     'word_class_comparison_lower_bound_in_units_of_tau': '>8'})
    return rows


def main() -> None:
    audit = finite_audit()
    result = {'status': 'PASS: exact finite generator audit and cutoff arithmetic',
              'small_graph_audit': audit, 'explicit_cutoffs': cutoff_rows(),
              'sharper_memory_four_interval': sharper_four(audit),
              'scope': 'The written cycle-decomposition and entropy bounds prove the cutoff for all k. The finite audits corroborate the graph lemma and independently recover all word-class LP values at k=3,4. The bounds are highly conservative and are not claimed sharp.'}
    Path('results/quantitative_cutoff.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
