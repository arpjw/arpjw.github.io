"""Exact construction and interval audits for arbitrary finite alphabets.

The written theorem supplies global optimality and the singular-limit proof.
This script checks rational flows, finite-path identities, fixed-corner entropy
minimizers, certified scalar inversions, and readable numerical consequences.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import permutations, product
import json
from math import isqrt
from pathlib import Path
import random

from intervals import I, SCALE, ln2, log as ilog

Word = tuple[int, ...]
Matrix = tuple[tuple[Q, ...], ...]


def words(m: int, length: int) -> list[Word]:
    return list(product(range(m), repeat=length))


def xlog(x: Q) -> I:
    return I.point(0) if x == 0 else x * ilog(I.point(x))


def corner_block(m: int, t: Q, a: int = 0, b: int = 1) -> Matrix:
    assert m >= 3 and 0 <= t <= 1 and 0 <= a < m and 0 <= b < m
    r, c = (1 - t) / (m - 1), (m - 2 + t) / (m - 1) ** 2
    matrix = tuple(tuple(t if (i, j) == (a, b) else r if i == a or j == b else c
                         for j in range(m)) for i in range(m))
    assert all(sum(row) == 1 for row in matrix)
    assert all(sum(matrix[i][j] for i in range(m)) == 1 for j in range(m))
    if t <= Q(1, m):
        assert min(x for row in matrix for x in row) == t
    return matrix


def phi(m: int, t: Q) -> I:
    """Exact fixed-corner block cost, with outward-rounded logarithms."""
    return (xlog(m * t) / m + 2 * (1 - t) * ilog(I.point(Q(m) * (1 - t) / (m - 1)))
            + (m - 2 + t) * ilog(I.point(Q(m) * (m - 2 + t) / (m - 1) ** 2))) / m


def block_cost(matrix: Matrix) -> I:
    m = len(matrix)
    return ilog(I.point(m)) + sum((xlog(x) for row in matrix for x in row), I.point(0)) / m


def overlap(a: I, b: I) -> None:
    assert a.lo <= b.hi and b.lo <= a.hi, (a, b)


@dataclass(frozen=True)
class Source:
    m: int
    k: int
    epsilon: Q
    missing: Word

    def __post_init__(self) -> None:
        assert self.m >= 3 and self.k >= 1 and 0 <= self.epsilon <= 1
        assert len(self.missing) == self.k + 1
        assert all(0 <= x < self.m for x in self.missing)

    def transition(self, word: Word) -> Q:
        assert len(word) == self.k + 1
        if word[1:-1] != self.missing[1:-1]:
            return Q(1, self.m)
        a, b = self.missing[0], self.missing[-1]
        i, j = word[0], word[-1]
        base = Q(0) if (i, j) == (a, b) else Q(1, self.m - 1) if i == a or j == b else Q(self.m - 2, (self.m - 1) ** 2)
        return (1 - self.epsilon) * base + self.epsilon / self.m

    def flow(self) -> dict[Word, Q]:
        q = {w: self.transition(w) / self.m ** self.k for w in words(self.m, self.k + 1)}
        for v in words(self.m, self.k):
            assert sum(q[v + (a,)] for a in range(self.m)) == Q(1, self.m ** self.k)
            assert sum(q[(a,) + v] for a in range(self.m)) == Q(1, self.m ** self.k)
        assert sum(q.values()) == 1
        return q

    def probability(self, path: Word) -> Q:
        if len(path) <= self.k:
            return Q(1, self.m ** len(path))
        result = Q(1, self.m ** self.k)
        for i in range(self.k, len(path)):
            result *= self.transition(path[i - self.k:i + 1])
        return result

    def deficit(self) -> I:
        # Fair-flow mixing stays inside the fixed-corner entropy-minimizing family.
        return phi(self.m, self.epsilon / self.m) / self.m ** (self.k - 1)

    def rate(self) -> I:
        assert self.epsilon > 0
        q = self.flow()
        # Pair opposite words to avoid cancellation.
        return sum(((value - q[w[::-1]]) * ilog(I.point(value / q[w[::-1]]))
                    for w, value in q.items() if w < w[::-1]), I.point(0))


def one_corner_rate(m: int, k: int, t: Q, palindromic_context: bool) -> I:
    assert 0 < t < Q(1, m)
    r, c = (1 - t) / (m - 1), (m - 2 + t) / (m - 1) ** 2
    if palindromic_context:
        return ((t - c) * ilog(I.point(t / c))
                + 2 * (m - 2) * (r - c) * ilog(I.point(r / c))) / m ** k
    return (t - Q(1, m)) * ilog(I.point(t * (m - 2 + t) / (1 - t) ** 2)) / m ** k


def asymptotic_audit() -> list[dict]:
    rows = []
    for m, k in ((3, 1), (3, 2), (3, 3), (4, 3), (10, 1)):
        pal = k <= 2
        coefficient = Q(m - 2, m ** k * (m - 1) ** 2) if pal else Q(1, m ** (k + 1))
        examples = []
        for power in (3, 6, 9):
            t = Q(1, 10 ** power)
            rate = one_corner_rate(m, k, t, pal)
            approximation = coefficient * ilog(I.point(1 / ((m - 2) * t)))
            eta = (phi(m, Q(0)) - phi(m, t)) / m ** (k - 1)
            assert eta.lo > 0
            big_l = ilog(1 / eta)
            budget_asymptotic = coefficient * (big_l + ilog(big_l) - k * ilog(I.point(m)) - ilog(I.point(m - 2)))
            examples.append({'t': str(t), 'threshold_gap_nats': eta.decimal_bounds(),
                             'exact_family_rate': rate.decimal_bounds(),
                             'rate_minus_transition_asymptotic': (rate - approximation).decimal_bounds(),
                             'rate_minus_budget_asymptotic': (rate - budget_asymptotic).decimal_bounds()})
            if m <= 4:
                missing = (0,) * k + (1,) if pal else (0,) + (0,) * (k - 2) + (1, 1)
                source = Source(m, k, m * t, missing)
                overlap(source.rate(), rate)
        rows.append({'m': m, 'k': k, 'coefficient': str(coefficient),
                     'context_type': 'palindromic' if pal else 'nonpalindromic', 'examples': examples})
    return rows


def fixed_corner_audit() -> dict:
    rng = random.Random(131013)
    count = 0
    for m in range(3, 9):
        for a, b in ((0, 0), (0, 1), (m - 1, 0)):
            for t in (Q(0), Q(1, 100 * m), Q(1, 2 * m), Q(1, m), Q(1, 2)):
                matrix = corner_block(m, t, a, b)
                overlap(block_cost(matrix), phi(m, t))
                count += 1
        perms = list(permutations(range(m))) if m <= 6 else None
        for trial in range(12):
            chosen = []
            for _ in range(7):
                if perms is not None:
                    pp = rng.choice(perms)
                else:
                    pp = tuple(rng.sample(range(m), m))
                # Half the trials constrain the special corner to zero.
                while trial % 2 == 0 and pp[0] == 1:
                    pp = tuple(rng.sample(range(m), m))
                chosen.append(pp)
            weights = [rng.randint(1, 10) for _ in chosen]
            total = sum(weights)
            matrix = tuple(tuple(Q(sum(weight for perm, weight in zip(chosen, weights) if perm[i] == j), total)
                                 for j in range(m)) for i in range(m))
            t = matrix[0][1]
            optimum = corner_block(m, t)
            assert sum(matrix[0][j] for j in range(m) if j != 1) == 1 - t
            assert sum(matrix[i][1] for i in range(1, m)) == 1 - t
            assert sum(matrix[i][j] for i in range(1, m) for j in range(m) if j != 1) == m - 2 + t
            divergence = sum((x * ilog(I.point(x / optimum[i][j])) / m
                              for i, row in enumerate(matrix) for j, x in enumerate(row) if x), I.point(0))
            gap = block_cost(matrix) - phi(m, t)
            overlap(gap, divergence)
            if matrix != optimum:
                assert gap.lo > 0
            count += 1
    return {'fixed_corner_and_KL_identity_cases': count, 'alphabet_sizes': list(range(3, 9))}


def path_audit() -> dict:
    counts = 0
    for m, k in ((3, 1), (4, 1), (3, 2), (3, 3)):
        source = Source(m, k, Q(1, 10), (0,) * k + (1,))
        q = source.flow()
        delta_coeff = Counter({Q(m): Q(1)})
        rate_coeff = Counter()
        for w, value in q.items():
            delta_coeff[source.transition(w)] += value
            rate_coeff[source.transition(w)] += value
            rate_coeff[source.transition(w[::-1])] -= value
        n = k + 3
        forward_coeff, reversal_coeff = Counter(), Counter()
        total = Q(0)
        for path in words(m, n):
            probability = source.probability(path)
            total += probability
            forward_coeff[Q(m)] += (n - k) * probability
            ratio = Q(1)
            for i in range(k, n):
                w = path[i - k:i + 1]
                p, pr = source.transition(w), source.transition(w[::-1])
                forward_coeff[p] += probability
                reversal_coeff[p] += probability
                reversal_coeff[pr] -= probability
                ratio *= p / pr
            assert ratio == probability / source.probability(path[::-1])
            counts += 1
        assert total == 1
        def clean(c: Counter) -> dict:
            return {x: y for x, y in c.items() if y}
        assert clean(forward_coeff) == clean(Counter({x: (n - k) * y for x, y in delta_coeff.items()}))
        assert clean(reversal_coeff) == clean(Counter({x: (n - k) * y for x, y in rate_coeff.items()}))
    return {'exact_path_probability_and_log_coefficient_checks': counts, 'source_cases': 4}


def inverse_bracket(m: int, target: I) -> tuple[Q, Q]:
    lo, hi = Q(0), Q(1, m)
    assert phi(m, lo).lo > target.hi and phi(m, hi).hi < target.lo
    for _ in range(70):
        mid = (lo + hi) / 2
        value = phi(m, mid)
        if value.lo > target.hi:
            lo = mid
        elif value.hi < target.lo:
            hi = mid
        else:
            raise AssertionError('interval precision insufficient for inversion')
    assert phi(m, lo).lo > target.hi and phi(m, hi).hi < target.lo
    return lo, hi


def positive_series(m: int, terms: int = 30) -> tuple[Q, Q]:
    base = m - 1
    partial = sum((Q(1, m * j * (2 * j - 1) * base ** (2 * j - 1)) for j in range(1, terms + 1)), Q(0))
    first_tail = Q(1, m * (terms + 1) * (2 * terms + 1) * base ** (2 * terms + 1))
    tail = first_tail / (1 - Q(1, base * base))
    return partial, partial + tail


def main() -> None:
    block_checks = fixed_corner_audit()
    path_checks = path_audit()
    flow_count = 0
    for m in range(3, 7):
        for k in range(1, 4):
            for missing in ((0,) * k + (1,), (0,) * (k + 1), tuple(i % m for i in range(k + 1))):
                for epsilon in (Q(0), Q(1, 10), Q(1, 1000)):
                    source = Source(m, k, epsilon, missing)
                    q = source.flow()
                    direct = ilog(I.point(m)) + sum((value * ilog(I.point(source.transition(w)))
                                                   for w, value in q.items() if value), I.point(0))
                    overlap(direct, source.deficit())
                    if epsilon == 0:
                        assert sum(value == 0 for value in q.values()) == 1
                        assert (q[missing[::-1]] > 0) == (missing != missing[::-1])
                    else:
                        assert min(q.values()) > 0
                    flow_count += 1
    thresholds = []
    for m in (3, 4, 10, 256, 1000):
        value = phi(m, Q(0))
        lo, hi = positive_series(m)
        overlap(value, I.hull(lo, hi))
        assert value.fraction_bounds()[0] >= Q(1, m * (m - 1))
        assert value.fraction_bounds()[1] <= Q(m - 1, m * m * (m - 2))
        thresholds.append({'m': m, 'memory_one_threshold_nats': value.decimal_bounds(),
                           'series_terms': 30, 'series_remainder_bound': str(hi - lo)})
    inversions = []
    for m, k in ((3, 1), (4, 2), (10, 3)):
        target = phi(m, Q(0)) / 2
        lo, hi = inverse_bracket(m, target)
        finite_bound = ilog(I.point((1 - (m - 1) * lo) / lo))
        inversions.append({'m': m, 'k': k, 'budget_fraction_of_threshold': '1/2',
                           'minimum_transition_bracket': I.hull(lo, hi).decimal_bounds(),
                           'exact_rational_bracket': [str(lo), str(hi)],
                           'reversal_rate_upper_bound_nats': finite_bound.decimal_bounds()[1]})
    regularizations = []
    previous = None
    for power in (1, 3, 6, 12, 24):
        source = Source(3, 1, Q(1, 10 ** power), (0, 1))
        deficit, rate = source.deficit(), source.rate()
        assert deficit.hi < phi(3, Q(0)).lo
        if previous is not None:
            assert rate.lo > previous.hi
        previous = rate
        regularizations.append({'epsilon': f'10^-{power}', 'deficit_nats': deficit.decimal_bounds(),
                                'reversal_rate_nats': rate.decimal_bounds()})
    # An integer square-root ceiling certifies the finite-sample advantage.
    byte_delta = phi(256, Q(0)) / 256 ** 2
    advantage_squared = byte_delta * Q(997, 2)
    root_raw = isqrt(advantage_squared.hi * SCALE)
    if root_raw * root_raw < advantage_squared.hi * SCALE:
        root_raw += 1
    success_upper = Q(1, 2) + Q(root_raw, SCALE)
    entropy_bits_lower = (I.point(8) - byte_delta / ln2()).decimal_bounds()[0]
    report = {'status': 'PASS: exact rational flow and path identities; outward-rounded entropy certificates',
              'block_audit': block_checks, 'path_audit': path_checks, 'stationary_flow_and_entropy_cases': flow_count,
              'thresholds': thresholds, 'certified_inversions': inversions, 'ternary_regularizations': regularizations,
              'near_threshold_asymptotic_checks': asymptotic_audit(),
              'byte_example': {'m': 256, 'k': 3, 'classification_length': 1000,
                               'threshold_nats': byte_delta.decimal_bounds(), 'entropy_bits_per_byte_lower_bound': entropy_bits_lower,
                               'classification_success_upper_bound': I.point(success_upper).decimal_bounds()[1]},
              'scope': 'The global threshold, sharp minimum-transition envelope, and asymptotic optimality up to vanishing additive error are established by the written proof. The displayed asymptotic examples concern the explicit family, not numerical global optimization. Finite checks corroborate identities; novelty and independent expert review remain open.'}
    Path('results/alphabet_threshold.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
