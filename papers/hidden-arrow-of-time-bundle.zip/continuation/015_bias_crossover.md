# Resolving the almost-fair-coin crossover

Status: a written uniform asymptotic proof with exact scalar certificates. Research draft; independent expert review and novelty checking remain open. All logarithms use nats. Memory is fixed throughout.

## 1. Two limits and a single crossover

Continuation 14 found a factor of two between the divergence coefficient of an exactly fair coin and the limit of the coefficients of increasingly fair biased coins. Here the two limits are taken together.

Fix \(k\ge3\). Put

\[
p=\frac{1-s}{2},\quad q=\frac{1+s}{2},\quad
R=p^{k-2}q,\quad R_0=2^{1-k},\quad C_0=R_0/4=2^{-k-1}.
\]

The bias parameter is \(s=q-p\ge0\). Sources have exactly independent length-\(k\) laws with symbol frequencies \((p,q)\). Let \(M_{p,k}(d)\) be the supremum of observable reversal divergence under entropy deficit at most \(d\). The singular threshold, with \(0\log0=0\), is

\[
\Delta(p)=R F_p,\qquad F_p=s\log s-2q\log q.
\]

Set \(\eta=\Delta(p)-d>0\), \(L=\log(1/\eta)\). We let \(s\to0\) and \(\eta\to0\) simultaneously, with no initial restriction on their relative speeds.

**Uniform implicit theorem.** Define

\[
T_p(x)=\begin{pmatrix}x&p-x\\p-x&s+x\end{pmatrix},\qquad
f_p(x)=D\bigl(T_p(x)\Vert(p,q)\otimes(p,q)\bigr).
\]

Let \(z\in(0,p^2)\) solve \(Rf_p(z)=d\). Then

\[
\boxed{M_{p,k}(d)
=R(p^2-z)\log\frac{(p-z)^2}{z(s+z)}+o(1).}
\]

The error tends to zero along every joint path \((s,\eta)\to(0,0)\), including \(s=0\). This is stronger than a fixed-bias asymptotic. It is still an asymptotic theorem, not a statement that the displayed family exactly maximizes every finite budget.

**Explicit crossover theorem.** If

\[
\beta=\frac{s\log(1/\eta)}{\eta}
\]

stays bounded, the same optimum is

\[
\boxed{M_{p,k}(d)
=2C_0\{L+\log L+\log R_0\}
 -C_0\log(1+2R_0\beta)+o(1).}
\]

Thus the crossover scale is \(s\asymp\eta/\log(1/\eta)\). The last logarithm is an explicit correction to the exactly fair answer at the same distance from each law's own threshold.

## 2. Reducing all sources to two boundary families

Every binary block with both margins \((p,q)\) is \(T_p(x)\). A middle context \(u\) has weight \(r_u\), the product of its symbol probabilities. Its block contributes \(r_u f_p(x_u)\) to the entropy deficit. A palindromic context contributes zero to reversal. A reversed pair of distinct contexts contributes

\[
r_u\,J\bigl(T_p(x_u),T_p(x_{u^R})\bigr),
\]

where \(J(A,B)=D(A\Vert B)+D(B\Vert A)\). A nonpalindromic context contains both symbols, so its minimum weight is \(R=p^{k-2}q\). The largest possible weight is \(pq^{k-2}\); both tend to \(R_0\).

For a source with only one nonindependent block \(T_p(x)\) at a nonpalindromic context, its exact rate divided by the context weight is

\[
j_p(x)=(x-p^2)f'_p(x),\qquad
f'_p(x)=\log\frac{x(s+x)}{(p-x)^2}.
\]

There are two potentially relevant boundary families: \(x=z\downarrow0\), with two diagonal entries \(z,s+z\); and \(x=p-t\uparrow p\), with both off-diagonal entries equal to \(t\downarrow0\). Their boundary costs are respectively \(F_p\) and
\(H(p)=-p\log p-q\log q\).

We first prove that no other source changes the global answer by a nonvanishing additive amount. Take any nearly maximizing sequence in the joint limit. The displayed one-block competitors have diverging rates, so the nearly maximizing rates also diverge. By compactness, subsequences converge to a fair binary flow with deficit at most \(R_0\log2\) and a relevant zero. The threshold equality classification from Continuation 14 forces a single nonindependent block, equal to a boundary matrix, at a nonpalindromic context. Every other block is independent.

For a nearby source \(Q\), form \(Q_x\) by keeping that entire block exactly and replacing every other block by the independent one. There is an exact identity

\[
\delta(Q)-\delta(Q_x)=D(Q\Vert Q_x).
\]

Here the distributions in the right-hand side are the length-\((k+1)\) flows. Since the total budget lies below \(\Delta(p)\), this relative entropy is at most the entropy drop from the corresponding block boundary. With \(h=z\) or \(h=t\), that drop is \(O(h\log(1/h))\), uniformly for \(p\) near \(1/2\). For the diagonal boundary, for example,

\[
F_p-f_p(z)=\int_0^z
\log\frac{(p-v)^2}{v(s+v)}\,dv
\le 2z\log(1/z)+O(z).
\]

Pinsker therefore gives \(\|Q-Q_x\|_1=O(\sqrt{h\log(1/h)})\). Crucially, both small entries are fixed exactly by the binary margin constraints. Every other relevant entry of the comparison flow stays uniformly positive. Isolating the two possibly singular reversal pairs yields

\[
\sigma(Q)-\sigma(Q_x)
=O\bigl(\sqrt h\,[\log(1/h)]^{3/2}\bigr)=o(1),
\]

uniformly as the bias disappears. Freezing only one of two unrelated small entries would not justify this step; the binary constraint freezes the whole block.

Since \(f_p\) decreases on \((0,p^2)\) and increases on \((p^2,p)\), and \(j_p\) moves in the same direction away from its minimum, the best comparison at weight \(r\) uses all the budget: \(rf_p(x)=d\), on either branch.

## 3. The minimum context weight remains best

We must also control context weights as they coalesce at fairness. On either inverse branch \(f_p(x)=d/r\), differentiation gives

\[
\frac{d}{dr}\{rj_p(x)\}
=j_p(x)-f_p(x)\frac{j'_p(x)}{f'_p(x)},\qquad
\frac{j'_p}{f'_p}=1+\frac{(x-p^2)f''_p(x)}{f'_p(x)}.
\]

Uniformly for all \(r\) between the smallest and largest context weights, the two roots approach their respective boundaries: \(d/r\to\log2\) and \(p\to1/2\). Write \(h=x\) on the left branch and \(h=p-x\) on the right. Then \(f_p(x)\) and \(|x-p^2|\) are bounded below by positive constants,

\[
f''_p(x)=\frac1x+\frac2{p-x}+\frac1{s+x}\ge\frac1h,
\qquad |f'_p(x)|=O(\log(1/h)),\quad j_p(x)=O(\log(1/h)).
\]

The ratio \((x-p^2)/f'_p(x)\) is positive. Consequently the negative term in the weight derivative has size at least a positive constant divided by \(h\log(1/h)\), whereas the positive term is only \(O(\log(1/h))\). The derivative is strictly negative for all sufficiently small joint parameters, uniformly over the weight interval.

Combining this with the previous section gives

\[
M_{p,k}(d)=\max\{S_-,S_+\}+o(1),
\]

where

\[
\begin{aligned}
S_-&=R(p^2-z)\log\frac{(p-z)^2}{z(s+z)},&Rf_p(z)&=d,\\
S_+&=R(pq-t)\log\frac{(p-t)(q-t)}{t^2},&Rf_p(p-t)&=d.
\end{aligned}
\]

The original optimization over all blocks has thus become a comparison of two explicitly defined scalar families, with a uniform additive error.

## 4. Comparing the families in the crossover window

The boundary-cost difference has the exact expression and expansion

\[
B(s)=H(p)-F_p=q\log q-p\log p-s\log s
=s\{\log(1/s)+1-\log2\}+O(s^3).
\]

Assume first that \(\beta=sL/\eta\) is bounded. Uniform endpoint entropy estimates imply

\[
z=\frac{\eta}{2R_0L}(1+o(1)),\qquad
t=\frac{\eta(1+R_0\beta)}{2R_0L}(1+o(1)),\qquad
\frac{s}{z}=2R_0\beta+o(1).
\]

Here is the needed entropy calculation. With \(\lambda=s/z\),

\[
F_p-f_p(z)=2z\log(1/z)
 +z\{2(1+\log p)+\lambda\log\lambda
 -(1+\lambda)\log(1+\lambda)\}+O(z^2),
\]

uniformly for bounded \(\lambda\). The integral bounds first give \(z\) comparable to \(\eta/L\), so bounded \(\beta\) implies bounded \(\lambda\), making this expansion applicable. On the other branch,

\[
H(p)-f_p(p-t)=2t\log(1/t)+t\{2+\log(pq)\}+O(t^2).
\]

Its required entropy drop is \(\eta/R+B(s)\). Uniformly for bounded \(\beta\), including \(\beta\to0\), one has \(RB(s)/\eta=R_0\beta+o(1)\). This follows from \(s=\beta\eta/L\) and the boundedness of \(\beta|\log\beta|\) near zero. The root estimates follow.

Let \(G(\eta)=2C_0\{L+\log L+\log R_0\}\). Substitution into the exact rates gives

\[
S_-=G(\eta)-C_0\log(1+2R_0\beta)+o(1),
\quad
S_+=G(\eta)-2C_0\log(1+R_0\beta)+o(1).
\]

The elementary inequality

\[
(1+x)^2\ge1+2x
\]

shows that \(S_-\) is asymptotically at least as good. If \(\beta\) tends to a positive finite value, its advantage tends to

\[
C_0\log\frac{(1+R_0\beta)^2}{1+2R_0\beta}>0.
\]

This proves the explicit crossover theorem, after including the uniform comparison error from the previous sections.

## 5. The remaining joint paths

It remains to exclude an advantage for the other branch when \(\beta\to\infty\). The diagonal entropy integral gives
\(z=O(\eta/L)\), hence \(z/s\to0\). Moreover,

\[
\eta=o(s\log(1/s)).
\]

To see this, put \(a=\eta/s\). If \(a\le1\) it is immediate. If \(a>1\), then \(a=o(L)\) by \(\beta\to\infty\), while \(L\le\log(1/s)\). The assertion follows in both cases.

Thus the off-diagonal entropy drop is dominated by \(B(s)\), and its root satisfies \(t/s\to1/2\). Expanding the exact rates, while retaining the bias-dependent coefficient multiplying \(\log(1/z)\), gives

\[
S_--S_+
=Rp^2\log(s/z)-2C_0\log2+o(1)\longrightarrow\infty.
\]

In this calculation the other potentially significant term is
\(-2Rps\log(1/s)\), which tends to zero. Retaining \(Rp^2\) in the first term matters: \(s\log(1/z)\) need not tend to zero along an arbitrarily fast approach to the entropy threshold.

Every joint sequence has subsequences on which \(\beta\) is bounded or tends to infinity. The two cases prove \(\max(S_-,S_+)=S_-+o(1)\), establishing the uniform implicit theorem along every joint path.

## 6. A continuum between the two coefficients

For a particularly readable family of joint limits, prescribe

\[
s=c\eta^\alpha,\qquad c>0,\quad\alpha>0.
\]

When \(0<\alpha\le1\), the two small diagonal entries have very different sizes. The preceding entropy integral yields
\(z\sim\eta/[R_0(1+\alpha)L]\). The full expansion is

\[
\boxed{M_{p,k}(d)=C_0\left\{(1+\alpha)L+\log L
 +\log\frac{R_0(1+\alpha)}{4c}\right\}+o(1),
\quad 0<\alpha\le1.}
\]

For \(\alpha>1\), \(\beta\to0\), so the fair expansion applies:

\[
\boxed{M_{p,k}(d)=2C_0\{L+\log L+\log R_0\}+o(1).}
\]

In particular,

\[
\boxed{\frac{M_{p,k}(d)}{\log(1/\eta)}
\longrightarrow C_0\{1+\min(\alpha,1)\}.}
\]

There is a continuum of leading coefficients between the biased-limit value \(C_0\) and the fair value \(2C_0\). At \(\alpha=1\), the leading coefficient has already reached the fair value, but the coefficient of \(\log L\) is still only half its fair value. The narrower scale \(s\asymp\eta/L\) resolves that further transition.

For example, at memory three \(C_0=1/16\). Bias \(s=\sqrt\eta\) gives leading coefficient \(3/32\), while bias \(s=\eta^2\) gives \(1/8\). These statements concern distance to the corresponding biased law's own threshold.

## 7. Evidence and open questions

Reproduce with `python3 continuation/bias_crossover.py`.

The receipt `results/bias_crossover.json` contains 60 crossover-family cases at memories three, four, and seven; nine power-law cases; 30 certified weight-derivative examples; and five boundary-gap identity checks. Inverse entries are enclosed by rational bisection with outward-rounded logarithms. Selected closed rates are checked against full stationary flows. The 60 crossover examples prescribe rational \(s/z\), then compute the implied entropy gap and crossover parameter; the power-law examples instead prescribe rational gaps and exact rational biases.

These are certified evaluations of the explicit families, not computer certificates for the entire parameter continuum or a numerical global maximization. Uniformity, elimination of other sources, and comparison of all context weights are the written proof. No explicit universal error constant or finite validity cutoff is supplied.

No previous theorem needed correction. The earlier fixed-law proof alone did not justify interchanging limits; the present argument supplies the missing uniform control and checks the competing boundary family. Exact finite-budget optimizer uniqueness for biased coins remains open, as does whether the diagonal one-block family beats the off-diagonal one at every common subcritical cost. An 80-case exploratory floating-point sweep supported that stronger scalar comparison, but it is not claimed as a theorem. Its separate script and receipt are `continuation/explore_biased_scalar.py` and `results/biased_scalar_exploration.json`.

The results remain research drafts. No new novelty search was performed for this continuation, and independent expert review remains necessary. No claim of publication priority is made.
