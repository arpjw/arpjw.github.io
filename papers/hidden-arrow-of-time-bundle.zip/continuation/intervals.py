"""Outward-rounded fixed-point intervals using exact integer arithmetic.

No floating-point operations are used for bounds. Transcendentals use positive
Taylor series with explicit remainder bounds and monotone endpoint evaluation.
This is a small task-specific verifier, not a general interval library.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from math import factorial

DIGITS = 40
SCALE = 10**DIGITS


def ceil_div(numerator: int, denominator: int) -> int:
    return -((-numerator) // denominator)


@dataclass(frozen=True)
class I:
    lo: int
    hi: int

    def __post_init__(self) -> None:
        if self.lo > self.hi:
            raise ValueError("reversed interval")

    @staticmethod
    def point(value: int | str | Fraction | I) -> I:
        if isinstance(value, I):
            return value
        q = Fraction(value)
        return I(q.numerator * SCALE // q.denominator, ceil_div(q.numerator * SCALE, q.denominator))

    @staticmethod
    def hull(low: int | str | Fraction | I, high: int | str | Fraction | I) -> I:
        return I(I.point(low).lo, I.point(high).hi)

    def __add__(self, other) -> I:
        other = I.point(other)
        return I(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self) -> I:
        return I(-self.hi, -self.lo)

    def __sub__(self, other) -> I:
        return self + (-I.point(other))

    def __rsub__(self, other) -> I:
        return I.point(other) + (-self)

    def __mul__(self, other) -> I:
        other = I.point(other)
        candidates = [self.lo * other.lo, self.lo * other.hi, self.hi * other.lo, self.hi * other.hi]
        return I(min(candidates) // SCALE, ceil_div(max(candidates), SCALE))

    __rmul__ = __mul__

    def reciprocal(self) -> I:
        if self.lo <= 0 <= self.hi:
            raise ZeroDivisionError("interval contains zero")
        return I(SCALE * SCALE // self.hi, ceil_div(SCALE * SCALE, self.lo))

    def __truediv__(self, other) -> I:
        return self * I.point(other).reciprocal()

    def __rtruediv__(self, other) -> I:
        return I.point(other) * self.reciprocal()

    def square(self) -> I:
        if self.lo >= 0:
            return I(self.lo * self.lo // SCALE, ceil_div(self.hi * self.hi, SCALE))
        if self.hi <= 0:
            return (-self).square()
        return I(0, ceil_div(max(self.lo * self.lo, self.hi * self.hi), SCALE))

    def fraction_bounds(self) -> tuple[Fraction, Fraction]:
        return Fraction(self.lo, SCALE), Fraction(self.hi, SCALE)

    def decimal_bounds(self) -> list[str]:
        def format_integer(n: int) -> str:
            sign = "-" if n < 0 else ""
            n = abs(n)
            return f"{sign}{n // SCALE}.{n % SCALE:0{DIGITS}d}"
        return [format_integer(self.lo), format_integer(self.hi)]

    def contains(self, value: int | str | Fraction) -> bool:
        q = Fraction(value)
        return self.lo * q.denominator <= q.numerator * SCALE <= self.hi * q.denominator


@lru_cache(maxsize=32768)
def exp_point(raw: int) -> I:
    if raw < 0:
        return exp_point(-raw).reciprocal()
    halvings = 0
    divisor = 1
    while raw > divisor * SCALE:
        halvings += 1
        divisor *= 2
    z = I.point(Fraction(raw, SCALE * divisor))
    total, term = I.point(1), I.point(1)
    for index in range(1, 61):
        term = term * z / index
        total = total + term
    # For 0 <= z <= 1, Taylor's remainder after degree 60 is < 3/61!.
    total = I(total.lo, total.hi + ceil_div(3 * SCALE, factorial(61)))
    for _ in range(halvings):
        total = total.square()
    return total


def exp(value: I) -> I:
    return I(exp_point(value.lo).lo, exp_point(value.hi).hi)


def atanh_small(z: I) -> I:
    if z.lo < 0 or z.hi > SCALE // 2:
        raise ValueError("series expects 0 <= z <= 1/2")
    zz = z.square()
    power = z
    total = I.point(0)
    terms = 80
    for index in range(terms):
        total = total + power / (2 * index + 1)
        power = power * zz
    tail = power / ((2 * terms + 1) * (1 - zz))
    return I(total.lo, total.hi + tail.hi)


@lru_cache(maxsize=1)
def ln2() -> I:
    return 2 * atanh_small(I.point(Fraction(1, 3)))


@lru_cache(maxsize=32768)
def log_point(raw: int) -> I:
    if raw <= 0:
        raise ValueError("log domain")
    value = Fraction(raw, SCALE)
    power = 0
    while value >= 2:
        value /= 2
        power += 1
    while value < 1:
        value *= 2
        power -= 1
    z = I.point((value - 1) / (value + 1))
    return 2 * atanh_small(z) + power * ln2()


def log(value: I) -> I:
    return I(log_point(value.lo).lo, log_point(value.hi).hi)


def sinh_cosh(value: I) -> tuple[I, I]:
    e = exp(value)
    inverse = e.reciprocal()
    return (e - inverse) / 2, (e + inverse) / 2


def entropy_cost(field: I) -> I:
    s, c = sinh_cosh(field)
    return field * s / c - log(c)


def check_library() -> None:
    # Exact algebra and series enclosures; decimal strings below are only
    # loose sanity brackets, not definitions of the transcendental values.
    assert (I.point(Fraction(1, 3)) * 3).contains(1)
    assert (I.hull(-2, 3).square()).contains(9)
    assert (I.hull(-2, -1).reciprocal()).contains(Fraction(-1, 2))
    assert exp(I.point(0)).contains(1)
    assert log(I.point(1)).contains(0)
    assert ln2().lo > I.point("0.693147180559945309417232121458176568").hi
    assert ln2().hi < I.point("0.693147180559945309417232121458176569").lo
    assert exp(I.point(2)).lo > 7 * SCALE
    assert exp(I.point(2)).hi < I.point("7.5").lo
    for value in ("0.1", "1", "2", "3", "6"):
        assert log(exp(I.point(value))).contains(value)


if __name__ == "__main__":
    check_library()
    print("PASS: exact arithmetic and transcendental enclosure checks")
