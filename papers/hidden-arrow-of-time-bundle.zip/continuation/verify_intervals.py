"""Exact rational enclosure tests and independent Decimal diagnostics.

Decimal transcendental comparisons are diagnostics, not the foundation of the
certificate. The proof bounds come from the series tails in intervals.py.
"""

from __future__ import annotations

from decimal import Decimal, localcontext
from fractions import Fraction as Q
import json
from pathlib import Path

from intervals import I, SCALE, check_library, exp, log


def main() -> None:
    check_library()
    exact_checks = 0
    values = [Q(i, j) for j in range(1, 8) for i in range(-9, 10)]
    for a in values:
        for b in values:
            ai, bi = I.point(a), I.point(b)
            for result, exact in ((ai + bi, a + b), (ai - bi, a - b), (ai * bi, a * b)):
                assert result.contains(exact)
                exact_checks += 1
            if b:
                assert (ai / bi).contains(a / b)
                exact_checks += 1
    wide = [(Q(i, 7), Q(i + width, 7)) for i in range(-5, 6) for width in (1, 3, 8)]
    for al, ah in wide:
        for bl, bh in wide:
            ai, bi = I.hull(al, ah), I.hull(bl, bh)
            for a in (al, ah):
                for b in (bl, bh):
                    for result, exact in ((ai + bi, a + b), (ai - bi, a - b), (ai * bi, a * b)):
                        assert result.contains(exact)
                        exact_checks += 1
                    if not bl <= 0 <= bh:
                        assert (ai / bi).contains(a / b)
                        exact_checks += 1
    diagnostics = 0
    with localcontext() as context:
        context.prec = 80
        for raw in ("-6", "-2", "-0.1", "0", "0.1", "0.7", "2", "3", "6", "12"):
            interval = exp(I.point(raw))
            expected = Decimal(raw).exp()
            assert Decimal(interval.lo) / SCALE < expected < Decimal(interval.hi) / SCALE or interval.contains(Q(expected))
            diagnostics += 1
        for raw in ("0.001", "0.1", "0.5", "1", "2", "3", "7", "200", "100000"):
            interval = log(I.point(raw))
            expected = Decimal(raw).ln()
            assert Decimal(interval.lo) / SCALE <= expected <= Decimal(interval.hi) / SCALE
            diagnostics += 1
    result = {
        "status": "PASS",
        "exact_rational_enclosure_checks": exact_checks,
        "independent_decimal_transcendental_diagnostics": diagnostics,
        "scope": "Arithmetic diagnostics supplement the written Taylor-remainder bounds; they are not formal verification or independent expert review.",
    }
    Path("results/interval_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
