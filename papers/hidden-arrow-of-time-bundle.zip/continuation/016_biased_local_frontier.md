# Where a weak hidden arrow first appears

Status: written local uniqueness and exact allocation proofs, with rational Taylor audits and separately labeled Decimal diagnostics. Research draft, not independent expert review or a verified novelty claim. All logarithms and rates use nats. The local validity interval is positive but not quantified.

## 1. An exact answer near maximum entropy

Fix a binary law \((p,q)\), where \(0<p\le1/2\), \(q=1-p\), and a memory \(k\ge3\). Every length-\(k\) window must have exactly the independent law \((p,q)^{\otimes k}\). Let \(M_{p,k}(\delta)\) be the largest observable time-reversal relative-entropy rate under entropy deficit at most \(\delta\). Set
\[
\mu=p^2,\qquad s=q-p,\qquad R=p^{k-2}q,
\qquad T_p(x)=\begin{pmatrix}x&p-x\\p-x&s+x\end{pmatrix},
\]
\[
f(x)=D\bigl(T_p(x)\Vert(p,q)\otimes(p,q)\bigr),\qquad
J(x,y)=(y-x)\{f'(y)-f'(x)\}.
\]
Define the scalar pair frontier
\[
A_p(c)=\max_{f(x)+f(y)\le c}J(x,y).
\]
For the small budgets used below, the feasible entries lie strictly between zero and \(p\).

**Local exact theorem.** For each fixed \(p\), there is \(c_0(p)>0\) such that, whenever \(0<\delta<Rc_0(p)\),
\[
\boxed{M_{p,k}(\delta)=R A_p(\delta/R).}
\]
Every optimizer puts its entire entropy deficit into exactly one pair of distinct reversed middle contexts of weight \(R\). Every other block is independent. The chosen pair has a unique unordered maximizing pair of parameters
\[
x_-(c)<\mu<x_+(c),\qquad c=\delta/R.
\]
Thus, once the context pair is chosen, the optimum is unique up to reversal. It is attained by a strictly positive kernel. For a strictly biased coin, there are \(\lfloor(k-1)/2\rfloor\) possible rarest context pairs: a single common symbol in a noncentral position, with all other symbols rare. At fairness, every nonpalindromic context pair has the same weight. The theorem does not claim uniqueness of the context choice.

The scalar optimum is analytic in \(c\) at zero and strictly convex for small positive \(c\). Write \(r=pq\). Its first terms are
\[
\boxed{A_p(c)=4c+\kappa_2c^2+\kappa_3c^3+O_p(c^4),}
\]
\[
\kappa_2=\frac{2(1-3r)^2}{3r^2}>0,\qquad
\kappa_3=\frac{\frac8{15}(1-5r+5r^2)^2-\frac29(1-3r)^4}{r^4}.
\]
Consequently
\[
\boxed{M_{p,k}(\delta)=4\delta+
 \frac{\kappa_2}{R}\delta^2+
 \frac{\kappa_3}{R^2}\delta^3+O_{p,k}(\delta^4).}
\]
The universal leading coefficient hides a strict preference for concentration at the next order. The theorem proves that preference exactly on a positive interval, not merely to second order. It does not solve the whole finite-budget frontier.

## 2. Reduction and a global straddling observation

Continuation 14's transport representation gives one scalar \(x_u\) per middle context \(u\), with weight \(r_u\). Each block contributes \(r_uf(x_u)\) to the entropy deficit. A reversed pair of distinct contexts contributes
\[
r_u\{D(T_p(x_u)\Vert T_p(x_{u^R}))+
 D(T_p(x_{u^R})\Vert T_p(x_u))\}=r_uJ(x_u,x_{u^R}).
\]
Palindromic contexts contribute zero to reversal. Every nonpalindromic context has weight at least \(R\). The derivative formulas are
\[
f'(x)=\log\frac{x(s+x)}{(p-x)^2},\qquad
f''(x)=\frac1x+\frac2{p-x}+\frac1{s+x}>0.
\]
The unique minimum is \(f(\mu)=f'(\mu)=0\). The two boundary costs are
\[
F_p=f(0)=s\log s-2q\log q,\qquad f(p)=H(p)\ge F_p.
\]
The last inequality is strict for \(p<1/2\); it also follows from the boundary-cost gap in Continuation 15.

For every \(0<c<F_p\), a scalar maximizer exists in the interior and uses the whole budget. It must straddle \(\mu\) strictly. Indeed, if two distinct parameters are on the same side of \(\mu\), replace the nearer one by the opposite-side parameter with the same entropy cost. Both the distance and the derivative gap increase strictly. Both inverse branches exist at that cost because it is below \(F_p\). If one parameter is exactly \(\mu\), moving it a distance \(\varepsilon\) to the opposite side costs only \(O(\varepsilon^2)\) and improves the objective to first order; adjusting the other parameter restores the budget at second order. Finally, moving a straddling endpoint farther from \(\mu\) strictly increases both objective and cost, so a slack budget cannot maximize. Equal parameters have zero objective and cannot maximize at positive budget.

This observation holds throughout the scalar subcritical range. It neither proves uniqueness there nor proves the global allocation formula outside the local interval.

## 3. Entropy coordinates give local uniqueness

The following argument works for any real analytic strictly convex scalar function with a nondegenerate minimum, after subtracting its value and translating its minimizer to \(\mu\). Introduce the signed entropy coordinate
\[
e=\operatorname{sgn}(x-\mu)\sqrt{2f(x)},\qquad x=\mu+v(e).
\]
This is an analytic diffeomorphism near zero: \(2f(\mu+t)/t^2\) is positive and analytic there. Put
\[
w(e)=f'(\mu+v(e))=\frac{e}{v'(e)}.
\]
For an ordered pair of entropy coordinates, write
\[
e_1=m-a,\qquad e_2=m+a,\qquad a\ge0.
\]
The exact cost is \(m^2+a^2\). The product of the two odd divided differences is analytic and even in \(a\), so
\[
J=\{v(m+a)-v(m-a)\}\{w(m+a)-w(m-a)\}
  =4a^2H(m,a^2),\qquad H(0,0)=1,
\]
for an analytic function \(H\). On the cost circle \(m^2+a^2=c\), the objective becomes
\[
G(c,m)=4(c-m^2)H(m,c-m^2),\qquad |m|\le\sqrt c.
\]
Its analytic extension to a neighborhood of \((0,0)\) satisfies
\[
G_{mm}(0,0)=-8.
\]
Hence \(G\) is strictly concave in \(m\) throughout the entire feasible interval for every sufficiently small positive \(c\). The endpoint values are zero, while the value at \(m=0\) is positive. The maximum is therefore unique and interior. The analytic implicit-function theorem gives its location \(m=m(c)\), analytic at zero, with \(m(0)=0\). Its value is analytic as well.

Strict convexity of \(f\) ensures that every feasible parameter tends to \(\mu\) as \(c\to0\), so this argument covers the entire feasible set, not just a neighborhood of a guessed optimizer. The value starts with \(4c\), so it is increasing near zero; the inequality-budget and equality-budget frontiers agree. Below we compute its positive quadratic coefficient, proving strict convexity of \(A_p\) near zero.

## 4. Coefficients and the almost symmetric maximizing pair

Write \(g_j=f^{(j)}(\mu)\) and
\[
v(e)=a_1e+a_2e^2+a_3e^3+O(e^4).
\]
Series inversion gives
\[
a_1=g_2^{-1/2},\quad a_2=-\frac{g_3}{6g_2^2},\quad
 a_3=\frac{5g_3^2}{72g_2^{7/2}}-\frac{g_4}{24g_2^{5/2}}.
\]
Expanding the divided differences,
\[
H(m,a^2)=1-\frac{2a_2}{a_1}m+
 \left(\frac{4a_2^2}{a_1^2}-\frac{2a_3}{a_1}\right)a^2
 +O(m^2,ma^2,a^4).
\]
Thus \(m(c)=-(a_2/a_1)c+O(c^2)\), and
\[
A_p(c)=4c+
 \left(\frac{20a_2^2}{a_1^2}-\frac{8a_3}{a_1}\right)c^2+O(c^3)
 =4c+\frac{g_4}{3g_2^2}c^2+O(c^3).
\]
The terms involving \(g_3^2\) cancel. This is an algebraic identity for the local symmetric Bregman objective, not a numerical observation.

For the next term, use the physical midpoint displacement \(b\) and half-separation \(h\):
\[
x_\pm=\mu+b\pm h.
\]
The order-\(c\) term of the midpoint is \(a_1m+a_2c=0\), so \(b=O(c^2)\). At \(b=0\),
\[
\begin{aligned}
C(0,h)&=f(\mu-h)+f(\mu+h)
 =g_2h^2+\frac{g_4}{12}h^4+\frac{g_6}{360}h^6+O(h^8),\\
J(0,h)&=4g_2h^2+\frac{2g_4}{3}h^4+
 \frac{g_6}{30}h^6+O(h^8).
\end{aligned}
\]
Here \(C\) denotes the pair cost. Along a fixed-cost curve, the derivative with respect to \(b\), evaluated at zero, is
\[
J_b-J_h\frac{C_b}{C_h}
 =\left(\frac{g_5}{3}-\frac{2g_3g_4}{3g_2}\right)h^4+O(h^6).
\]
The constrained second derivative tends to \(-8g_2\). Analyticity in \((c,b)\), obtained by solving for \(h^2\), therefore yields
\[
\boxed{b=B_pc^2+O(c^3),\qquad
 B_p=\frac{g_5-2g_3g_4/g_2}{24g_2^3}.}
\]
The optimizing shift changes the value only at order \(c^4\). Inverting \(C(0,h)=c\) in the preceding even series gives
\[
\boxed{\kappa_2=\frac{g_4}{3g_2^2},\qquad
 \kappa_3=\frac{g_6}{45g_2^3}-\frac{g_4^2}{18g_2^4}.}
\]
In particular, odd derivatives influence the maximizing pair before they influence these two value coefficients.

For the binary transport curve,
\[
g_2=r^{-2},\quad g_3=-s^2r^{-4},\quad
 g_4=2(1-3r)^2r^{-6},\quad
 g_6=24(1-5r+5r^2)^2r^{-10}.
\]
These give the stated coefficients and
\[
B_p=-\frac{s^2(1-6r^2)}{12r^2},\qquad
h=r\sqrt c+O_p(c^{3/2}).
\]
The entropy shares are less symmetric than the physical displacements:
\[
\boxed{f(x_-)-f(x_+)=\frac{s^2}{3r}c^{3/2}+O_p(c^{5/2}).}
\]
Indeed this difference is exactly \(-2m\sqrt{c-m^2}\), and the expansion of \(m(c)\) gives the formula. For a strictly biased coin, the rare-diagonal-depleting block receives more entropy deficit at every sufficiently small positive budget.

For example, when \(p=1/3\),
\[
\kappa_2=\frac32,\qquad\kappa_3=\frac{349}{120},\qquad
B_p=-\frac{19}{144},\qquad\frac{s^2}{3r}=\frac16.
\]
At memory three, \(R=2/9\), so
\[
M_{1/3,3}(\delta)=4\delta+\frac{27}{4}\delta^2+
 \frac{9423}{160}\delta^3+O(\delta^4).
\]
At fairness, \(\kappa_2=2/3\), \(\kappa_3=14/45\), and both the midpoint displacement and entropy imbalance vanish, agreeing with the original symmetric branch.

## 5. Why one rarest context pair gets everything

Choose \(c_0\) small enough that \(A_p\) is strictly increasing and strictly convex on \([0,c_0]\), with \(A_p(0)=0\). Then \(A_p(c)/c\) is strictly increasing for positive \(c\) in this interval. A pair of contexts of weight \(r_i\ge R\), using deficit \(d_i\), has rate at most \(r_iA_p(d_i/r_i)\). If \(d_i>0\), \(\delta/R<c_0\), and \(d_i\le\delta\), then
\[
r_iA_p(d_i/r_i)
 =d_i\frac{A_p(d_i/r_i)}{d_i/r_i}
 \le\frac{d_i}{\delta}\,R A_p(\delta/R).
\]
Summing over pairs proves the upper bound. Any deficit placed in palindromic contexts only reduces the sum of the useful \(d_i\)'s. Strictness shows that equality requires exactly one nonzero \(d_i=\delta\), with \(r_i=R\), and zero palindrome cost. The unique scalar pair constructs equality, giving the theorem and all its equality cases.

This resolves local strict-positive attainment even though the general nonuniform subcritical attainment question in Continuation 14 was left open. No assertion of that broader kind is needed.

## 6. A whole-branch result for the one-block family

There is also a monotonicity theorem that does not require small budgets, but applies to a narrower family. Put \(h=\mu-x\) on the rare-diagonal branch, \(0<h<\mu\), and \(F(h)=f(\mu-h)\). The convergent series is
\[
f''(\mu-h)=\sum_{n\ge0}a_nh^n,\qquad
a_n=p^{-2(n+1)}+q^{-2(n+1)}+2(-1)^n(pq)^{-(n+1)}.
\]
Every coefficient is nonnegative. For odd \(n\), it is the square
\((p^{-(n+1)}-q^{-(n+1)})^2\); for even \(n\), it is positive. Hence
\[
F(h)=\sum_{n\ge0}\frac{a_n}{(n+1)(n+2)}h^{n+2}.
\]
Against an independent reversed block, the rate is \(j(\mu-h)=hF'(h)\). The ratio \(hF'(h)/F(h)\) is the mean of the degrees under the normalized positive series weights. Its derivative with respect to \(\log h\) is the variance of those degrees. It is strictly positive, since at least the degree-two and degree-four coefficients are positive.

Thus the one-block rate-to-cost ratio increases strictly all the way to its boundary cost \(F_p\). At any common fixed deficit \(d\), the rate \(r_u j(x)\), with \(r_uf(x)=d\) on this branch, strictly decreases as the context weight increases, whenever the inverse solutions exist. The one-block scalar rate is also strictly superadditive below \(F_p\), by the same increasing-ratio argument.

This verifies the algebraic lead recorded in the previous handoff. It does not compare the rare-diagonal and off-diagonal one-block families, and it does not extend the two-block allocation theorem to all budgets.

## 7. Receipts, background, and remaining questions

Reproduce with `python3 continuation/biased_local_frontier.py`.

The receipt `results/biased_local_frontier.json` separates the following evidence:

- Seven rational parameter cases audit formal stationarity and the cubic value expansion using exact polynomial coefficients. They also check 280 nonnegative curvature-series coefficients.
- Twenty-four rational two-block sources check full stationary marginals and the transport entropy and reversal identities, with interval logarithms.
- Nine 85-digit Decimal Newton calculations check critical-point residuals and the predicted asymptotic coefficients. They are numerical diagnostics, not interval certificates of global optimality or of a validity cutoff.

The universal local theorem and all-budget one-block ratio theorem rest on the written analytic arguments. The finite audits corroborate formulas but do not replace those proofs. The previously explored 80-case one-block branch comparison remains unproved; no earlier theorem required correction in this continuation.

The divergence identity is standard information geometry. For background, Nielsen and Nock's \href{https://franknielsen.github.io/GeometryWMixtures-ICASSP2018.pdf}{\emph{On the Geometry of Mixtures of Prescribed Distributions}} identifies KL divergence on a fixed-component mixture family with the Bregman divergence generated by negative Shannon entropy. The present scalar identity is an elementary instance. This source does not establish priority for the constrained local extremal formula or the context allocation theorem, and no novelty claim follows from the focused search.

Open questions include an explicit \(c_0(p)\), the full biased-binary frontier and allocation, and nonuniform transition floors. This theorem and the earlier crossover theorem control opposite ends of the entropy range; the interior phase diagram remains unresolved.
