"""Certified scalar comparisons for the simultaneous bias/entropy-gap limit.

Rational probabilities, interval logarithms, and certified inverse brackets.
The global and uniform claims are analytic proofs in Continuation 15.
"""
from __future__ import annotations

from fractions import Fraction as Q
import json
from pathlib import Path

from intervals import I, log as ilog
from nonuniform_threshold import Source, cost, zero_cost, overlap, xlog


def f(p: Q, x: Q) -> I:
    return cost(p, p, x)


def j(p: Q, x: Q) -> I:
    # Keep tiny factors separate: rounding their product first unnecessarily
    # loses relative accuracy near the two-zero fair-coin boundary.
    slope = ilog(I.point(x)) + ilog(I.point(1 - 2 * p + x)) - 2 * ilog(I.point(p - x))
    return (x - p * p) * slope


def inverse(p: Q, target: I, identity: bool) -> tuple[Q, Q]:
    """Bracket small entry h: x=h on the left, x=p-h on the right."""
    evaluate = lambda h: f(p, p - h if identity else h)
    lo, hi = Q(0), p * (1 - p) if identity else p * p
    assert evaluate(lo).lo > target.hi and evaluate(hi).hi < target.lo
    for _ in range(100):
        mid = (lo + hi) / 2
        value = evaluate(mid)
        if value.lo > target.hi:
            lo = mid
        elif value.hi < target.lo:
            hi = mid
        else:
            # The existing endpoints remain a certified bracket. This only
            # occurs when the target uncertainty exceeds the next split.
            break
    assert evaluate(lo).lo > target.hi and evaluate(hi).hi < target.lo
    return lo, hi


def bracket_rate(p: Q, bracket: tuple[Q, Q], identity: bool) -> I:
    lo, hi = bracket
    low = j(p, p - hi if identity else hi)
    high = j(p, p - lo if identity else lo)
    return I(low.lo, high.hi)


def crossover_examples() -> list[dict]:
    result = []
    for k in (3, 4, 7):
        r0, c0 = Q(1, 2 ** (k - 1)), Q(1, 2 ** (k + 1))
        for lam in (Q(0), Q(1, 10), Q(1), Q(10), Q(100)):
            examples = []
            for power in (4, 8, 12, 16):
                z, s = Q(1, 10 ** power), lam / 10 ** power
                p = (1 - s) / 2
                r = p ** (k - 2) * (1 - p)
                target = f(p, z)
                eta = r * (zero_cost(p, p) - target)
                assert eta.lo > 0
                big_l = ilog(1 / eta)
                beta = s * big_l / eta
                anti = r * j(p, z)
                t = inverse(p, target, True)
                ident = r * bracket_rate(p, t, True)
                fair = 2 * c0 * (big_l + ilog(big_l) + ilog(I.point(r0)))
                anti_formula = fair - c0 * ilog(1 + 2 * r0 * beta)
                ident_formula = fair - 2 * c0 * ilog(1 + r0 * beta)
                gap_limit = c0 * ilog(I.point((1 + lam / 2) ** 2 / (1 + lam)))
                if lam:
                    assert (anti - ident).lo > 0
                else:
                    overlap(anti, ident)
                if k <= 4 and power == 4:
                    source = Source((p, 1 - p), k, (0, 1) + (0,) * (k - 1), z)
                    overlap(source.rate(), anti)
                    overlap(source.deficit(), r * target)
                examples.append({'z': str(z), 'bias_s': str(s), 'entropy_gap': eta.decimal_bounds(),
                                 'beta': beta.decimal_bounds(), 'anti_rate': anti.decimal_bounds(),
                                 'identity_small_entry_bracket': list(map(str, t)),
                                 'identity_rate': ident.decimal_bounds(),
                                 'anti_crossover_residual': (anti - anti_formula).decimal_bounds(),
                                 'identity_crossover_residual': (ident - ident_formula).decimal_bounds(),
                                 'branch_gap_minus_limit': (anti - ident - gap_limit).decimal_bounds()})
            result.append({'k': k, 'lambda_s_over_z': str(lam), 'branch_gap_limit': gap_limit.decimal_bounds(),
                           'examples': examples})
    return result


def power_examples() -> list[dict]:
    result = []
    k = 3
    r0, c0 = Q(1, 4), Q(1, 16)
    for alpha in (Q(1, 2), Q(1), Q(2)):
        examples = []
        for exponent in (4, 8, 12):
            eta = Q(1, 10 ** exponent)
            s = Q(1, 10 ** int(alpha * exponent))
            p = (1 - s) / 2
            r = p * (1 - p)
            target = zero_cost(p, p) - eta / r
            z, t = inverse(p, target, False), inverse(p, target, True)
            anti, ident = r * bracket_rate(p, z, False), r * bracket_rate(p, t, True)
            big_l = ilog(I.point(1 / eta))
            formula = (c0 * ((1 + alpha) * big_l + ilog(big_l) + ilog(I.point(r0 * (1 + alpha) / 4)))
                       if alpha <= 1 else 2 * c0 * (big_l + ilog(big_l) + ilog(I.point(r0))))
            examples.append({'eta': str(eta), 'bias_s': str(s), 'anti_rate': anti.decimal_bounds(),
                             'identity_rate': ident.decimal_bounds(), 'power_law_residual': (anti - formula).decimal_bounds(),
                             'anti_rate_over_log_gap': (anti / big_l).decimal_bounds(),
                             'anti_small_entry_bracket': list(map(str, z))})
        result.append({'alpha': str(alpha), 'leading_coefficient': str(c0 * (1 + min(alpha, 1))),
                       'examples': examples})
    return result


def elementary_audit() -> dict:
    cases = 0
    for p in (Q(1, 3), Q(2, 5), Q(49, 100), Q(499, 1000), Q(1, 2)):
        q, s = 1 - p, 1 - 2 * p
        boundary_gap = -xlog(p) - xlog(q) - zero_cost(p, p)
        overlap(boundary_gap, xlog(q) - xlog(p) - xlog(s))
        for h in (Q(1, 1000), Q(1, 10 ** 6), Q(1, 10 ** 9)):
            for x in (h, p - h):
                # Exact derivative sign needed for decreasing rate as the
                # singular entry is increased toward the independent block.
                fp = ilog(I.point(x)) + ilog(I.point(s + x)) - 2 * ilog(I.point(p - x))
                fpp = 1 / x + 2 / (p - x) + 1 / (s + x)
                jp = fp + (x - p * p) * fpp
                weight_derivative = j(p, x) - f(p, x) * jp / fp
                assert weight_derivative.hi < 0
                cases += 1
    return {'certified_weight_derivative_examples': cases,
            'boundary_gap_identity_cases': 5,
            'scope': 'Finite examples audit the algebra; uniform eventual monotonicity is proved analytically.'}


def main() -> None:
    receipt = {'status': 'exact intervals and rational root brackets; global uniformity rests on the written proof',
               'elementary': elementary_audit(), 'crossover': crossover_examples(), 'power_paths': power_examples(),
               'limits': ['not a numerical global optimizer', 'no explicit uniform remainder constant',
                          'fixed memory only', 'no independent expert review or verified novelty']}
    Path('results/bias_crossover.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'crossover_family_cases': sum(len(x['examples']) for x in receipt['crossover']),
                      'power_path_cases': sum(len(x['examples']) for x in receipt['power_paths']),
                      **receipt['elementary']}, indent=2))


if __name__ == '__main__':
    main()
