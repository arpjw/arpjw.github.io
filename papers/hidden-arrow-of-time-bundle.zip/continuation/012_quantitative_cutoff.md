# Continuation 12: an explicit validity interval

Status: a quantitative strengthening of Continuation 11, using a written cycle-decomposition argument and exact finite checks. The bounds are deliberately conservative, not estimates of the actual phase boundary. Independent expert review and novelty verification remain open.

## 1. The result

Continuation 11 identified the unique critical boundary source for sufficiently small fairness errors, but did not quantify that phrase at memory four and above. We now give an explicit interval at every memory.

Let \(k\ge3\), \(N=2^{k-1}\), and let \(d_k\) be the denominator of the known coefficient \(\alpha_k\) in lowest terms. Define

\[
\boxed{\tau_{\rm safe}(k)=2^{-k-32d_k4^{k-1}}.}
\]

For every \(0<\tau\le\tau_{\rm safe}(k)\), the exact critical source, uniqueness statement, and entropy formula of Continuation 11 hold. Thus its threshold expansion through quadratic order is valid on a specified positive interval.

This universal interval is tiny: at memory four it only gives \(2^{-6148}\). An exact finite refinement improves that case to

\[
\boxed{0<\tau\le2^{-39}\qquad(k=4).}
\]

Neither endpoint is claimed sharp. At memory three, the previously established range is much larger and should continue to be used. The new result removes an existence-only qualification at larger memory; it does not locate the next phase change.

The proof has two ingredients: a rational gap for stationary perturbation polytopes, and entropy estimates whose constants do not grow with memory after tolerance is measured relative to the uniform word mass.

## 2. A two-cycle description of stationary perturbations

Let \(G\) be a directed graph with \(N\) vertices and at least one edge. Replace each edge by a forward arc with sign \(+1\) and a backward arc with sign \(-1\), retaining parallel arcs and loops. Consider

\[
\mathcal V=\{v:Dv=0,\ \sum_e v_e=0,\ \|v\|_1\le2\},
\]

where \(D\) is the incidence matrix of the original graph.

Every \(v\in\mathcal V\) lifts to a nonnegative circulation on the signed graph with total arc mass two and zero signed mass. Start with its positive and negative parts. If their total mass is less than two, add equal mass to the forward and backward copies of any edge. This changes neither the projected vector nor signed mass.

Decompose the lifted circulation into simple directed cycles. A cycle has length \(L\le N\), signed mass \(d\), and an integer projected edge vector \(c\). Notice that \(L\) and \(d\) have the same parity.

Cycles of zero signed mass can be normalized individually. Cycles of positive and negative signed mass can be paired by matching their total signed masses. Consequently \(\mathcal V\) is the convex hull of the following finite family of projected vectors:

\[
\frac{2c}{L}\quad(d=0),
\]

and

\[
\frac{2(|d_-|c_+ + d_+c_-)}{|d_-|L_+ + d_+L_-}
\quad(d_+>0>d_-).
\]

For completeness, match amounts of positive and negative signed mass in a finite transport table. Each matched amount multiplies \(c_+/d_+ + c_-/|d_-|\). After normalization to total arc mass two, these are exactly the displayed pair vectors. The normalization weights, together with those of zero-mass cycles, sum to one because the original total arc mass was two. This proves the convex-hull assertion even when cycles overlap or projection cancels edges.

Every generator has an integer common denominator at most \(N^2\). For a zero-mass cycle, \(L\) is even. For a paired generator, its displayed denominator is even, since each \(L_\pm\) has the parity of \(d_\pm\). Cancelling the factor two leaves a denominator at most

\[
\frac{|d_-|L_+ + d_+L_-}{2}\le N^2.
\]

The generators need not all be vertices. Their bounded denominators and convex-hull property are what the argument needs.

## 3. Quantitative objective gaps

Apply the lemma to the binary de Bruijn graph with \(N=2^{k-1}\) vertices. The missing-word functional \(\ell_w\) has integer coefficients. Write the global optimum as \(\alpha=\alpha_k=p/d\) in lowest terms and set

\[
g=\frac1{dN^2},\qquad c=\frac1{4dN^2}.
\]

Any generator whose objective is smaller than \(\alpha\) has gap at least \(g\): subtract two rational numbers with denominators at most \(N^2\) and exactly \(d\), respectively.

If a word class has optimum smaller than \(\alpha\), every generator has this gap, and hence

\[
\ell_w(v)\le\alpha-g\quad\text{for every }v\in\mathcal V.
\]

If instead \(\ell_w\) has a unique maximizing vector \(v_*\), every maximizing generator projects to \(v_*\). All generators have L1 norm at most two, so their distances from \(v_*\) are at most four. Taking convex combinations gives the quantitative sharpness bound

\[
\boxed{\alpha-\ell_w(v)\ge c\|v-v_*\|_1.}
\]

Continuation 11 proves the needed uniqueness for both maximizing word classes at every \(k\ge4\). Memory three is handled by its earlier exact solution.

## 4. Entropy estimates at the right scale

Put \(h=2^{-k}\), \(x=\tau/h\), and \(S=\log(h/\tau)\). For a feasible marginal direction \(v\), write

\[
a=\ell_w(v),\qquad m_z=\sum_b v_{bz},\qquad s=m_u.
\]

For a zero-word face, \(0\le a\le1\). Since \(v\) has zero mass and TV norm at most one, every coordinate of \(v\) and every context mass \(m_z\) has magnitude at most one. Both L1 norms are at most two.

Let \(F_{w,\tau}(v)\) be the minimum entropy deficit with marginal \(U+\tau v\) and missing word \(w\), as in Continuation 11. Its exact product-block formula yields, uniformly for \(x\le1/4\),

\[
F_{w,\tau}(v)=2h\log2-\tau Sa
+\tau\{s\log2+a\log a-a\}+R,
\qquad |R|\le4\tau^2/h.
\]

Use \(a\log a=0\) at zero. To prove the remainder bound, expand only the nonsingular terms around \(h\) and \(2h\). For \(|t|<b\), the first-order Taylor error of \(f(b+t)= (b+t)\log(b+t)\) is at most \(t^2/[2(b-|t|)]\). The squared direction sums satisfy

\[
\sum v_e^2\le2,\quad\sum m_z^2\le2,\quad R_0^2+C_0^2\le2,\quad s^2\le1,
\]

where \(R_0,C_0\) are the two individual marginal slopes appearing with minus signs in the exact formula. The total remainder is therefore at most

\[
\frac{\tau^2}{h}\left(\frac8{3}+\frac6{7}\right)
=\frac{74\tau^2}{21h}<\frac{4\tau^2}{h}.
\]

There is also a uniform gradient bound at a maximizing vector, where \(a=\alpha\ge1/2\). On stationary zero-mass directions, the gradient divided by \(\tau\) has the form

\[
-S\ell_w+(\log\alpha)\ell_w+(\log2)s+E.
\]

Here \(s\) denotes the linear context-mass functional. An ambient coefficient vector for the error satisfies

\[
\|E\|_\infty\le\frac{3x}{1-x}+\frac{2x}{2-x}\le\frac97.
\]

Indeed, differentiating the regular Taylor remainders leaves three possible terms of the form \(\log(1+xv_e)\), and two of the form \(\log(1+xm_z/2)\), for each coordinate. The inequality \(|\log(1+t)|\le |t|/(1-|t|)\) gives the bound. Since both \(\ell_w\) and the context functional have coefficients bounded by one,

\[
|DF_{w,\tau}(v_*)[z]+\tau S\ell_w(z)|
\le\tau M\|z\|_1,
\quad M\le |\log\alpha|+\log2+9/7<4.
\]

These estimates involve the relative tolerance \(x\), not a constant proportional to the memory length.

## 5. Proving the explicit interval

Assume first \(k\ge4\), and let \(K=32dN^2\). If \(0<\tau\le h2^{-K}\), then

\[
S\ge K\log2>K/2=16dN^2.
\]

The sharpness inequality and the gradient estimate imply that every nonzero feasible displacement \(z=v-v_*\) in a maximizing word class obeys

\[
DF_{w,\tau}(v_*)[z]\ge\tau(cS-M)\|z\|_1>0.
\]

The function \(F_{w,\tau}\) is convex, as proved in Continuation 11. Thus \(v_*\) is its unique exact minimizer for each maximizing class throughout the stated interval.

Next compare all other word classes. Let the selected source have context slope \(-\rho\), where \(\rho=1-\alpha\) for odd memory and \(\rho=\alpha-1/2\) for even memory. The function \(a\log a-a\) decreases on \([0,1]\). Since \(s\ge-1\) and \(a\le\alpha-g\), the uniform expansion gives

\[
F_{w,\tau}(v)-F_{*,\tau}(v_*)
\ge\tau\{gS-(1-\rho)\log2-8x\}>0.
\]

The last inequality follows from \(gS>16\), \(\log2<1\), and \(x\le1/4\).

There remain the two maximizing classes. Their exact minimizers have context slopes \(+\rho\) and \(-\rho\), so their entropy difference is at least

\[
\tau\{2\rho\log2-8x\}>0
\quad\text{whenever }x\le\rho/16.
\]

Our cutoff satisfies this condition. Indeed \(\rho\ge1/[2(k+1)]\), \(K\ge k+5\), and \(k+1\le2^k\), whence

\[
x\le2^{-K}\le\frac1{32(k+1)}\le\frac\rho{16}.
\]

It also ensures \(x\le1/4\). This selects the negative-context source uniquely, up to complement and reversal, and excludes every other missing-word face. The boundary-threshold argument of Continuation 11 then identifies its deficit with \(T_k(\tau)\). At \(k=3\), the proposed tiny interval lies within the earlier exact regime, so the same stated cutoff is valid there as well.

## 6. A sharper exact four-bit interval

For \(k=4\), enumerate all simple cycles of the signed graph. There are 122 cycles, producing 2,722 balanced generators before deduplication and 2,505 distinct projected vectors. Exact rational evaluation over these generators gives:

- Both globally maximizing word classes have a unique maximizing vector and sharpness constant \(c=1/22\) in L1 distance.
- The largest coefficient among all other word classes is \(5/8\), so their gap from \(\alpha=2/3\) is \(1/24\).

The convex-hull lemma extends these finite inequalities to the whole polytope. No numerical optimization is used.

Now take \(x\le2^{-35}\), equivalently \(\tau\le2^{-39}\). The sharper gradient estimate is

\[
M\le\log3+\frac{3x}{1-x}+\frac{2x}{2-x}
<\frac{11}{10}+\frac1{1000}.
\]

The interval library certifies \(\log2>693/1000\) and \(\log3<11/10\). Therefore

\[
cS\ge\frac{35\log2}{22}>
\frac{35\cdot693}{22000}=1.1025>M.
\]

The other-class comparison also stays strictly positive, using \(\rho=1/6\), \(g=1/24\), and \(\log2<7/10\):

\[
gS-(1-\rho)\log2-8x
>\frac{35\cdot693}{24000}-\frac7{12}-8\cdot2^{-35}>0.
\]

Finally \(2^{-35}<\rho/16\), settling the remaining maximizing class. Every bound is uniform over the entire interval, so this is not merely a certificate at its upper endpoint.

## 7. Reproduction and remaining questions

Run `python3 continuation/quantitative_cutoff.py`. It uses the standard library and existing integer interval arithmetic. Its receipt is `results/quantitative_cutoff.json`.

The script independently recovers all missing-word coefficients at memories three and four from cycle generators, matching the saved LP certificates. It checks stationarity, zero mass, the TV bound, common denominators, coefficient gaps, and the exact sharpness constants. It also verifies the arithmetic of the universal cutoff at several memories through 101 without materializing impossibly small floating-point numbers.

The arbitrary-memory theorem depends on the written decomposition and uniform entropy estimates, together with the earlier equality classification. The finite generator audit corroborates that proof; it does not establish an infinite claim by extrapolation.

No previous theorem needed correction. Continuation 11's unquantified cutoff is strengthened here. Finding useful larger validity intervals or the next phase changes remains open. The larger-alphabet threshold is still an unverified continuation direction. These are research drafts, with independent expert review and novelty verification unresolved.
