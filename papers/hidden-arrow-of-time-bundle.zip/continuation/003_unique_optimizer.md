# Continuation 3: uniqueness of the unequal global optimizer

Status: all three finite interval covers passed. Together with the analytic infinite-tail argument below, they give a computer-assisted proof of uniqueness of the unequal global optimizer. This is not proof-assistant formalization, independent expert review, or an established novelty claim.

## The conclusion

Write `r_t` for the unique global symmetry threshold proved and enclosed in Continuation 1. For the original uncapped two-variable problem, the new conclusion is:

- For `0<r<r_t`, the symmetric pair is the unique ordered maximizer.
- At `r=r_t`, there are exactly two ordered maximizing pairs: the symmetric pair and one unequal pair.
- For `r_t<r<log2`, there is exactly one ordered maximizing pair, and it is unequal.
- The envelope `F` is strictly convex. It is analytic on each side of the transition and has a strict upward jump in its derivative at the transition.

Here ordered means `x>=y>=0`. Swapping coordinates, changing the overall sign, or choosing a different reversed context pair produces the expected symmetries of the original Markov construction.

This does **not** prove that the stationary curve has exactly one minimum over its entire domain. We bypass that stronger question by separating all candidates that could be global maximizers.

## 1. Geometry of the stationary curve

Use the definitions from Continuation 1:

\[
u=A(x),\quad v=A(y),\quad t=u+v,\quad z=u-v,
\]

\[
c(w)=w\tanh w-\log\cosh w,\qquad
R(t,z)=c((t+z)/2)+c((t-z)/2).
\]

For clarity write `H(t,z)=sinh(z)/z-B(t)cosh(z)-C(t)`, so subscripts on `H` below denote partial derivatives. Every unequal stationary point lies on the unique analytic curve `z=z(t)`, `t>t_c`. We know `z'(t)>0`, `H_z<0`, and `H_t>0` at its root. In particular `u(t)=(t+z(t))/2` strictly increases.

Let `rho(t)=R(t,z(t))`. The constrained objective, regarded locally as a function of `z` with cost fixed, has derivative with the same sign as `H(t,z)`. More exactly, with `alpha=sech^2 u`, `beta=sech^2 v`, and `R_t>0`,

\[
\left.\frac{dJ}{dz}\right|_R
=\frac{\alpha\beta\,t\sinh^2(t)\,z}
 {2R_t(\cosh t+\cosh z)}H(t,z).
\]

To verify this identity, write `J=(tanh u+tanh v)(u+v)`. Then `J_u=t alpha+x+y`, `J_v=t beta+x+y`, `R_u=u alpha`, and `R_v=v beta`. The determinant `J_z R_t-J_t R_z` equals `(J_u R_v-J_v R_u)/2`; substitution yields the displayed factor.

Along a fixed-cost curve, `dt/dz=-R_z/R_t`. Differentiating `H` at a stationary point gives

\[
\left.\frac{dH}{dz}\right|_R
=H_z-H_tR_z/R_t
=\frac{H_z}{R_t}\rho'(t).
\]

All factors except `H_z` and `rho'` are positive. Therefore:

- If `rho'(t)<0`, the unequal stationary point is a strict local minimum at fixed cost.
- If `rho'(t)>0`, it is a strict local maximum.

This criterion identifies which parts of the stationary curve can matter globally.

## 2. An analytic proof that the tail is increasing

We prove `rho'(t)>0` for every `t>=6`. This handles an infinite interval without numerical truncation.

### 2.1 First force the smaller field below one

For `t>=4`, put `q=exp(-2t)`. Using `7<e^2<37/5`, we have `q<1/2401` and the elementary bounds

\[
B(t)\le\frac{1+3q}{t}+5q,\qquad C(t)<4e^{-t}.
\]

Also `tanh(t-2)>=1-2e^4 q` and `cosh(t-2)>=e^{t-2}/2`. Consequently

\[
\frac{H(t,t-2)}{\cosh(t-2)}
\ge\frac{2}{t(t-2)}
-q\left[\frac{2e^4}{t-2}+\frac3t+65\right].
\]

Multiplying by `t(t-2)`, the right side is strictly greater than

\[
2-e^{-2t}(113t+65t^2)>2-1492/2401>0.
\]

The last inequality uses the monotonic decrease of `t exp(-2t)` and `t^2 exp(-2t)` for `t>=4`. Since `H(t,z)` is positive before its unique positive root in `z`, this proves `z(t)>t-2`, hence `0<v(t)<1` for all `t>=4`.

### 2.2 Use the stationary equation to bound the small field

Put `alpha=sech^2 u`, `beta=sech^2 v`, `D=tanh u+tanh v`. The stationary equation is equivalent to

\[
v=\alpha L(u,v),\qquad
L(u,v)=\frac{u}{\beta}+\frac{u^2-v^2}{D}.
\]

For `t>=6`, the preceding step gives `u=t-v>5`. On `u>=5, 0<v<1`,

\[
D>3/4,\quad D<2,\quad \cosh^2v<3,
\quad \cosh v\sinh v<2.
\]

It follows that

\[
\frac{12}{25}u^2\le L<2u^2,
\qquad v<2u^2\alpha.
\]

The partial derivatives are

\[
L_u=\frac1\beta+\frac{2u}{D}
-\frac{(u^2-v^2)\alpha}{D^2},
\]

\[
L_v=2u\cosh v\sinh v-\frac{2v}{D}
-\frac{(u^2-v^2)\beta}{D^2}.
\]

Direct bounds give `|L_u|<4u` and `|L_v|<3u^2`. To check the constants, use

\[
u^j\alpha\le4u^j e^{-2u}
\le 4\,5^j e^{-10}<\frac{4\,5^j}{16807}
\quad (j=2,3).
\]

For example `|L_v|<=4u+8/3+(16/9)u^2<3u^2` for `u>=5`. Similarly `|L_u|<=3+(8/3)u+(16/9)u^2 alpha<4u`.

Thus `1-alpha L_v>9/10`, and differentiating `v=alpha L` with respect to `u` gives

\[
\left|\frac{dv}{du}\right|
\le\frac{v\,[2+|L_u|/L]}{9/10}
\le\frac{110}{27}v<5v.
\]

Finally,

\[
\frac{d}{du}[c(u)+c(v(u))]
=u\alpha+v\beta\frac{dv}{du}
>u\alpha-5v^2
>u\alpha(1-20u^3\alpha)>0,
\]

because `20u^3 alpha<10000/16807<1`. As `u(t)` increases, this proves `rho'(t)>0` for all `t>=6`. The same bounds imply `v->0` and `u->infinity`, hence `rho(t)->log2` as `t->infinity`.

## 3. The finite interval certificate

The remaining assertions are deliberately weaker than proving the entire curve has only one fold:

1. `rho'(t)<0` for `t_c<t<=2.06`.
2. `rho(t)<0.663391796` for `2.06<=t<=2.1`.
3. `rho'(t)>0` for `2.1<=t<=6`.

The script `continuation/uniqueness_certificate.py` uses the existing 40-decimal outward-rounded integer interval library. Every accepted subinterval is recorded, and an exact rational tiling check verifies that there are no gaps in each finite cover.

The near-critical derivative is evaluated in `w=z^2` coordinates, which remove the apparent singularity of `z'(t)`. Define

\[
D(w)=\cosh\sqrt w,\quad Q(w)=\frac{\sinh\sqrt w}{\sqrt w},
\quad Q'(w)=\sum_{n\ge0}\frac{(n+1)w^n}{(2n+3)!}.
\]

Then `K(t,w)=Q(w)-B(t)D(w)-C(t)` has

\[
K_w=Q'(w)-B(t)Q(w)/2,\qquad
w'=-K_t/K_w.
\]

All three positive series are regular at `w=0`. On `0<=w<=1`, truncating them at `n=29` leaves each tail below `100/60!`. The script encloses these tails explicitly.

For the increasing region it uses the implicit equation `G(u,v)=v-alpha L=0`, computes `dv/du=-G_u/G_v`, and encloses the derivative of the cost directly. If a rectangle proves `G_u>0` and `G_v>0`, it first proves that `v` decreases on that rectangle's branch segment, then tightens its range using the two endpoint enclosures. This tightening is a consequence of an accepted sign bound, not an assumption from a plot.

The certificate will fail rather than accept an unresolved sign or incomplete cover. The infinite tail uses Section 2, not floating-point sampling.

All covers passed. The negative-derivative cover used 175 nodes and 88 accepted intervals; the below-transition cover used 9,913 nodes and 4,957 intervals; the positive-derivative cover used 2,301 nodes and 1,151 intervals. See `results/uniqueness_certificate.json` for every interval and its outward-rounded bound. The total is 6,196 accepted intervals, plus the direct near-critical enclosure.

The earlier critical-budget enclosure gives `rho(t_c)<0.664<log2`. The first segment decreases from that value, the middle segment stays below the transition, and the upper segment increases to `log2` without reaching it. Therefore every unequal stationary point, on the entire curve, has cost strictly below `log2`.

## 4. Why this proves uniqueness globally

The previous transition certificate gives `r_t>=0.663391796`. Hence a global unequal maximizer at or above the transition cannot lie in the middle interval. It cannot lie in the first interval because those stationary points are strict local minima. It must lie on `t>=2.1`.

The finite cover and tail proof show that `rho` is strictly increasing there. Its value at `2.1` is below the transition budget, and its limit is `log2`. Thus for every `r in [r_t,log2)` there is exactly one possible unequal global maximizing pair. Above the transition it must maximize because symmetry is suboptimal. At the transition, the original coexistence argument supplies an unequal maximizer, so there is exactly one unequal pair alongside symmetry.

Below the transition, there can be no unequal global maximizer tied with symmetry. If one existed at an interior budget `r<r_t`, hold its allocation fraction fixed while increasing the budget slightly. Its budget derivative is the unequal multiplier `lambda>S'(r)`, so it would beat symmetry immediately to the right, contradicting the definition of `r_t`.

## 5. Strict convexity and the jump in slope

On `r>r_t`, the unique optimizer depends analytically on `r` by the implicit function theorem, because `rho'(t)>0`. Its envelope derivative is the multiplier `lambda(t)`. Continuation 1 proves `lambda(t)` strictly increases, so `F` is strictly convex above the transition.

Below the transition, `F=S`, and `S'(r)=2+2 sinh(t_0)/t_0` strictly increases. At the transition, the right derivative is strictly greater than the left derivative because `lambda>S'(r_t)`. These statements give strict convexity of the entire envelope, with one upward corner.

The uniqueness result is computer-assisted on a finite interval and analytic on the infinite tail. It does not turn the still-unproved one-fold conjecture into a theorem, nor settle the low-noise capped allocation problem.

Continuation 4 subsequently resolves that allocation problem using this uniqueness result, rearrangement, and a marginal-value comparison. The first-order jump is enclosed in `results/jump_certificate.json`: the bias-magnitude difference jumps from zero to an interval contained in `[0.3573645126,0.3573690528]`, and the derivative of `F` jumps upward by an amount in `[1.1555315596,1.1555504276]`.
