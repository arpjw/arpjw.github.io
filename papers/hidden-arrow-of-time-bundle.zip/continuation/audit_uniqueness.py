"""Cross-coordinate derivative checks and exact tail-constant arithmetic."""

from fractions import Fraction as Q
import json
from pathlib import Path

from intervals import I
from branch_certificate import branch_derivative, root_z
from uniqueness_certificate import implicit_fields, regular_cost_derivative


def main() -> None:
    checks = 0
    for raw in ("2.02", "2.04", "2.06", "2.09", "2.1", "2.2", "3", "4", "5", "6"):
        t, z = I.point(raw), root_z(Q(raw))
        old = branch_derivative(t, z)
        u, v = (t + z) / 2, (t - z) / 2
        gu, gv, drdu = implicit_fields(u, v)
        transformed = drdu / (1 - gu / gv)
        assert transformed.lo <= old.hi and old.lo <= transformed.hi
        checks += 1
        if z.square().hi <= I.point(1).hi:
            regular = regular_cost_derivative(t, z.square())
            assert regular.lo <= old.hi and old.lo <= regular.hi
            checks += 1
    margins = {
        "positive_H_tail_margin": 2 - Q(1492, 2401),
        "cosh_squared_bound_margin": 3 - (Q(37, 5) + 2 + Q(1, 7)) / 4,
        "cosh_sinh_bound_margin": 2 - Q(37, 20),
        "L_u_bound_margin": 4 - (Q(3, 5) + Q(8, 3) + Q(16, 9) * Q(20, 16807)),
        "L_v_bound_margin": 3 - (Q(4, 5) + Q(8, 75) + Q(16, 9)),
        "implicit_denominator_margin": Q(1, 10) - Q(300, 16807),
        "v_derivative_bound_margin": 5 - Q(110, 27),
        "positive_cost_derivative_margin": 1 - Q(10000, 16807),
    }
    assert all(value > 0 for value in margins.values())
    report = {
        "status": "PASS",
        "cross_coordinate_derivative_enclosure_checks": checks,
        "exact_positive_tail_margins": {key: str(value) for key, value in margins.items()},
        "scope": "Checks of equivalent coordinate formulas and exact constants supplement the written tail proof and full interval cover; no independent expert review is implied.",
    }
    Path("results/uniqueness_audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
