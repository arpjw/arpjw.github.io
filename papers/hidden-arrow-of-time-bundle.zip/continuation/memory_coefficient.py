"""Exact primal/dual certificates for the near-fairness logarithmic coefficient.

Generation optionally uses SciPy/HiGHS. Verification uses only the standard
library and exact Fractions. Numerical solver statuses are never proof evidence.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as Q
import json
from math import lcm
from pathlib import Path
from time import perf_counter


RESULT = Path("results/memory_coefficient.json")


def words(k: int) -> list[str]:
    return [f"{i:0{k}b}" for i in range(2**k)]


def complement(word: str) -> str:
    return word.translate(str.maketrans("01", "10"))


def representative(word: str) -> str:
    return min(word, word[::-1], complement(word), complement(word[::-1]))


def objective(word: str) -> dict[str, Q]:
    a, u, b = word[0], word[1:-1], word[-1]
    result = Counter({u + complement(b): Q(1)})
    result[a + u] -= 1
    return {key: value for key, value in result.items() if value}


def check_certificate(record: dict) -> Q:
    k, missing = record["k"], record["missing_word"]
    assert len(missing) == k + 1 and missing != missing[::-1]
    edges, nodes = words(k), words(k-1)
    direction = {edge: Q(value) for edge, value in record["direction"].items()}
    potential = {node: Q(value) for node, value in record["potential"].items()}
    assert direction.keys() <= set(edges) and potential.keys() <= set(nodes)
    mass, radius = Q(record["mass_multiplier"]), Q(record["dual_radius"])
    assert radius >= 0
    # Clear denominators once, so the large finite audit uses exact integers.
    primal_scale = lcm(*(value.denominator for value in direction.values()))
    direction_int = {edge: value.numerator * (primal_scale // value.denominator) for edge, value in direction.items()}
    assert sum(direction_int.values()) == 0
    assert sum(abs(value) for value in direction_int.values()) <= 2*primal_scale
    balance = Counter()
    for edge, value in direction_int.items():
        balance[edge[:-1]] += value
        balance[edge[1:]] -= value
    assert all(value == 0 for value in balance.values())
    dual_scale = lcm(mass.denominator, radius.denominator, *(value.denominator for value in potential.values()))
    potential_int = {node: value.numerator * (dual_scale // value.denominator) for node, value in potential.items()}
    mass_int = mass.numerator * (dual_scale // mass.denominator)
    radius_int = radius.numerator * (dual_scale // radius.denominator)
    ell = objective(missing)
    for edge in edges:
        residual = int(ell.get(edge, 0))*dual_scale + potential_int.get(edge[:-1], 0) - potential_int.get(edge[1:], 0) + mass_int
        assert abs(residual) <= radius_int, (missing, edge, residual, radius_int)
    primal = Q(sum(int(value) * direction_int.get(edge, 0) for edge, value in ell.items()), primal_scale)
    assert primal == 2 * radius == Q(record["coefficient"]), (missing, primal, radius)
    return primal


def generate(max_k: int) -> dict:
    import numpy as np
    import scipy
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix, hstack, vstack

    all_records, table = [], []
    for k in range(3, max_k + 1):
        started = perf_counter()
        edges, nodes = words(k), words(k-1)
        edge_index = {edge: i for i, edge in enumerate(edges)}
        node_index = {node: i for i, node in enumerate(nodes)}
        rows, cols, values = [], [], []
        for j, edge in enumerate(edges):
            rows.extend((node_index[edge[:-1]], node_index[edge[1:]]))
            cols.extend((j, j))
            values.extend((1., -1.))
        incidence = coo_matrix((values, (rows, cols)), shape=(len(nodes), len(edges))).tocsr()
        signed = hstack((incidence, -incidence), format="csr")
        mass_row = coo_matrix(np.array([1.] * len(edges) + [-1.] * len(edges)).reshape(1,-1))
        equalities = vstack((signed, mass_row), format="csr")
        representatives = sorted({representative(w) for w in words(k+1) if w != w[::-1]})
        records = []
        for missing in representatives:
            ell = objective(missing)
            target = np.array([float(ell.get(edge, 0)) for edge in edges])
            solution = linprog(
                np.concatenate((-target, target)), A_ub=np.ones((1, 2*len(edges))),
                b_ub=[2.], A_eq=equalities, b_eq=np.zeros(len(nodes)+1),
                bounds=(0, None), method="highs",
            )
            assert solution.success, solution.message
            rational = lambda x: Q(float(x)).limit_denominator(100000)
            direction = {edge: rational(solution.x[j] - solution.x[j+len(edges)]) for j, edge in enumerate(edges)}
            potential = {node: rational(solution.eqlin.marginals[j]) for j, node in enumerate(nodes)}
            radius = -rational(solution.ineqlin.marginals[0])
            record = {
                "k": k, "missing_word": missing, "coefficient": str(2*radius),
                "direction": {e: str(v) for e, v in direction.items() if v},
                "potential": {n: str(v) for n, v in potential.items() if v},
                "mass_multiplier": str(rational(solution.eqlin.marginals[-1])),
                "dual_radius": str(radius),
            }
            check_certificate(record)
            records.append(record)
        maximum = max(Q(record["coefficient"]) for record in records)
        maximizers = [record["missing_word"] for record in records if Q(record["coefficient"]) == maximum]
        row = {
            "k": k, "maximum_coefficient": str(maximum),
            "representative_count": len(records), "maximizing_representatives": maximizers,
            "coefficient_histogram_over_representatives": dict(Counter(record["coefficient"] for record in records)),
        }
        table.append(row)
        all_records.extend(records)
        print(json.dumps({**row, "generation_seconds": perf_counter()-started}), flush=True)
    return {
        "status": "All listed primal and dual witnesses pass exact rational verification",
        "definition": "max ell(v) subject to stationary incidence balance, zero mass, and sum(abs(v)) <= 2; ell(v)=v[u(1-b)]-v[au] for missing word aub",
        "generator": {"solver": "scipy.optimize.linprog, HiGHS", "scipy_version": scipy.__version__, "rational_denominator_limit": 100000},
        "table": table, "certificates": all_records,
        "scope": "Finite-dimensional LP coefficients are exactly certified. Their connection to the singular threshold requires the written asymptotic proof. Values outside the listed k range are not inferred.",
    }


def verify(report: dict) -> dict:
    counts = Counter()
    for record in report["certificates"]:
        check_certificate(record)
        counts[record["k"]] += 1
    for row in report["table"]:
        k = row["k"]
        expected = {representative(w) for w in words(k+1) if w != w[::-1]}
        records = [r for r in report["certificates"] if r["k"] == k]
        assert len(records) == len(expected)
        assert {r["missing_word"] for r in records} == expected
        assert Q(row["maximum_coefficient"]) == max(Q(r["coefficient"]) for r in records)
    return {"status": "PASS: standard-library exact rational verification", "certificate_count": sum(counts.values()), "per_memory": dict(counts)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--generate", action="store_true")
    parser.add_argument("--max-k", type=int, default=8)
    arguments = parser.parse_args()
    if arguments.generate:
        report = generate(arguments.max_k)
        RESULT.write_text(json.dumps(report, indent=2) + "\n")
    else:
        report = json.loads(RESULT.read_text())
    receipt = verify(report)
    Path("results/memory_coefficient_verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
