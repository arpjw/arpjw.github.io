# Continuation 8: an algebraic transition in the near-fair threshold

Status: written proof plus a 12-interval certificate for one competing edge class. Exact rational arithmetic brackets the transition and the post-transition optimizer. Numerical checks are supplementary. Independent expert review and novelty verification remain open.

## 1. Main result

For stationary binary Markov sources of order at most three with
\(\mathrm{TV}(P_3,U_3)\le\tau\), let \(T_3(\tau)\) be the infimum
entropy-rate deficit permitting an unbounded observable time-reversal
KL rate over strictly positive kernels. All logarithms are natural.

The exact order-three singular threshold is now determined for every
\(0<\tau\le1/16\), extending the earlier interval by a factor of 625.
There is a new, continuous change of the critical boundary construction.

Let \(f(x)=x\log x\), and define

\[
\begin{split}
c&=\frac18-\frac{\tau}{2},\qquad
a=\frac18+\frac{\tau}{4}-\frac E2,\qquad e=\frac18+E,\\
z&=a-c,\qquad p=a+c,\qquad w=a+e,\\
\mathcal B(\tau,E)&=\log2+f(z)+2f(a)+2f(c)+2f(e)-2f(w)-f(p).
\end{split}
\]

Let \(\tau_*\) be the unique positive root of

\[
\boxed{12\tau(1+2\tau)^2(1+\tau)^2+\tau-1=0.}
\]

An exact rational bracket implies

\[
0.05676474584889017582578389126779<\tau_*
<0.05676474584889017582578389126780.
\]

For \(0<\tau\le\tau_*\), set \(E_*(\tau)=0\). For
\(\tau_*<\tau\le1/16\), let \(E_*(\tau)\) be the unique root in
\((0,\tau/2)\) of

\[
\boxed{e^4(a+c)=a^2(a+e)^2(a-c).}
\]

This is a polynomial equation in \(E\), with the affine substitutions above.
Then the exact global threshold is

\[
\boxed{T_3(\tau)=\mathcal B(\tau,E_*(\tau)).}
\]

Below this entropy-deficit budget the reversal-rate supremum is finite.
At or above it, the supremum is infinite over strictly positive kernels.
For every tolerance in this range, the critical boundary flow is unique
up to reversal and forbids 1010 or 0101.

For \(\tau\le\tau_*\), this is precisely the previous closed formula
\(V(\tau)\). The previous endpoint 0.0001 was a certified range,
not a phase boundary. At \(\tau=1/16\), outward enclosures are

\[
\begin{split}
E_*&\in(0.00305778789644517695496403078208,\;
0.00305778789644517695496403078212),\\
T_3&\in(0.07848341416309437360018738245140,\;
0.07848341416309437360018738245188).
\end{split}
\]

The improvement over extending the old vertex formula to this tolerance
exceeds 0.00010206079100429 nats.

## 2. The type-B polygon and its exposed edge

We use the stationary-flow classification and reverse-complement
symmetrization from Continuation 7. The three missing-edge classes are
A: 0011,1100; B: 1010,0101; and C: 0010,0100,1011,1101.
All three-word marginal probabilities are positive since \(\tau\le1/16\).

For type B, symmetrization gives \(a=b,c=d,e=f\). With
\(z=a-c\) and \(E=e-1/8\), the TV polygon is

\[
\frac{2|z-E|+|2z+E|}{3}+|E|\le\tau.
\]

Its global supporting inequality is \(z+E/2\le3\tau/4\).
Equality holds exactly on the edge

\[
z=\frac{3\tau}{4}-\frac E2,\qquad 0\le E\le\frac\tau2.
\]

To see the equality restriction, replace the two absolute values by
\(z-E\) and \(2z+E\). For \(E\ge0\) this gives
\(\mathrm{TV}\ge4z/3+2E/3\), with equality requiring \(E\le z\).
For \(E<0\), the stronger bound is \(z\le3\tau/4+E\),
so equality in the displayed supporting inequality is impossible.
The resulting marginal parametrization is exactly the one in Section 1.

Let \(F_B(z,E)\) denote the convex reduced deficit from Continuation 7.
Its gradients obey

\[
F_{B,E}-\frac12F_{B,z}
=2\log e-\log a-\log w+\frac12\log p-\frac12\log z
=\frac12\log\frac{e^4p}{a^2w^2z}.
\]

On the edge this is \(\mathcal B_E\). Direct differentiation gives

\[
\mathcal B_{EE}
=\frac2e+\frac1{2a}-\frac1{2w}-\frac1{4p}+\frac1{4z}>0.
\]

Indeed \(w>e\) and \(p>a\), so the first and third terms have positive
sum, as do the second and fourth; the last is positive.
Thus the edge objective is strictly convex.

At \(E=0\),

\[
\mathcal B_E(\tau,0)
=\frac12\log\frac{1-\tau}
 {12\tau(1+2\tau)^2(1+\tau)^2}.
\]

Its sign changes at exactly \(\tau_*\). The defining polynomial is
strictly increasing for positive \(\tau\), so the root is unique.
At the other edge endpoint \(E=\tau/2\),

\[
\frac{e^4p}{a^2w^2z}\ge\frac{112}{81}>1
\qquad(0<\tau\le1/16).
\]

For this bound use \(a=1/8,e\ge1/8,p\ge7/32,w\le9/32,z\le1/32\).
Strict convexity therefore gives exactly one interior edge minimum
when \(\tau>\tau_*\).

## 3. Why the edge minimum is the global type-B minimum

Throughout the edge region,

\[
a\in[1/8,9/64],\quad c\in[3/32,1/8],\quad
w\ge1/4,\quad p\le1/4,\quad z\le3/64.
\]

Consequently

\[
F_{B,z}
=\log z+\frac23\log a-\frac43\log c-\frac23\log w+\frac13\log p
<-0.74978.
\]

At an interior edge minimum \(F_E=F_z/2\). Since \(F_z<0\), its supporting
plane is minimized exactly on the exposed edge \(z+E/2=3\tau/4\).
Convexity proves global optimality on the whole polygon.
Strict convexity along the edge proves uniqueness.

At the vertex, the second supporting-gradient condition also holds:

\[
-F_{B,z}-F_{B,E}
=\log\frac{c^2w^2}{ze^2p}\ge\log3>0.
\]

The same endpoint bounds give this estimate. For \(\tau<\tau_*\),
the first condition \(F_E-F_z/2>0\) is strict as well, so the vertex is
the unique polygon optimum. At \(\tau=\tau_*\), the supporting plane
touches the edge, but strict edge convexity still makes the vertex
the unique optimum. This handles the equality case explicitly.

## 4. Type A is strictly worse throughout the larger interval

The type-A vertex remains its unique optimum up to \(\tau=1/16\).
At its vertex \(a=1/8-\tau/4,c=1/8+\tau/2,e=1/8,z=3\tau/4\),
the supporting-gradient conditions simplify to

\[
\exp(F_{A,E}-F_{A,z})
=\frac{1+\tau}{12\tau(1-\tau)^2}\ge\frac43>1,
\]

\[
\exp\!\left(2[-F_{A,z}/2-F_{A,E}]\right)
=\frac{(1-2\tau)^4(1-\tau)^2}{3\tau(1+\tau)}
\ge\frac{180075}{69632}>1.
\]

Their positivity also implies \(F_{A,z}<0\). Its value is the previous
\(U(\tau)\). The derivative difference from the type-B vertex value is

\[
(U-V)'=\frac14\log
\frac{4(1-\tau^2)(1-4\tau)^4}{(1-2\tau)^4(1+2\tau)^2}.
\]

The logarithmic ratio is strictly decreasing: its log derivative is

\[
-\frac{2\tau}{1-\tau^2}-\frac{16}{1-4\tau}
+\frac8{1-2\tau}-\frac4{1+2\tau}<0.
\]

The middle pair already has negative sum. Its minimum on the interval
is \(4080/2401>1\), attained at \(\tau=1/16\).
Hence \(U>V\ge T_3\) for every positive tolerance in the interval.
All constants in this section are exact rational endpoint bounds.

## 5. A convex certificate excludes the unsymmetrized type C

No symmetry averaging that fixes a type-C missing edge is assumed.
For the representative zero \(q(0010)=0\), use the full marginal vector
\(m=(e,a,b,c,d,f)\) with

\[
c+b=a+d,\qquad e+2a+2b+c+d+f=1.
\]

The constrained middle-01 block is
\(\begin{pmatrix}0&a\\c&z\end{pmatrix}\), where \(z=b-a=d-c\ge0\).
All other blocks use product margins to maximize conditional entropy.
Their reduced deficit is the convex function

\[
C(m)=\log2+f(e)+2f(a)+f(c)+f(b)+f(f)+f(z)
-f(e+a)-f(b+f)-f(a+d).
\]

The letter \(f\) in \(f(f)\) denotes the mass of 111 as its argument.
The function is convex as a partial minimization of conditional-entropy
deficit over affine flow constraints. It is continuous on the relevant
boundary, even if \(z=0\).

Take the strictly positive trial marginal

\[
m_C(\tau)=
\left(\frac18,\frac18-\frac\tau6,\frac18+\frac\tau2,
\frac18-\frac{2\tau}3,\frac18,\frac18\right)
=m_0+\tau v_C,
\]

where \(m_0=(1/8,\ldots,1/8)\) and
\(v_C=(0,-1/6,1/2,-2/3,0,0)\).
Write \(W(\tau)=C(m_C(\tau))\) and choose its gradient on the stationary
affine subspace as

\[
g=\left(
\log\frac e w,\quad 2\log a-\log z-\log w,\quad
\log\frac{bz}{up},\quad \log\frac c p,\quad0,\quad\log\frac f u
\right),
\]

with \(w=e+a,u=b+f,p=a+d\). This is an ambient representative;
only its inner products with stationary directions are used.

Let \(P\) be the TV unit ball of stationary marginal perturbations:

\[
P=\left\{v:
\sum_i w_iv_i=0,\ \sum_i \beta_iv_i=0,\
\frac12\sum_iw_i|v_i|\le1\right\},
\]

where \(w=(1,2,2,1,1,1)\) and \(\beta=(0,-1,1,1,-1,0)\).
Every feasible marginal is \(m_0+\tau v\) for some \(v\in P\).
Convexity therefore gives

\[
C(m)\ge W(\tau)+\tau\min_{v\in P}g(\tau)\cdot(v-v_C).
\]

The polytope \(P\) has **34 vertices**, enumerated exactly in the script.
Completeness is elementary: within an orthant, a vertex of the weighted
L1 ball intersected with two independent homogeneous constraints has
at most three nonzero coordinates. Three-coordinate circuits are
cross products of the two constraint rows. Two-coordinate circuits
are also captured by adjoining any independent third column.
There are no one-coordinate circuits because every weight is nonzero.
The script normalizes the TV of each nonzero cross product to one,
includes both signs, and deduplicates exact rational vectors.

For each vertex define

\[
D_v(\tau)=W(\tau)-V(\tau)+\tau g(\tau)\cdot(v-v_C).
\]

The exact interval certificate proves all 34 functions strictly positive
on \([1/10000,1/16]\). It uses just **12 closed subintervals** with matching
endpoints. On each subinterval it encloses \(D_v\) at the midpoint and uses
the mean-value bound from

\[
D'_v=g\cdot v-V'+(\tau g')\cdot(v-v_C).
\]

All logarithms and arithmetic are outward rounded using the previously
audited integer-interval library. This covers every parameter value;
it is not a parameter grid. Continuation 7's existing certificate
excludes C on \((0,1/10000]\). Thus every C boundary has deficit
strictly above \(V\), and hence strictly above the B optimum.

The trial \(m_C\) is only used to generate supporting planes.
No claim that it is the exact type-C optimizer over this entire
interval is needed or made.

## 6. Boundary flow, uniqueness, and divergence

With the optimal \(a,c,e\) from Section 1, take

\[
\pi=(e,a,c,a,a,c,a,e)
\]

in binary lexicographic order, and set the middle-01 block to

\[
\begin{pmatrix}c&a-c\\0&c\end{pmatrix}.
\]

Use product margins in the other three blocks. This stationary flow
has TV exactly \(\tau\), only one zero edge 1010, and reverse-edge mass
\(q(0101)=c^2/(a+c)>0\). Its deficit is the stated threshold.
Mixing with weight \(\eta\) of the fair flow produces positive kernels,
TV \((1-\eta)\tau\), deficit at most \((1-\eta)T_3(\tau)\), and

\[
\sigma_\eta=\frac{c^2}{a+c}\log\frac1\eta+O_\tau(1).
\]

Conversely, compactness would force any sequence with unbounded rate
below the claimed budget to have a limiting missing edge of type A,
B, or C. Continuity of entropy deficit, and the three minimizations
or lower bounds, give a contradiction.

For uniqueness, A and C are strictly excluded. The B polygon optimizer
is unique, including at the phase boundary. At fixed marginal the
product blocks maximize entropy uniquely. Equality in the original
reverse-complement averaging forces both flows to have the same row
kernel as their average. That average allows every edge except 1010
and is irreducible: append 111000 to reach 000, then append any
desired three-bit target. These paths avoid 1010. The stationary law
of this kernel is unique, so an unsymmetrized minimizer must already
equal the constructed flow. The other B missing edge gives its
reversal partner.

## 7. A continuous transition with a jump in curvature

Above \(\tau_*\), implicit differentiation of \(\mathcal B_E=0\) gives

\[
E_*'(\tau_*+)
=-\frac{\mathcal B_{\tau E}}{\mathcal B_{EE}}
\in(0.53664502934523786866,0.53664502934523786867).
\]

At \(E=0\),

\[
\mathcal B_{\tau E}
=-\frac1{4a}-\frac1{4w}-\frac1{8p}-\frac3{8z}<0.
\]

The threshold and its first derivative are continuous. Its second
derivative has a downward jump of

\[
\frac{\mathcal B_{\tau E}^2}{\mathcal B_{EE}}
\in(6.48307419233430305489,6.48307419233430305490).
\]

The construction starts moving continuously; it does not jump to a
separated optimizer as the earlier exactly-fair entropy frontier did.
This is a second, mathematically different phase change within the
same research problem.

## 8. Reproduction, audit, and remaining scope

Run python3 continuation/extended_near_threshold.py.
It writes results/extended_near_threshold.json; the saved log is
results/extended_near_threshold_run.log.

The receipt contains all 34 exact vertices, the 12 covering intervals,
positive lower bounds, rational polynomial-root brackets, analytic
sign receipts, and five certified examples. At all five examples the
closed entropy expression agrees with independently summed rational
flow entropy intervals. Five independent type-C flow sums also agree
with the supporting-plane construction's value. A fair-flow regularization has certified
deficit strictly below the exact threshold interval. Eighty
finite-difference checks in stationary directions are labeled
floating-point diagnostics.

The symmetry and equality arguments from Continuation 7 were reread.
No correction to its theorem was required. The type-C calculation
uses the full stationary marginal polytope, not the A/B
symmetrization. The new endpoint \(1/16\) is again a convenient certified
endpoint, not a claim that another phase transition occurs there.
The structure beyond it, larger memory, and the full capped-pair
phase diagram remain open.
