#!/usr/bin/env python3
"""Exact certificates for the five-day calibration gap; standard library only.

Run: python3 verify_calibration.py
Prints JSON. No floating point arithmetic or optimization solver is used.
"""

from fractions import Fraction as F
from itertools import combinations, product
import json


BITS = ((0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0), (1, 1, 1))
REPORTS = tuple(tuple(F(1, 2) if bit == 0 else F(1, 3) for bit in row) for row in BITS)
POLICIES = tuple(product((0, 1), repeat=5))


def constraints():
    rows, rhs = [], []
    for expert in range(3):
        for report in sorted({row[expert] for row in REPORTS}):
            row = tuple(F(p[expert] == report) for p in REPORTS)
            rows.append(row)
            rhs.append(sum(row) * report)
    return rows, rhs


def satisfies(point, rows, rhs):
    return all(sum(a * z for a, z in zip(row, point)) == b for row, b in zip(rows, rhs))


def unique_solution(rows, rhs, n):
    """Rational Gauss-Jordan elimination, including inconsistency detection."""
    mat = [list(map(F, row)) + [F(b)] for row, b in zip(rows, rhs)]
    pivots = []
    for col in range(n):
        pivot = next((r for r in range(len(pivots), len(mat)) if mat[r][col]), None)
        if pivot is None:
            continue
        r = len(pivots)
        mat[r], mat[pivot] = mat[pivot], mat[r]
        divisor = mat[r][col]
        mat[r] = [v / divisor for v in mat[r]]
        for other in range(len(mat)):
            if other != r:
                factor = mat[other][col]
                mat[other] = [x - factor * y for x, y in zip(mat[other], mat[r])]
        pivots.append(col)
    if any(not any(row[:n]) and row[n] for row in mat) or len(pivots) != n:
        return None
    result = [F(0)] * n
    for r, col in enumerate(pivots):
        result[col] = mat[r][n]
    return tuple(result)


def box_vertices(rows, rhs, n):
    """Enumerate all active box subsets, independent of the derived line formula."""
    vertices = set()
    for k in range(n + 1):
        for indices in combinations(range(n), k):
            for values in product((0, 1), repeat=k):
                extra = [tuple(F(j == i) for j in range(n)) for i in indices]
                point = unique_solution(rows + extra, rhs + list(values), n)
                if point is not None and all(0 <= z <= 1 for z in point):
                    assert satisfies(point, rows, rhs)
                    vertices.add(point)
    return sorted(vertices)


def payoff(policy, counts, capacity):
    return sum(z if action else capacity - z for action, z in zip(policy, counts))


def main():
    rows, rhs = constraints()
    binary = [p for p in POLICIES if satisfies(p, rows, rhs)]
    assert binary == [(1, 0, 0, 0, 1)]
    vertices = box_vertices(rows, rhs, 5)
    bad_vertex = (F(1, 2), F(1, 2), F(1, 2), F(1, 2), F(0))
    assert vertices == [bad_vertex, tuple(map(F, binary[0]))]

    finite_policy = binary[0]
    assert min(payoff(finite_policy, z, 1) for z in binary) == 5
    relaxed_policy = (0, 0, 0, 0, 0)
    assert min(payoff(relaxed_policy, z, 1) for z in vertices) == 3
    # A pointwise upper bound for every pure policy also bounds every mixture.
    assert max(payoff(policy, bad_vertex, 1) for policy in POLICIES) == 3

    repetition_checks = []
    for r in range(1, 101):
        feasible_counts = [(a, r - a, r - a, r - a, 2 * a - r)
                           for a in range((r + 1) // 2, r + 1)]
        for counts in feasible_counts:
            assert satisfies(counts, rows, [r * b for b in rhs])
            assert all(0 <= z <= r for z in counts)
        expected = 5 if r == 1 else 3 * r + (r % 2)
        lower = max(min(payoff(policy, z, r) for z in feasible_counts) for policy in POLICIES)
        # One feasible count vector is an upper bound against all mixed policies.
        upper = max(payoff(policy, feasible_counts[0], r) for policy in POLICIES)
        assert lower == upper == expected
        relaxed_vertex = tuple(r * z for z in bad_vertex)
        relaxed_upper = max(payoff(policy, relaxed_vertex, r) for policy in POLICIES)
        relaxed_lower = min(payoff(relaxed_policy, z, r)
                            for z in (relaxed_vertex, tuple(r * z for z in binary[0])))
        assert relaxed_lower == relaxed_upper == 3 * r
        repetition_checks.append({"r": r, "finite": expected, "relaxed": 3 * r})

    # The smallest approximate-calibration example illustrates bound rounding.
    p, epsilon = F(2, 5), F(2, 5)
    assert [y for y in (0, 1) if abs(y - p) <= epsilon] == [0]
    assert abs(F(1, 2) - p) <= epsilon

    # Exact rational samples supplement the proof for the entire epsilon range.
    tolerances = (F(0), F(1, 100), F(1, 12), F(1, 6), F(1, 4), F(1, 3) - F(1, 1000))
    for tolerance in tolerances:
        def approx_feasible(point):
            return all(abs(sum(a * z for a, z in zip(row, point)) - b)
                       <= sum(row) * tolerance for row, b in zip(rows, rhs))
        assert [z for z in POLICIES if approx_feasible(z)] == binary
        candidate = (F(1, 2),) * 4 + (min(F(1, 2), 3 * tolerance),)
        assert approx_feasible(candidate)
        expected = max(F(5, 2), 3 - 3 * tolerance)
        assert max(payoff(policy, candidate, 1) for policy in POLICIES) == expected
        if tolerance <= F(1, 6):
            policy = (F(1, 2), F(1, 6), F(1, 6), F(1, 6), F(0))
            coefficients = tuple(2 * x - 1 for x in policy)
            upper_rows = [row for row in rows if sum(row) == 3]
            dual_coefficients = tuple(-sum(row[j] for row in upper_rows) / 3 for j in range(5))
            assert coefficients == dual_coefficients
            assert sum(1 - x for x in policy) - (1 + 3 * tolerance) == expected
        else:
            assert all(2 * F(1, 2) - 1 == 0 for _ in range(5))
    complement = tuple(1 - z for z in binary[0])
    for row, b in zip(rows, rhs):
        assert abs(sum(a * z for a, z in zip(row, complement)) - b) <= sum(row) / 3
    assert tuple(F(a + b, 2) for a, b in zip(binary[0], complement)) == (F(1, 2),) * 5

    print(json.dumps({
        "status": "all exact certificates passed",
        "arithmetic": "fractions.Fraction and integers only",
        "binary_sequences_enumerated": 32,
        "deterministic_policies_enumerated": 32,
        "feasible_binary_sequences": binary,
        "relaxed_vertices": [[str(z) for z in v] for v in vertices],
        "finite_value": 5,
        "relaxed_value": 3,
        "repetition_cases_verified": len(repetition_checks),
        "repetition_values_first_ten": repetition_checks[:10],
        "approximate_one_day_counterexample_verified": True,
        "approximate_five_day_tolerances_verified": [str(t) for t in tolerances],
        "approximate_endpoint_complement_certificate_verified": True,
        "limits": "Certificates supplement the proofs; they do not establish literature priority."
    }, indent=2))


if __name__ == "__main__":
    main()
