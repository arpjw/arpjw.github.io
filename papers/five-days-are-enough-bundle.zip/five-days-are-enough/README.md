# Five Days Are Enough

A research draft on finite empirical calibration and continuous forecast aggregation.

Files:
- calibration_gap.tex: standalone LaTeX manuscript.
- verify_calibration.py: exact-arithmetic checks, using only the Python standard library.
- verification.json: recorded verification output.

Run `python3 verify_calibration.py` to reproduce the checks. Compile the manuscript with Tectonic or a standard LaTeX distribution.

This AI-assisted draft includes complete proofs, references, and disclosure of verification and novelty limits. It has not received external peer review.
